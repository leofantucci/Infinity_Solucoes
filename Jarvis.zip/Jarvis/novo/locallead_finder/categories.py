"""Categorias configuráveis (data/categories.json): palavra-chave -> filtros OSM."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from services.dedupe import normalize_text


@dataclass
class Category:
    key: str
    label: str
    aliases: list[str]
    queries: list[list[tuple[str, str]]]   # OU entre queries, E dentro de cada uma
    name_regex: str = ""


def _parse_tag(text: str) -> tuple[str, str]:
    key, _, value = text.partition("=")
    if not key.strip() or not value.strip():
        raise ValueError(f"Tag inválida '{text}'. Use o formato chave=valor (ex.: amenity=dentist).")
    return key.strip(), value.strip()


class CategoryStore:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.categories: dict[str, Category] = {}
        self.load()

    def load(self) -> None:
        self.categories.clear()
        if not self.path.exists():
            return
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        for key, item in raw.items():
            if key.startswith("_") or not isinstance(item, dict):
                continue
            queries = [[_parse_tag(t) for t in q] for q in item.get("queries", [])]
            self.categories[key] = Category(
                key=key, label=item.get("label", key), aliases=item.get("aliases", [key]),
                queries=queries, name_regex=item.get("name_regex", ""),
            )

    def labels(self) -> list[str]:
        return [c.label for c in self.categories.values()]

    def match(self, keyword: str) -> Category | None:
        """Encontra a categoria pelo que o usuário digitou (rótulo, chave ou alias)."""
        kw = normalize_text(keyword)
        if not kw:
            return None
        for cat in self.categories.values():           # correspondência exata
            names = {normalize_text(cat.key), normalize_text(cat.label), *map(normalize_text, cat.aliases)}
            if kw in names:
                return cat
        for cat in self.categories.values():           # correspondência parcial
            for alias in map(normalize_text, cat.aliases):
                if len(alias) >= 4 and (alias in kw or kw in alias):
                    return cat
        return None

    def add(self, key: str, label: str, aliases: list[str], tag_groups: list[list[str]]) -> None:
        """Adiciona/atualiza uma categoria e grava no JSON, sem mexer na lógica do programa."""
        for group in tag_groups:
            for tag in group:
                _parse_tag(tag)
        raw = json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
        raw[normalize_text(key).replace(" ", "_")] = {
            "label": label or key,
            "aliases": [normalize_text(a) for a in aliases if a.strip()] or [normalize_text(key)],
            "queries": tag_groups,
        }
        self.path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
        self.load()
