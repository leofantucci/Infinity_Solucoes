"""Orquestra pesquisa e verificação (usado pela interface; também testável sem GUI)."""
from __future__ import annotations

from browser.firefox import BrowserError, FirefoxBrowser
from models import SITE_ENCONTRADO, Company, SearchParams
from providers.google_places import GooglePlacesProvider
from providers.osm import OSMProvider
from services import lead_classifier
from services.dedupe import deduplicate
from services.site_checker import SiteVerifier
from utils import Cancelled, HttpClient, ProviderError

SOURCE_OSM = "OpenStreetMap"
SOURCE_GOOGLE = "Google Places API"


def filter_discovered(companies: list[Company], site_filter: str, only_phone: bool) -> list[Company]:
    """site_filter: 'todos' | 'com_site' | 'sem_site'."""
    out = []
    for c in companies:
        if site_filter == "com_site" and not c.site:
            continue
        if site_filter == "sem_site" and c.site:
            continue
        if only_phone and not c.telefone:
            continue
        out.append(c)
    return out


def run_search(settings, db, categories, params: SearchParams, source: str, site_filter: str,
               only_phone: bool, cancel, log=print, progress=lambda done, total: None) -> list[int]:
    http = HttpClient(settings, cancel, log)
    osm = OSMProvider(settings, db, categories, http, cancel, log)
    provider = osm if source == SOURCE_OSM else GooglePlacesProvider(settings, osm, http, cancel, log)
    progress(0, 0)
    log(f"Pesquisando '{params.keyword}' em {params.city}/{params.state} (raio {params.radius_km:g} km) "
        f"via {provider.source_name}...")
    companies = provider.search(params)
    log(f"{len(companies)} estabelecimento(s) retornado(s) pela fonte.")
    companies = deduplicate(companies)
    companies = filter_discovered(companies, site_filter, only_phone)
    ids, new = [], 0
    total = len(companies)
    for i, c in enumerate(companies, 1):
        cancel.check()
        if c.site:                     # a fonte informou um site; a verificação o confirma depois
            c.status_site = SITE_ENCONTRADO
        lead_classifier.apply(c)
        cid, is_new = db.upsert(c)
        existing = db.get_many([cid])[0]
        lead_classifier.apply(existing)
        db.save(existing)
        ids.append(cid)
        new += is_new
        progress(i, total)
    log(f"Concluído: {len(ids)} empresa(s) após filtros ({new} nova(s), {len(ids) - new} já estavam no banco).")
    return ids


def run_verification(settings, db, ids: list[int], cancel, log=print, progress=lambda d, t: None,
                     use_browser: bool = True, headless: bool | None = None, recheck: bool = False) -> int:
    companies = db.get_many(ids)
    todo = [c for c in companies if recheck or not c.verificado_em]
    if not todo:
        log("Nada a verificar: todas as empresas já foram verificadas.")
        return 0
    http = HttpClient(settings, cancel, log)
    browser = None
    done = 0
    try:
        if use_browser:
            browser = FirefoxBrowser(settings, cancel, headless, log)
            try:
                browser.start()
            except BrowserError as exc:
                log(f"AVISO: {exc}")
                log("Continuando apenas com Requests (sem busca no navegador).")
                browser = None
        verifier = SiteVerifier(settings, http, cancel, log, browser, use_search=browser is not None)
        progress(0, len(todo))
        for c in todo:
            cancel.check()
            try:
                verifier.verify(c)
            except Cancelled:
                raise
            except Exception as exc:   # uma empresa com erro não pode derrubar o lote
                log(f"  Erro ao verificar '{c.nome}': {exc}. Marcado como inconclusivo.")
                c.status_site = "Verificação inconclusiva"
                lead_classifier.apply(c)
            db.save(c)
            done += 1
            progress(done, len(todo))
    except Cancelled:
        log("Verificação cancelada; o que já foi verificado ficou salvo.")
    finally:
        if browser is not None:
            browser.close()
    log(f"Verificação finalizada: {done} de {len(todo)} empresa(s).")
    return done
