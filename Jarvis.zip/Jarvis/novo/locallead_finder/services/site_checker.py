"""Verificação de presença digital: site oficial + redes sociais."""
from __future__ import annotations

import re
from datetime import datetime
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from browser.firefox import BrowserBlocked, BrowserError
from models import (REDES_BUSCA, REDES_CANDIDATOS, REDES_FONTE, REDES_NAO_VERIFICADAS, REDES_NENHUMA,
                    REDES_NO_SITE, SITE_ENCONTRADO, SITE_INCONCLUSIVO, SITE_NAO_INFORMADO, SITE_NENHUM,
                    Company)
from services import lead_classifier
from services.matching import is_directory_domain, score_candidate, snippet_confirms_profile
from services.social_finder import PLATFORMS, classify_url, extract_social_links
from utils import Cancelled, FetchError

_CONTACT_RE = re.compile(r"\(?\d{2}\)?\s?9?\d{4}[-\s]?\d{4}|tel:|wa\.me|whatsapp|mailto:", re.I)
MAX_LINKS_TESTED = 5
MAX_CANDIDATE_PAGES = 4


def normalize_url(url: str) -> str:
    url = (url or "").strip()
    if not url:
        return ""
    return url if re.match(r"^https?://", url, re.I) else "https://" + url


def analyze_html(html: str, url: str) -> tuple[list[str], dict]:
    """Critérios observáveis: viewport, HTTPS, contato visível, conteúdo e título."""
    soup = BeautifulSoup(html or "", "html.parser")
    facts = {
        "viewport": bool(soup.find("meta", attrs={"name": re.compile("^viewport$", re.I)})),
        "https": url.lower().startswith("https://"),
        "titulo": (soup.title.get_text(strip=True) if soup.title else ""),
    }
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    text = soup.get_text(" ", strip=True)
    facts["texto_len"] = len(text)
    facts["contato"] = bool(_CONTACT_RE.search(html or ""))
    problems = []
    if not facts["viewport"]:
        problems.append("sem meta viewport (provável layout não responsivo)")
    if not facts["https"]:
        problems.append("não usa HTTPS")
    if not facts["contato"]:
        problems.append("sem telefone, WhatsApp ou e-mail visível")
    if facts["texto_len"] < 300:
        problems.append("conteúdo textual muito escasso")
    if not facts["titulo"]:
        problems.append("página sem título")
    return problems, facts


def internal_links(html: str, base_url: str, limit: int = MAX_LINKS_TESTED) -> list[str]:
    host = urlparse(base_url).netloc
    seen, out = set(), []
    for a in BeautifulSoup(html or "", "html.parser").find_all("a", href=True):
        href = a["href"].strip()
        if href.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue
        full = urljoin(base_url, href).split("#")[0]
        if urlparse(full).netloc == host and full not in seen and full.rstrip("/") != base_url.rstrip("/"):
            seen.add(full)
            out.append(full)
        if len(out) >= limit:
            break
    return out


class SiteVerifier:
    def __init__(self, settings, http, cancel, log=print, browser=None, use_search: bool = True) -> None:
        self.s, self.http, self.cancel, self.log = settings, http, cancel, log
        self.browser, self.use_search = browser, use_search

    # ---------- página ----------
    def _fetch_html(self, url: str) -> tuple[str | None, str, str]:
        """Retorna (html, url_final, erro). Tenta Requests e, se preciso, o Firefox (JS)."""
        error = ""
        html, final = None, url
        try:
            resp = self.http.get(url, headers={"Accept": "text/html,application/xhtml+xml"})
            ctype = resp.headers.get("Content-Type", "")
            if resp.status_code < 400 and "html" in ctype.lower():
                html, final = resp.text, resp.url
            else:
                error = f"HTTP {resp.status_code}" if resp.status_code >= 400 else f"conteúdo {ctype or 'desconhecido'}"
        except FetchError as exc:
            error = str(exc)
        needs_js = html is not None and len(BeautifulSoup(html, "html.parser").find_all("a")) < 3 \
            and len(html) < 4000
        if (html is None or needs_js) and self.browser is not None:
            try:
                self.log(f"  Abrindo no Firefox: {url}")
                rendered = self.browser.get_html(url)
                if rendered and len(rendered) > 200:
                    return rendered, url, ""
            except BrowserError as exc:
                error = error or str(exc)
        return html, final, error

    def _broken_links(self, html: str, url: str) -> tuple[int, int]:
        tested = broken = 0
        for link in internal_links(html, url):
            self.cancel.check()
            tested += 1
            try:
                if self.http.get(link, retries=0, timeout=10).status_code >= 400:
                    broken += 1
            except FetchError:
                broken += 1
        return tested, broken

    def _record_site(self, c: Company, url: str, html: str, via: str) -> None:
        c.site = url
        c.status_site = SITE_ENCONTRADO
        c.verificacao_url = url
        problems, facts = analyze_html(html, url)
        tested, broken = self._broken_links(html, url)
        if tested and broken >= 2 and broken / tested >= 0.4:
            problems.append(f"links internos quebrados ({broken} de {tested} testados)")
        c.site_problemas = " | ".join(problems)
        c.analise_site = (f"{via}. Título: {facts['titulo'][:80] or 'ausente'}; viewport: "
                          f"{'sim' if facts['viewport'] else 'não'}; HTTPS: {'sim' if facts['https'] else 'não'}; "
                          f"contato visível: {'sim' if facts['contato'] else 'não'}; "
                          f"links testados: {tested}, com erro: {broken}.")
        socials = extract_social_links(html, url)
        found = False
        for plat in PLATFORMS:
            if socials[plat] and not getattr(c, plat):
                setattr(c, plat, socials[plat][0])
                found = True
        if found or any(socials.values()):
            c.status_redes = REDES_NO_SITE
        elif c.status_redes == REDES_NAO_VERIFICADAS:
            c.status_redes = REDES_NENHUMA

    # ---------- fluxos ----------
    def verify(self, c: Company) -> Company:
        self.cancel.check()
        self.log(f"Verificando: {c.nome}")
        c.verificado_em = datetime.now().strftime("%Y-%m-%d %H:%M")
        c.status_redes = REDES_FONTE if (c.instagram or c.facebook or c.youtube) else REDES_NAO_VERIFICADAS
        site = normalize_url(c.site)
        social = classify_url(site) if site else None
        if social:                           # o campo "site" apontava para uma rede social
            if not getattr(c, social[0]):
                setattr(c, social[0], social[1])
            c.status_redes = REDES_FONTE
            self.log("  O 'site' informado é uma rede social; será tratado como perfil, não como site.")
            c.site, site = "", ""
        if site:
            self._verify_known_site(c, site)
        else:
            self._verify_by_search(c)
        lead_classifier.apply(c)
        return c

    def _verify_known_site(self, c: Company, site: str) -> None:
        html, final, error = self._fetch_html(site)
        if html is None:
            c.status_site = SITE_INCONCLUSIVO
            c.verificacao_url = site
            c.analise_site = f"Site informado pela fonte, mas não foi possível acessá-lo ({error})."
            self.log(f"  Inconclusivo: {error}")
            return
        self._record_site(c, final or site, html, "Site informado pela fonte e acessível")
        self.log("  Site oficial acessível.")

    def _verify_by_search(self, c: Company) -> None:
        if not (self.use_search and self.browser is not None):
            c.status_site = SITE_NAO_INFORMADO
            self.log("  Sem site na fonte e sem busca no navegador: mantido como 'não informado pela fonte'.")
            return
        query = f"{c.nome} {c.cidade}".strip()
        search_url = "https://html.duckduckgo.com/html/?q=" + query.replace(" ", "+")
        c.verificacao_url = search_url
        try:
            results = self.browser.search(query)
        except BrowserBlocked as exc:
            c.status_site, c.analise_site = SITE_INCONCLUSIVO, str(exc)
            self.log(f"  {exc} Revisão manual necessária.")
            return
        except (BrowserError, Cancelled) as exc:
            if isinstance(exc, Cancelled):
                raise
            c.status_site, c.analise_site = SITE_INCONCLUSIVO, f"Falha no navegador: {exc}"
            self.log(f"  Falha no navegador: {exc}")
            return
        if not results:
            c.status_site, c.analise_site = SITE_INCONCLUSIVO, "A busca não retornou resultados legíveis."
            self.log("  Busca sem resultados legíveis: inconclusivo.")
            return

        candidates, unchecked, fetched = [], 0, 0
        confirmed_social = False
        for r in results[:10]:
            self.cancel.check()
            plat = classify_url(r.url)
            if plat:
                if snippet_confirms_profile(c, f"{r.title} {r.snippet}"):
                    if not getattr(c, plat[0]):
                        setattr(c, plat[0], plat[1])
                    confirmed_social = True
                else:
                    candidates.append(plat[1])
                continue
            if is_directory_domain(r.url) or fetched >= MAX_CANDIDATE_PAGES:
                continue
            fetched += 1
            html, final, error = self._fetch_html(r.url)
            if html is None:
                unchecked += 1
                continue
            text = BeautifulSoup(html, "html.parser").get_text(" ", strip=True)
            ok, reasons = score_candidate(c, final or r.url, r.title, text)
            if ok:
                origin = urlparse(final or r.url)
                home = f"{origin.scheme}://{origin.netloc}/"
                self._record_site(c, home, html, "Site confirmado por busca (" + "; ".join(reasons) + ")")
                c.verificacao_url = r.url
                self.log(f"  Site oficial confirmado: {home}")
                break
        else:
            if unchecked:
                c.status_site = SITE_INCONCLUSIVO
                c.analise_site = f"{unchecked} resultado(s) da busca não puderam ser abertos; revisar manualmente."
                self.log("  Inconclusivo: alguns resultados não puderam ser verificados.")
            else:
                c.status_site = SITE_NENHUM
                c.analise_site = "Busca pública não retornou site que possa ser associado à empresa."
                self.log("  Nenhum site encontrado após verificação.")

        # redes sociais (só candidatas ficam em campo separado, para revisão manual)
        if c.status_redes != REDES_NO_SITE:
            if confirmed_social:
                c.status_redes = REDES_BUSCA
            elif candidates:
                c.status_redes = REDES_CANDIDATOS
                c.redes_candidatas = " ; ".join(dict.fromkeys(candidates))
            elif c.status_redes == REDES_NAO_VERIFICADAS:
                c.status_redes = REDES_NENHUMA
