"""Classificação comercial simples (prioridade alta / média / baixa)."""
from __future__ import annotations

from models import (PRIORIDADE_ALTA, PRIORIDADE_BAIXA, PRIORIDADE_MEDIA, SITE_ENCONTRADO,
                    SITE_INCONCLUSIVO, SITE_NENHUM, Company)
from services.dedupe import normalize_phone

MIN_PROBLEMAS_SITE = 2


def _redes(c: Company) -> str:
    nomes = [n for n, v in (("Instagram", c.instagram), ("Facebook", c.facebook), ("YouTube", c.youtube)) if v]
    if not nomes:
        return ""
    return f" Usa {', '.join(nomes)}, o que não indica ausência de site."


def classify(c: Company) -> tuple[str, str]:
    """Retorna (prioridade, motivo). Nunca conclui 'sem site' só porque o campo veio vazio."""
    if not c.ativo:
        return PRIORIDADE_BAIXA, "Empresa marcada como fechada/inativa pela fonte."

    tem_telefone = bool(normalize_phone(c.telefone))

    if c.status_site == SITE_ENCONTRADO:
        problemas = [p.strip() for p in c.site_problemas.split("|") if p.strip()]
        if len(problemas) >= MIN_PROBLEMAS_SITE:
            return PRIORIDADE_MEDIA, "Possui site, com deficiências observáveis: " + "; ".join(problemas) + "."
        if c.verificado_em:
            return PRIORIDADE_BAIXA, "Já possui site oficial sem deficiências relevantes observadas."
        return PRIORIDADE_BAIXA, "Site oficial informado pela fonte (ainda não analisado)."

    if c.status_site == SITE_NENHUM:
        if tem_telefone:
            return PRIORIDADE_ALTA, ("Empresa ativa, com telefone e nenhum site oficial encontrado "
                                     "após verificação." + _redes(c))
        return PRIORIDADE_MEDIA, ("Nenhum site encontrado após verificação, mas não há telefone "
                                  "disponível para contato." + _redes(c))

    if c.status_site == SITE_INCONCLUSIVO:
        return PRIORIDADE_MEDIA, "Verificação inconclusiva: revisar manualmente a presença digital." + _redes(c)

    return PRIORIDADE_MEDIA, ("Site não informado pela fonte; a existência de site ainda não foi "
                              "verificada." + _redes(c))


def apply(c: Company) -> Company:
    c.prioridade, c.motivo = classify(c)
    return c
