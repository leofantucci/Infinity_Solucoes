"""Normalização e deduplicação de empresas."""
from __future__ import annotations

import re
import unicodedata

from models import Company

_MERGE_FIELDS = [
    "categoria", "endereco", "cidade", "estado", "latitude", "longitude", "telefone",
    "site", "instagram", "facebook", "youtube", "google_maps_url", "fonte_url",
]


def normalize_text(value: str | None) -> str:
    """minúsculas, sem acentos, só letras/números separados por um espaço."""
    if not value:
        return ""
    text = unicodedata.normalize("NFKD", str(value))
    text = "".join(ch for ch in text if not unicodedata.combining(ch)).lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def normalize_phone(value: str | None) -> str:
    """Só dígitos, sem o código do país 55; usa o primeiro número se houver vários."""
    if not value:
        return ""
    first = re.split(r"[;/,]", str(value))[0]
    digits = re.sub(r"\D", "", first)
    if digits.startswith("55") and len(digits) > 11:
        digits = digits[2:]
    return digits


def id_key(c: Company) -> str:
    return f"{c.fonte}:{c.source_id}" if c.fonte and c.source_id else ""


def fingerprint(c: Company) -> str:
    """Combinação normalizada de nome + endereço + telefone."""
    name, addr, phone = normalize_text(c.nome), normalize_text(c.endereco), normalize_phone(c.telefone)
    if not name:
        return ""
    return f"{name}|{addr}|{phone}"


def name_phone_key(c: Company) -> str:
    """Chave relaxada: mesmo nome e mesmo telefone (endereços variam entre fontes)."""
    name, phone = normalize_text(c.nome), normalize_phone(c.telefone)
    return f"{name}|{phone}" if name and phone else ""


def keys_for(c: Company) -> list[str]:
    return [k for k in (id_key(c), fingerprint(c), name_phone_key(c)) if k]


def is_duplicate(a: Company, b: Company) -> bool:
    return bool(set(keys_for(a)) & set(keys_for(b)))


def merge_into(base: Company, other: Company) -> Company:
    """Preenche campos vazios de `base` com dados de `other` (nunca sobrescreve)."""
    for name in _MERGE_FIELDS:
        if getattr(base, name) in ("", None) and getattr(other, name) not in ("", None):
            setattr(base, name, getattr(other, name))
    return base


def deduplicate(companies: list[Company]) -> list[Company]:
    """Remove duplicatas mantendo a primeira ocorrência e aproveitando dados das demais."""
    seen: dict[str, Company] = {}
    result: list[Company] = []
    for company in companies:
        keys = keys_for(company)
        match = next((seen[k] for k in keys if k in seen), None)
        if match is not None:
            merge_into(match, company)
            keys = keys + keys_for(match)
        else:
            result.append(company)
            match = company
        for k in keys:
            seen[k] = match
    return result
