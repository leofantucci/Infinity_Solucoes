"""Google Places API (New) – opcional. Usa apenas a API oficial e a máscara mínima de campos.

ATENÇÃO: telefone e site pertencem a níveis (SKUs) de cobrança mais altos que nome/endereço.
Confira os preços e cotas vigentes na documentação oficial antes de usar.
"""
from __future__ import annotations

from datetime import datetime

from models import Company, SearchParams
from services.dedupe import normalize_text
from utils import FetchError, HttpClient, ProviderError

ENDPOINT = "https://places.googleapis.com/v1/places:searchText"
FIELD_MASK = ",".join([
    "places.id", "places.displayName", "places.formattedAddress", "places.location",
    "places.googleMapsUri", "places.nationalPhoneNumber", "places.websiteUri",
    "places.businessStatus", "nextPageToken",
])


def parse_places(places: list[dict], city: str, state: str, label: str, now: str | None = None) -> list[Company]:
    now = now or datetime.now().strftime("%Y-%m-%d %H:%M")
    result = []
    for p in places:
        name = (p.get("displayName") or {}).get("text", "").strip()
        if not name:
            continue
        address = p.get("formattedAddress", "")
        norm_addr = normalize_text(address)
        loc = p.get("location") or {}
        result.append(Company(
            nome=name, categoria=label, endereco=address,
            # só preenche cidade/estado se constarem no endereço retornado (nada é presumido)
            cidade=city if normalize_text(city) in norm_addr else "",
            estado=state if normalize_text(state) in norm_addr else "",
            latitude=loc.get("latitude"), longitude=loc.get("longitude"),
            telefone=p.get("nationalPhoneNumber", ""),
            site=p.get("websiteUri", ""),
            google_maps_url=p.get("googleMapsUri", ""),
            fonte="Google Places", source_id=p.get("id", ""),
            fonte_url=p.get("googleMapsUri", ""),
            data_pesquisa=now,
            ativo=p.get("businessStatus", "OPERATIONAL") == "OPERATIONAL",
        ))
    return result


class GooglePlacesProvider:
    source_name = "Google Places API"

    def __init__(self, settings, osm_provider, http: HttpClient, cancel, log=print) -> None:
        self.s, self.osm, self.http, self.cancel, self.log = settings, osm_provider, http, cancel, log

    def search(self, params: SearchParams) -> list[Company]:
        key = self.s.google_api_key
        if not key:
            raise ProviderError("Chave da Google Places API não configurada. Defina GOOGLE_PLACES_API_KEY no .env.")
        geo = self.osm.geocode(params.city, params.state, params.country)   # centro para viés de localização
        body = {
            "textQuery": f"{params.keyword} em {params.city}, {params.state}, {params.country}",
            "languageCode": "pt-BR", "regionCode": "BR", "pageSize": 20,
            "locationBias": {"circle": {
                "center": {"latitude": geo["lat"], "longitude": geo["lon"]},
                "radius": min(params.radius_km * 1000.0, 50000.0)}},
        }
        headers = {"Content-Type": "application/json", "X-Goog-Api-Key": key, "X-Goog-FieldMask": FIELD_MASK}
        companies: list[Company] = []
        while len(companies) < params.max_results:
            self.cancel.check()
            self.log("Consultando a Google Places API (Text Search)...")
            try:
                resp = self.http.post(ENDPOINT, json=body, headers=headers, min_interval=1.0)
            except FetchError as exc:
                raise ProviderError(f"Falha de conexão com a Google Places API: {exc}") from exc
            if resp.status_code != 200:
                try:
                    msg = resp.json().get("error", {}).get("message", "")
                except ValueError:
                    msg = ""
                hint = " Verifique a chave, se a Places API (New) está ativada e o faturamento do projeto." \
                    if resp.status_code in (400, 403) else ""
                raise ProviderError(f"Google Places API respondeu HTTP {resp.status_code}: {msg}.{hint}")
            data = resp.json()
            companies += parse_places(data.get("places", []), params.city, params.state, params.keyword)
            token = data.get("nextPageToken")
            if not token:
                break
            body["pageToken"] = token
        return companies[: params.max_results]
