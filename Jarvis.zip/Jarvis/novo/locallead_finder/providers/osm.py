"""OpenStreetMap: geocodificação (Nominatim) + busca de estabelecimentos (Overpass)."""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime

from categories import CategoryStore
from models import Company, SearchParams
from services.dedupe import normalize_text
from services.social_finder import normalize_handle
from utils import FetchError, HttpClient, ProviderError, haversine_km


def _q(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def build_query(queries: list[list[tuple[str, str]]], name_regex: str,
                lat: float, lon: float, radius_m: int, limit: int) -> str:
    """Monta a consulta Overpass QL (OU entre queries, E entre tags de uma query)."""
    around = f"(around:{radius_m},{lat:.6f},{lon:.6f})"
    parts = []
    for query in queries:
        conds = "".join(f'["{_q(k)}"="{_q(v)}"]' for k, v in query)
        parts.append(f"  nwr{conds}{around};")
    if name_regex:
        parts.append(f'  nwr["name"~"{_q(name_regex)}",i]{around};')
    if not parts:
        raise ProviderError("Nenhum filtro de busca definido para este segmento.")
    return "[out:json][timeout:60];\n(\n" + "\n".join(parts) + f"\n);\nout center tags {limit};"


def _address(tags: dict) -> str:
    street = tags.get("addr:street", "")
    number = tags.get("addr:housenumber", "")
    first = ", ".join(x for x in (street, number) if x)
    suburb = tags.get("addr:suburb") or tags.get("addr:neighbourhood") or ""
    city = tags.get("addr:city", "")
    state = tags.get("addr:state", "")
    postcode = tags.get("addr:postcode", "")
    city_state = " - ".join(x for x in (city, state) if x)
    pieces = [first, suburb, city_state, postcode]
    return ", ".join(p for p in pieces if p)


def _is_active(tags: dict) -> bool:
    return not any(k.startswith(("disused:", "abandoned:", "was:", "closed")) for k in tags) \
        and tags.get("opening_hours") != "closed"


def parse_elements(elements: list[dict], label: str, center: tuple[float, float],
                   max_results: int, now: str | None = None) -> list[Company]:
    """Converte elementos do Overpass em Company. Campos ausentes ficam vazios (nada é inventado)."""
    now = now or datetime.now().strftime("%Y-%m-%d %H:%M")
    found: list[tuple[float, Company]] = []
    for el in elements:
        tags = el.get("tags") or {}
        name = (tags.get("name") or tags.get("brand") or "").strip()
        if not name:
            continue                      # sem nome não há como prospectar
        lat = el.get("lat", (el.get("center") or {}).get("lat"))
        lon = el.get("lon", (el.get("center") or {}).get("lon"))
        kind, oid = el.get("type", "node"), el.get("id")
        company = Company(
            nome=name,
            categoria=label,
            endereco=_address(tags),
            cidade=tags.get("addr:city", ""),
            estado=tags.get("addr:state", ""),
            latitude=lat, longitude=lon,
            telefone=(tags.get("phone") or tags.get("contact:phone") or tags.get("contact:mobile") or "").strip(),
            site=(tags.get("website") or tags.get("contact:website") or tags.get("url") or "").strip(),
            instagram=normalize_handle("instagram", tags.get("contact:instagram", "")),
            facebook=normalize_handle("facebook", tags.get("contact:facebook", "")),
            youtube=normalize_handle("youtube", tags.get("contact:youtube", "")),
            fonte="OpenStreetMap",
            source_id=f"{kind}/{oid}",
            fonte_url=f"https://www.openstreetmap.org/{kind}/{oid}",
            data_pesquisa=now,
            ativo=_is_active(tags),
        )
        dist = haversine_km(center[0], center[1], lat, lon) if lat is not None and lon is not None else 9e9
        found.append((dist, company))
    found.sort(key=lambda t: t[0])
    return [c for _, c in found[:max_results]]


class OSMProvider:
    source_name = "OpenStreetMap"

    def __init__(self, settings, db, categories: CategoryStore, http: HttpClient, cancel, log=print) -> None:
        self.s, self.db, self.categories = settings, db, categories
        self.http, self.cancel, self.log = http, cancel, log

    # ---------- Nominatim ----------
    def geocode(self, city: str, state: str, country: str) -> dict:
        key = "nominatim:" + "|".join(normalize_text(x) for x in (city, state, country))
        cached = self.db.cache_get(key, self.s.cache_ttl_hours)
        if cached:
            self.log("Geocodificação obtida do cache local.")
            return json.loads(cached)
        self.log(f"Localizando {city}, {state}, {country} no Nominatim...")
        params = {"city": city, "state": state, "country": country, "format": "jsonv2", "limit": 1}
        if self.s.nominatim_email:
            params["email"] = self.s.nominatim_email
        try:
            resp = self.http.get(self.s.nominatim_url, params=params, min_interval=1.2,
                                 headers={"User-Agent": self.s.nominatim_user_agent})
        except FetchError as exc:
            raise ProviderError(f"Não foi possível consultar o Nominatim: {exc}") from exc
        if resp.status_code != 200:
            raise ProviderError(f"Nominatim respondeu HTTP {resp.status_code}. Tente novamente mais tarde.")
        data = resp.json()
        if not data:
            raise ProviderError(f"Cidade não encontrada: {city}, {state}, {country}. Confira a grafia.")
        result = {"lat": float(data[0]["lat"]), "lon": float(data[0]["lon"]), "nome": data[0].get("display_name", "")}
        self.db.cache_set(key, json.dumps(result))
        return result

    # ---------- Overpass ----------
    def _overpass(self, query: str) -> list[dict]:
        key = "overpass:" + hashlib.sha1(query.encode()).hexdigest()
        cached = self.db.cache_get(key, self.s.cache_ttl_hours)
        if cached:
            self.log("Resultado do Overpass obtido do cache local (sem nova consulta).")
            return json.loads(cached)
        last = "sem resposta"
        for url in self.s.overpass_urls:
            self.cancel.check()
            self.log(f"Consultando Overpass API ({url.split('/')[2]})...")
            try:
                # Uma repetição curta por endpoint evita ficar preso muito tempo
                # num servidor ruim antes de tentar a próxima alternativa.
                resp = self.http.post(url, data={"data": query}, timeout=90,
                                      min_interval=self.s.overpass_min_interval, retries=1)
            except FetchError as exc:
                last = str(exc)
                self.log(f"  Servidor indisponível: {exc}; tentando a próxima alternativa.")
                continue
            if resp.status_code == 200:
                try:
                    elements = resp.json().get("elements", [])
                except ValueError:
                    last = "resposta inválida"
                    continue
                self.db.cache_set(key, json.dumps(elements))
                return elements
            last = f"HTTP {resp.status_code}"
            self.log(f"  Overpass respondeu {last}; tentando o próximo servidor.")
        raise ProviderError(f"Overpass indisponível ({last}). Aguarde alguns minutos e tente de novo.")

    def search(self, params: SearchParams) -> list[Company]:
        geo = self.geocode(params.city, params.state, params.country)
        category = self.categories.match(params.keyword)
        if category:
            queries, regex, label = category.queries, category.name_regex, category.label
            self.log(f"Segmento reconhecido: {label}.")
        else:
            queries, regex, label = [], re.sub(r"[^\w\s-]", "", params.keyword).strip(), params.keyword
            self.log("Segmento sem mapeamento: buscando pelo nome (menos preciso). "
                     "Use 'Adicionar categoria' para mapear tags do OSM.")
        limit = min(max(params.max_results * 3, 60), 1000)
        query = build_query(queries, regex, geo["lat"], geo["lon"], int(params.radius_km * 1000), limit)
        elements = self._overpass(query)
        self.log(f"Overpass retornou {len(elements)} elementos.")
        return parse_elements(elements, label, (geo["lat"], geo["lon"]), params.max_results)
