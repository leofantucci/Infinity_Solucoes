"""Servidor web local (somente 127.0.0.1) que alimenta o painel HUD no Firefox. Só usa a biblioteca padrão."""
from __future__ import annotations

import json
import secrets
import tempfile
import threading
from dataclasses import asdict
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import exporters
from models import SearchParams
from services import pipeline
from services.dedupe import normalize_text
from utils import Cancelled, CancelToken, ProviderError

WEB_DIR = Path(__file__).resolve().parent / "web"
MAX_BODY = 64 * 1024
SITE_FILTERS = {"todos", "com_site", "sem_site"}


class Jobs:
    """Executa uma tarefa por vez em segundo plano e guarda logs/progresso para o painel."""

    def __init__(self, settings, db, categories) -> None:
        self.settings, self.db, self.categories = settings, db, categories
        self.lock = threading.Lock()
        self.logs: list[dict] = []
        self.running, self.task = False, ""
        self.progress = (0, 0)
        self.ids: list[int] = []
        self.cancel = CancelToken()
        self.thread: threading.Thread | None = None

    def log(self, msg: str) -> None:
        with self.lock:
            self.logs.append({"t": datetime.now().strftime("%H:%M:%S"), "m": str(msg)})

    def set_progress(self, done: int, total: int) -> None:
        self.progress = (done, total)

    def start(self, task: str, fn) -> bool:
        with self.lock:
            if self.running:
                return False
            self.running, self.task, self.progress = True, task, (0, 0)
            self.cancel = CancelToken()
            cancel = self.cancel

        def job() -> None:
            try:
                fn(cancel, self.log, self.set_progress)
            except Cancelled:
                self.log("Operação cancelada.")
            except ProviderError as exc:
                self.log(f"ERRO: {exc}")
            except Exception as exc:  # a thread nunca morre em silêncio
                self.log(f"ERRO inesperado: {type(exc).__name__}: {exc}")
            finally:
                with self.lock:
                    self.running = False

        self.thread = threading.Thread(target=job, daemon=True)
        self.thread.start()
        return True

    def status(self, since: int) -> dict:
        with self.lock:
            return {"running": self.running, "task": self.task, "logs": self.logs[since:],
                    "next": len(self.logs), "done": self.progress[0], "total": self.progress[1]}


def parse_params(data: dict) -> SearchParams:
    try:
        radius = float(str(data.get("radius", "5")).replace(",", "."))
        maximum = int(data.get("max", 50))
    except (TypeError, ValueError):
        raise ValueError("Raio e quantidade máxima devem ser números.")
    if not (0 < radius <= 50) or not (0 < maximum <= 500):
        raise ValueError("Raio deve estar entre 0 e 50 km e o máximo entre 1 e 500.")
    kw, city = str(data.get("keyword", "")).strip(), str(data.get("city", "")).strip()
    if not kw or not city:
        raise ValueError("Informe o segmento e a cidade.")
    return SearchParams(kw[:80], city[:80], str(data.get("state", "")).strip()[:80],
                        str(data.get("country", "")).strip()[:80], radius, maximum)


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, addr, settings, db, categories) -> None:
        super().__init__(addr, Handler)
        self.settings, self.db, self.categories = settings, db, categories
        self.jobs = Jobs(settings, db, categories)
        self.token = secrets.token_urlsafe(24)


class Handler(BaseHTTPRequestHandler):
    server: Server

    def log_message(self, *args) -> None:   # silencioso; o painel tem seus próprios logs
        pass

    # ---------- utilidades ----------
    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; "
                         "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def _error(self, code: int, msg: str) -> None:
        self._json({"error": msg}, code)

    def _host_ok(self) -> bool:
        port = self.server.server_address[1]
        return self.headers.get("Host", "") in (f"127.0.0.1:{port}", f"localhost:{port}")

    def _authorized(self, query: dict) -> bool:
        token = self.headers.get("X-LLF-Token") or (query.get("token") or [""])[0]
        return self._host_ok() and secrets.compare_digest(token, self.server.token)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > MAX_BODY:
            raise ValueError("Requisição grande demais.")
        raw = self.rfile.read(length) if length else b"{}"
        data = json.loads(raw or b"{}")
        if not isinstance(data, dict):
            raise ValueError("Corpo inválido.")
        return data

    # ---------- GET ----------
    def do_GET(self) -> None:
        url = urlparse(self.path)
        query = parse_qs(url.query)
        if url.path == "/":
            if not self._host_ok():
                return self._error(403, "Host não permitido.")
            html = (WEB_DIR / "index.html").read_text(encoding="utf-8").replace("__TOKEN__", self.server.token)
            return self._send(200, html.encode(), "text/html; charset=utf-8")
        if not self._authorized(query):
            return self._error(403, "Acesso negado.")
        s, jobs = self.server.settings, self.server.jobs
        if url.path == "/api/config":
            return self._json({
                "city": s.default_city, "state": s.default_state, "country": s.default_country,
                "categories": self.server.categories.labels(),
                "google_configured": bool(s.google_api_key),
                "sources": [pipeline.SOURCE_OSM, pipeline.SOURCE_GOOGLE],
                "export_filters": exporters.EXPORT_FILTERS,
                "firefox_headless": s.firefox_headless,
            })
        if url.path == "/api/status":
            try:
                since = max(int((query.get("since") or ["0"])[0]), 0)
            except ValueError:
                since = 0
            return self._json(jobs.status(since))
        if url.path == "/api/results":
            db = self.server.db
            companies = db.all() if (query.get("scope") or [""])[0] == "all" else db.get_many(jobs.ids)
            return self._json({"results": [asdict(c) for c in companies]})
        if url.path == "/api/export":
            return self._export(query)
        self._error(404, "Não encontrado.")

    def _export(self, query: dict) -> None:
        kind = (query.get("kind") or ["csv"])[0]
        mode = (query.get("filter") or ["todos"])[0]
        if kind not in ("csv", "xlsx") or mode not in exporters.EXPORT_FILTERS:
            return self._error(400, "Parâmetros de exportação inválidos.")
        companies = exporters.filter_companies(self.server.db.get_many(self.server.jobs.ids), mode)
        if not companies:
            return self._error(404, "Nenhuma empresa atende ao filtro de exportação.")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / f"out.{kind}"
            (exporters.export_csv if kind == "csv" else exporters.export_excel)(companies, path)
            body = path.read_bytes()
        name = f"leads_{mode}_{datetime.now():%Y%m%d_%H%M}.{kind}"
        ctype = "text/csv; charset=utf-8" if kind == "csv" else \
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        self._send(200, body, ctype, {"Content-Disposition": f'attachment; filename="{name}"'})

    # ---------- POST ----------
    def do_POST(self) -> None:
        url = urlparse(self.path)
        if not self._authorized(parse_qs(url.query)):
            return self._error(403, "Acesso negado.")
        try:
            data = self._body()
        except (ValueError, json.JSONDecodeError) as exc:
            return self._error(400, str(exc))
        srv, jobs, s = self.server, self.server.jobs, self.server.settings

        if url.path == "/api/search":
            try:
                params = parse_params(data)
            except ValueError as exc:
                return self._error(400, str(exc))
            source = data.get("source", pipeline.SOURCE_OSM)
            site_filter = data.get("site_filter", "todos")
            if source not in (pipeline.SOURCE_OSM, pipeline.SOURCE_GOOGLE) or site_filter not in SITE_FILTERS:
                return self._error(400, "Fonte ou filtro inválido.")
            if source == pipeline.SOURCE_GOOGLE and not s.google_api_key:
                return self._error(400, "Defina GOOGLE_PLACES_API_KEY no .env ou use o OpenStreetMap.")
            only_phone = bool(data.get("only_phone"))

            def run(cancel, log, progress):
                jobs.ids = pipeline.run_search(s, srv.db, srv.categories, params, source, site_filter,
                                               only_phone, cancel, log, progress)
            return self._started(jobs.start("search", run))

        if url.path == "/api/verify":
            if not jobs.ids:
                return self._error(400, "Faça uma pesquisa primeiro.")
            ids = list(jobs.ids)
            use_browser, headless = bool(data.get("use_browser", True)), bool(data.get("headless", False))
            return self._started(jobs.start("verify", lambda cancel, log, progress: pipeline.run_verification(
                s, srv.db, ids, cancel, log, progress, use_browser, headless)))

        if url.path == "/api/cancel":
            jobs.cancel.cancel()
            jobs.log("Cancelando... aguarde a operação atual terminar.")
            return self._json({"ok": True})

        if url.path == "/api/load_db":
            if jobs.running:
                return self._error(409, "Aguarde a tarefa atual terminar.")
            jobs.ids = [c.id for c in srv.db.all()]
            jobs.log(f"{len(jobs.ids)} empresa(s) carregada(s) do banco local.")
            return self._json({"ok": True})

        if url.path == "/api/category":
            name = str(data.get("name", "")).strip()
            aliases = [a.strip() for a in str(data.get("aliases", "")).split(",") if a.strip()]
            groups = [[t.strip() for t in g.split(",") if t.strip()] for g in str(data.get("tags", "")).split(";")]
            groups = [g for g in groups if g]
            if not name or not groups:
                return self._error(400, "Informe o nome e ao menos uma tag (ex.: shop=pet).")
            try:
                srv.categories.add(name, name, aliases + [name], groups)
            except ValueError as exc:
                return self._error(400, str(exc))
            jobs.log(f"Categoria '{name}' adicionada.")
            return self._json({"categories": srv.categories.labels()})

        if url.path == "/api/shutdown":
            jobs.cancel.cancel()
            self._json({"ok": True})
            threading.Thread(target=srv.shutdown, daemon=True).start()
            return
        self._error(404, "Não encontrado.")

    def _started(self, ok: bool) -> None:
        if not ok:
            return self._error(409, "Já existe uma tarefa em andamento.")
        self._json({"ok": True})


def create_server(settings, db, categories, port: int = 8765) -> Server:
    """Cria o servidor em 127.0.0.1. Se a porta estiver ocupada, tenta as próximas."""
    last: OSError | None = None
    for p in ([port + i for i in range(10)] if port else [0]):
        try:
            return Server(("127.0.0.1", p), settings, db, categories)
        except OSError as exc:
            last = exc
    raise OSError(f"Nenhuma porta livre a partir de {port}: {last}")
