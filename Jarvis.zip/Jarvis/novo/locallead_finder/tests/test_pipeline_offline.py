"""Fluxo completo sem rede: provedores e navegador são substituídos por dublês."""
import unittest
from types import SimpleNamespace
from unittest import mock

from browser.firefox import SearchResult
from categories import CategoryStore
from config import load_settings
from database import Database
from models import (SITE_ENCONTRADO, SITE_INCONCLUSIVO, SITE_NENHUM, SearchParams)
from providers.osm import OSMProvider
from services import pipeline
from services.site_checker import SiteVerifier
from utils import CancelToken, FetchError

ELEMENTS = [
    {"type": "node", "id": 1, "lat": -21.29, "lon": -50.34,
     "tags": {"name": "Clínica Sorriso Bom", "amenity": "dentist", "phone": "(18) 3641-0000"}},
    {"type": "node", "id": 2, "lat": -21.30, "lon": -50.34,
     "tags": {"name": "Dentista Com Site", "amenity": "dentist", "website": "https://comsite.example"}},
]
GOOD_PAGE = ("<html><head><title>Dentista</title><meta name='viewport' content='width=device-width'></head><body>"
             + "texto " * 100 + "<a href='tel:+551836410000'>ligar</a></body></html>")


class FakeHttp:
    def __init__(self, pages):
        self.pages = pages

    def get(self, url, **kw):
        if url not in self.pages:
            raise FetchError("sem rede")
        return SimpleNamespace(status_code=200, headers={"Content-Type": "text/html"}, text=self.pages[url], url=url)


class FakeBrowser:
    def __init__(self, results):
        self.results = results

    def search(self, query):
        return self.results

    def get_html(self, url):
        return ""   # simula página sem conteúdo renderizado extra; vale o HTML do Requests


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.s = load_settings()
        self.db = Database(":memory:")
        self.cancel = CancelToken()
        self.cats = CategoryStore(self.s.categories_file)

    def _search(self, **kw):
        with mock.patch.object(OSMProvider, "geocode", return_value={"lat": -21.29, "lon": -50.34, "nome": "x"}), \
             mock.patch.object(OSMProvider, "_overpass", return_value=ELEMENTS):
            return pipeline.run_search(self.s, self.db, self.cats, SearchParams("dentista", "Birigui", "São Paulo", "Brasil"),
                                       pipeline.SOURCE_OSM, kw.get("site", "todos"), kw.get("phone", False),
                                       self.cancel, log=lambda m: None)

    def test_pesquisa_classifica_e_nao_duplica(self):
        ids = self._search()
        self.assertEqual(len(ids), 2)
        self.assertEqual(len(self._search()), 2)
        self.assertEqual(len(self.db.all()), 2)
        by_name = {c.nome: c for c in self.db.get_many(ids)}
        self.assertEqual(by_name["Clínica Sorriso Bom"].prioridade, "média")   # ainda não verificada
        self.assertEqual(by_name["Dentista Com Site"].prioridade, "baixa")

    def test_filtros_de_pesquisa(self):
        self.assertEqual(len(self._search(site="sem_site")), 1)
        self.assertEqual(len(self._search(site="com_site")), 1)
        self.assertEqual(len(self._search(phone=True)), 1)

    def test_verificacao_site_conhecido(self):
        c = self.db.get_many(self._search(site="com_site"))[0]
        v = SiteVerifier(self.s, FakeHttp({"https://comsite.example": GOOD_PAGE}), self.cancel, lambda m: None)
        v.verify(c)
        self.assertEqual(c.status_site, SITE_ENCONTRADO)
        self.assertEqual(c.prioridade, "baixa")

    def test_site_inacessivel_e_inconclusivo(self):
        c = self.db.get_many(self._search(site="com_site"))[0]
        SiteVerifier(self.s, FakeHttp({}), self.cancel, lambda m: None).verify(c)
        self.assertEqual(c.status_site, SITE_INCONCLUSIVO)
        self.assertEqual(c.prioridade, "média")

    def test_busca_sem_site_confirmado_vira_alta_prioridade(self):
        c = self.db.get_many(self._search(site="sem_site"))[0]
        results = [SearchResult("Clínica Sorriso Bom - Apontador", "https://www.apontador.com.br/x", ""),
                   SearchResult("Clínica Sorriso Bom (@sorrisobom)", "https://www.instagram.com/sorrisobom/",
                                "Clínica Sorriso Bom em Birigui")]
        c.cidade = "Birigui"
        SiteVerifier(self.s, FakeHttp({}), self.cancel, lambda m: None, FakeBrowser(results)).verify(c)
        self.assertEqual(c.status_site, SITE_NENHUM)
        self.assertEqual(c.prioridade, "alta")
        self.assertEqual(c.instagram, "https://www.instagram.com/sorrisobom/")

    def test_busca_encontra_site_oficial(self):
        c = self.db.get_many(self._search(site="sem_site"))[0]
        page = GOOD_PAGE.replace("texto ", "Clínica Sorriso Bom (18) 3641-0000 ", 1)
        results = [SearchResult("Clínica Sorriso Bom", "https://sorrisobom.example/contato", "")]
        SiteVerifier(self.s, FakeHttp({"https://sorrisobom.example/contato": page}), self.cancel,
                     lambda m: None, FakeBrowser(results)).verify(c)
        self.assertEqual(c.status_site, SITE_ENCONTRADO)
        self.assertEqual(c.site, "https://sorrisobom.example/")


if __name__ == "__main__":
    unittest.main()
