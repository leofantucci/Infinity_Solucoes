import unittest

from browser.firefox import looks_blocked, parse_duckduckgo
from models import Company
from providers.osm import build_query, parse_elements
from providers.google_places import parse_places
from services.matching import is_directory_domain, score_candidate, snippet_confirms_profile
from services.site_checker import analyze_html, internal_links


class MatchingTests(unittest.TestCase):
    c = Company(nome="Clínica Sorriso Bom", cidade="Birigui", telefone="(18) 3641-0000")

    def test_confirma_site_com_telefone_e_nome(self):
        ok, _ = score_candidate(self.c, "https://clinicasorrisobom.com.br/", "Início",
                                "Clínica Sorriso Bom - ligue (18) 3641-0000")
        self.assertTrue(ok)

    def test_nao_confirma_so_por_semelhanca_de_nome(self):
        ok, _ = score_candidate(self.c, "https://outrosorriso.com/", "Sorriso", "Dentista em Marília, tel 14 3333-1111")
        self.assertFalse(ok)

    def test_diretorios_sao_ignorados(self):
        self.assertTrue(is_directory_domain("https://www.apontador.com.br/x"))
        self.assertFalse(is_directory_domain("https://clinicasorrisobom.com.br"))

    def test_perfil_social_exige_nome_completo_e_cidade_ou_telefone(self):
        self.assertTrue(snippet_confirms_profile(self.c, "Clínica Sorriso Bom (@x) - Birigui, SP"))
        self.assertFalse(snippet_confirms_profile(self.c, "Sorriso Bom - Curitiba"))


class ParsingTests(unittest.TestCase):
    def test_build_query_overpass(self):
        q = build_query([[("healthcare", "doctor"), ("healthcare:speciality", "dermatology")]], "dermat",
                        -21.29, -50.34, 5000, 100)
        self.assertIn('nwr["healthcare"="doctor"]["healthcare:speciality"="dermatology"](around:5000', q)
        self.assertIn('["name"~"dermat",i]', q)
        self.assertTrue(q.rstrip().endswith("out center tags 100;"))

    def test_parse_elements_nao_inventa_dados(self):
        elements = [
            {"type": "node", "id": 1, "lat": -21.29, "lon": -50.34,
             "tags": {"name": "Dentista A", "amenity": "dentist", "phone": "+55 18 3641-0000",
                      "contact:instagram": "@dentista_a"}},
            {"type": "way", "id": 2, "center": {"lat": -21.3, "lon": -50.3}, "tags": {"name": "Dentista B"}},
            {"type": "node", "id": 3, "lat": -21.29, "lon": -50.34, "tags": {"amenity": "dentist"}},  # sem nome
        ]
        result = parse_elements(elements, "Dentistas", (-21.29, -50.34), 10, now="2026-10-26 10:00")
        self.assertEqual([c.nome for c in result], ["Dentista A", "Dentista B"])
        self.assertEqual(result[0].instagram, "https://www.instagram.com/dentista_a/")
        self.assertEqual(result[1].telefone, "")
        self.assertEqual(result[1].site, "")
        self.assertEqual(result[0].fonte_url, "https://www.openstreetmap.org/node/1")

    def test_parse_google_places(self):
        places = [{"id": "abc", "displayName": {"text": "Mercado Bom"}, "formattedAddress": "Rua A, 10 - Birigui - SP",
                   "location": {"latitude": -21.2, "longitude": -50.3}, "googleMapsUri": "https://maps.google.com/?cid=1",
                   "businessStatus": "CLOSED_PERMANENTLY"}]
        c = parse_places(places, "Birigui", "São Paulo", "mercado")[0]
        self.assertEqual(c.cidade, "Birigui")
        self.assertEqual(c.estado, "")           # "São Paulo" não consta no endereço retornado
        self.assertFalse(c.ativo)
        self.assertEqual(c.site, "")

    def test_parse_duckduckgo_e_bloqueio(self):
        html = ('<div class="result"><a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexemplo.com.br%2F&rut=1">'
                'Exemplo</a><a class="result__snippet">Texto</a></div>')
        r = parse_duckduckgo(html)
        self.assertEqual(r[0].url, "https://exemplo.com.br/")
        self.assertEqual(r[0].snippet, "Texto")
        self.assertTrue(looks_blocked("<div class='anomaly-modal'>"))
        self.assertFalse(looks_blocked(html))

    def test_analise_observavel(self):
        problems, facts = analyze_html("<html><head><title>X</title></head><body>oi</body></html>", "http://x.com")
        self.assertIn("não usa HTTPS", problems)
        self.assertFalse(facts["viewport"])
        ok_html = ('<html><head><title>Ok</title><meta name="viewport" content="width=device-width"></head><body>'
                   + "texto " * 100 + "<a href='tel:+551836410000'>ligar</a></body></html>")
        self.assertEqual(analyze_html(ok_html, "https://x.com")[0], [])

    def test_links_internos(self):
        html = '<a href="/a">a</a><a href="https://outro.com/b">b</a><a href="#x">c</a><a href="/c">c</a>'
        self.assertEqual(internal_links(html, "https://x.com/"), ["https://x.com/a", "https://x.com/c"])


if __name__ == "__main__":
    unittest.main()
