import tempfile
import unittest
from pathlib import Path

import pandas as pd

import exporters
from models import Company


def sample():
    return [
        Company(nome="A", telefone="1836410000", prioridade="alta", site=""),
        Company(nome="B", telefone="", prioridade="baixa", site="https://b.com", latitude=-21.1, longitude=-50.2),
        Company(nome="C", telefone="1899990000", prioridade="média", site=""),
    ]


class ExportTests(unittest.TestCase):
    def test_filtros(self):
        names = lambda mode: [c.nome for c in exporters.filter_companies(sample(), mode)]
        self.assertEqual(names("todos"), ["A", "B", "C"])
        self.assertEqual(names("sem_site"), ["A", "C"])
        self.assertEqual(names("com_telefone"), ["A", "C"])
        self.assertEqual(names("alta_prioridade"), ["A"])

    def test_csv_utf8_e_nao_informado(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = exporters.export_csv(sample(), Path(tmp) / "x.csv")
            df = pd.read_csv(path, encoding="utf-8-sig", dtype=str, keep_default_na=False)
        self.assertEqual(df.loc[0, "Site oficial"], "não informado")
        self.assertEqual(df.loc[1, "Telefone comercial"], "não informado")
        self.assertEqual(df.loc[1, "Latitude"], "-21.100000")

    def test_excel(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = exporters.export_excel(sample(), Path(tmp) / "x.xlsx")
            df = pd.read_excel(path, dtype=str)
        self.assertEqual(len(df), 3)
        self.assertIn("Motivo da oportunidade", df.columns)


if __name__ == "__main__":
    unittest.main()
