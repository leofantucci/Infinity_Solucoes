"""Configurações lidas de variáveis de ambiente / arquivo .env."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _get(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _num(name: str, default: float, cast=float) -> float:
    try:
        return cast(_get(name, str(default)))
    except ValueError:
        return default


def _bool(name: str, default: bool = False) -> bool:
    return _get(name, str(default)).lower() in {"1", "true", "sim", "yes", "on"}


def _path(name: str, default: str) -> Path:
    p = Path(_get(name, default)).expanduser()
    return p if p.is_absolute() else BASE_DIR / p


@dataclass(frozen=True)
class Settings:
    default_city: str
    default_state: str
    default_country: str
    nominatim_url: str
    nominatim_user_agent: str
    nominatim_email: str
    overpass_urls: tuple
    overpass_min_interval: float
    google_api_key: str
    request_delay: float
    request_timeout: int
    max_retries: int
    cache_ttl_hours: int
    page_load_timeout: int
    firefox_headless: bool
    firefox_binary: str
    geckodriver_path: str
    http_user_agent: str
    db_path: Path
    categories_file: Path


def load_settings() -> Settings:
    return Settings(
        default_city=_get("DEFAULT_CITY", "Birigui"),
        default_state=_get("DEFAULT_STATE", "São Paulo"),
        default_country=_get("DEFAULT_COUNTRY", "Brasil"),
        nominatim_url="https://nominatim.openstreetmap.org/search",
        nominatim_user_agent=_get("NOMINATIM_USER_AGENT", "LocalLeadFinder/1.0 (uso pessoal)"),
        nominatim_email=_get("NOMINATIM_EMAIL"),
        # Endpoints alternativos: se um estiver sobrecarregado (HTTP 429/502/503/504),
        # o provider tenta os próximos sem depender de um único servidor.
        overpass_urls=(
            "https://overpass.kumi.systems/api/interpreter",
            "https://overpass.private.coffee/api/interpreter",
            "https://overpass-api.de/api/interpreter",
        ),
        overpass_min_interval=5.0,
        google_api_key=_get("GOOGLE_PLACES_API_KEY"),
        request_delay=max(_num("REQUEST_DELAY_SECONDS", 2.0), 1.0),
        request_timeout=int(_num("REQUEST_TIMEOUT_SECONDS", 20, int)),
        max_retries=int(_num("MAX_RETRIES", 2, int)),
        cache_ttl_hours=int(_num("CACHE_TTL_HOURS", 72, int)),
        page_load_timeout=int(_num("PAGE_LOAD_TIMEOUT_SECONDS", 30, int)),
        firefox_headless=_bool("FIREFOX_HEADLESS", False),
        firefox_binary=_get("FIREFOX_BINARY"),
        geckodriver_path=_get("GECKODRIVER_PATH"),
        http_user_agent=_get("HTTP_USER_AGENT", "LocalLeadFinder/1.0 (verificação de presença digital; uso pessoal)"),
        db_path=_path("DB_PATH", "data/locallead.sqlite3"),
        categories_file=_path("CATEGORIES_FILE", "data/categories.json"),
    )
