"""Exportação para CSV (UTF-8) e Excel (XLSX)."""
from __future__ import annotations

from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from models import NAO_INFORMADO, PRIORIDADE_ALTA, Company

EXPORT_FILTERS = {
    "todos": "Todos os resultados",
    "sem_site": "Apenas empresas sem site encontrado",
    "com_telefone": "Apenas empresas com telefone",
    "alta_prioridade": "Apenas oportunidades de alta prioridade",
}

COLUMNS = [
    ("prioridade", "Prioridade"), ("nome", "Nome comercial"), ("categoria", "Categoria"),
    ("telefone", "Telefone comercial"), ("site", "Site oficial"), ("instagram", "Instagram"),
    ("facebook", "Facebook"), ("youtube", "YouTube"), ("google_maps_url", "Google Maps"),
    ("endereco", "Endereço completo"), ("cidade", "Cidade"), ("estado", "Estado"),
    ("latitude", "Latitude"), ("longitude", "Longitude"), ("status_site", "Status do site"),
    ("status_redes", "Status das redes sociais"), ("motivo", "Motivo da oportunidade"),
    ("analise_site", "Análise do site (critérios observáveis)"), ("redes_candidatas", "Perfis candidatos (não confirmados)"),
    ("fonte", "Fonte original"), ("fonte_url", "URL da fonte"), ("verificacao_url", "URL da verificação"),
    ("data_pesquisa", "Data da pesquisa"), ("verificado_em", "Verificado em"), ("ativo", "Empresa ativa"),
]
_LINK_HEADERS = {"Site oficial", "Instagram", "Facebook", "YouTube", "Google Maps", "URL da fonte", "URL da verificação"}


def filter_companies(companies: list[Company], mode: str) -> list[Company]:
    if mode == "sem_site":
        return [c for c in companies if not c.site]
    if mode == "com_telefone":
        return [c for c in companies if c.telefone]
    if mode == "alta_prioridade":
        return [c for c in companies if c.prioridade == PRIORIDADE_ALTA]
    return list(companies)


def _cell(attr: str, value) -> str:
    if attr == "ativo":
        return "Sim" if value else "Não"
    if value is None or value == "":
        return NAO_INFORMADO
    if attr in ("latitude", "longitude"):
        return f"{float(value):.6f}"
    return str(value)


def to_dataframe(companies: list[Company]) -> pd.DataFrame:
    rows = [{header: _cell(attr, getattr(c, attr)) for attr, header in COLUMNS} for c in companies]
    return pd.DataFrame(rows, columns=[h for _, h in COLUMNS])


def export_csv(companies: list[Company], path: str | Path) -> Path:
    path = Path(path)
    # utf-8-sig = UTF-8 com BOM, para o Excel/LibreOffice reconhecerem os acentos
    to_dataframe(companies).to_csv(path, index=False, encoding="utf-8-sig")
    return path


def export_excel(companies: list[Company], path: str | Path) -> Path:
    path = Path(path)
    df = to_dataframe(companies)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Leads")
        ws = writer.sheets["Leads"]
        fill = PatternFill("solid", fgColor="1F4E78")
        for cell in ws[1]:
            cell.font, cell.fill = Font(bold=True, color="FFFFFF"), fill
            cell.alignment = Alignment(vertical="center", wrap_text=True)
        ws.freeze_panes = "C2"
        ws.auto_filter.ref = ws.dimensions
        colors = {"alta": "C6EFCE", "média": "FFEB9C", "baixa": "EDEDED"}
        for idx, header in enumerate(df.columns, 1):
            letter = get_column_letter(idx)
            longest = max([len(str(header))] + [len(str(v)) for v in df[header]])
            ws.column_dimensions[letter].width = min(max(12, longest + 2), 60)
            for row in range(2, len(df) + 2):
                cell = ws.cell(row=row, column=idx)
                if header in _LINK_HEADERS and str(cell.value).startswith("http"):
                    cell.hyperlink = str(cell.value)
                    cell.font = Font(color="0563C1", underline="single")
                if header == "Prioridade" and cell.value in colors:
                    cell.fill = PatternFill("solid", fgColor=colors[cell.value])
    return path
