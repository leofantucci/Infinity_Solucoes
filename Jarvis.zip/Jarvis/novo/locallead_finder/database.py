"""Armazenamento SQLite: empresas (sem duplicatas) e cache de consultas."""
from __future__ import annotations

import sqlite3
import threading
import time
from dataclasses import fields
from pathlib import Path

from models import COMPANY_FIELDS, Company
from services.dedupe import fingerprint, id_key, merge_into, name_phone_key

_COLS = [n for n in COMPANY_FIELDS if n != "id"]
_REAL = {"latitude", "longitude"}
_INT = {"ativo"}


def _sql_type(name: str) -> str:
    return "REAL" if name in _REAL else "INTEGER" if name in _INT else "TEXT"


class Database:
    def __init__(self, path: Path | str) -> None:
        if str(path) != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        self._create()

    def _create(self) -> None:
        cols = ", ".join(f"{n} {_sql_type(n)}" for n in _COLS)
        with self._lock, self._conn:
            self._conn.execute(
                f"CREATE TABLE IF NOT EXISTS companies (id INTEGER PRIMARY KEY AUTOINCREMENT, {cols}, "
                "k_id TEXT, k_finger TEXT, k_namephone TEXT)")
            for k in ("k_id", "k_finger", "k_namephone"):
                self._conn.execute(f"CREATE INDEX IF NOT EXISTS idx_{k} ON companies({k})")
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, created REAL)")

    # ---------- conversão ----------
    @staticmethod
    def _to_company(row: sqlite3.Row) -> Company:
        data = {n: row[n] for n in COMPANY_FIELDS}
        data["ativo"] = bool(data["ativo"])
        for k, v in data.items():
            if v is None and k not in _REAL and k != "id":
                data[k] = ""
        return Company(**data)

    @staticmethod
    def _values(c: Company) -> list:
        return [int(getattr(c, n)) if n in _INT else getattr(c, n) for n in _COLS]

    # ---------- empresas ----------
    def _find(self, c: Company) -> sqlite3.Row | None:
        keys = {"k_id": id_key(c), "k_finger": fingerprint(c), "k_namephone": name_phone_key(c)}
        clauses = [f"{col}=?" for col, v in keys.items() if v]
        if not clauses:
            return None
        params = [v for v in keys.values() if v]
        return self._conn.execute(
            f"SELECT * FROM companies WHERE {' OR '.join(clauses)} LIMIT 1", params).fetchone()

    def upsert(self, c: Company) -> tuple[int, bool]:
        """Insere a empresa ou mescla com a existente. Retorna (id, é_nova)."""
        with self._lock, self._conn:
            row = self._find(c)
            if row is not None:
                existing = self._to_company(row)
                merge_into(existing, c)
                existing.data_pesquisa = c.data_pesquisa or existing.data_pesquisa
                self._update(existing)
                return existing.id, False
            placeholders = ", ".join("?" for _ in _COLS)
            cur = self._conn.execute(
                f"INSERT INTO companies ({', '.join(_COLS)}, k_id, k_finger, k_namephone) "
                f"VALUES ({placeholders}, ?, ?, ?)",
                self._values(c) + [id_key(c), fingerprint(c), name_phone_key(c)])
            c.id = cur.lastrowid
            return c.id, True

    def _update(self, c: Company) -> None:
        sets = ", ".join(f"{n}=?" for n in _COLS)
        self._conn.execute(
            f"UPDATE companies SET {sets}, k_id=?, k_finger=?, k_namephone=? WHERE id=?",
            self._values(c) + [id_key(c), fingerprint(c), name_phone_key(c), c.id])

    def save(self, c: Company) -> None:
        with self._lock, self._conn:
            self._update(c)

    def get_many(self, ids: list[int]) -> list[Company]:
        if not ids:
            return []
        with self._lock:
            marks = ",".join("?" for _ in ids)
            rows = self._conn.execute(f"SELECT * FROM companies WHERE id IN ({marks})", ids).fetchall()
        by_id = {r["id"]: self._to_company(r) for r in rows}
        return [by_id[i] for i in ids if i in by_id]

    def all(self) -> list[Company]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM companies ORDER BY id").fetchall()
        return [self._to_company(r) for r in rows]

    # ---------- cache ----------
    def cache_get(self, key: str, ttl_hours: float) -> str | None:
        with self._lock:
            row = self._conn.execute("SELECT value, created FROM cache WHERE key=?", (key,)).fetchone()
        if row and time.time() - row["created"] < ttl_hours * 3600:
            return row["value"]
        return None

    def cache_set(self, key: str, value: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("INSERT OR REPLACE INTO cache (key, value, created) VALUES (?,?,?)",
                               (key, value, time.time()))

    def close(self) -> None:
        with self._lock:
            self._conn.close()
