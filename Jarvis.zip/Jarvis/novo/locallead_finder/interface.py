"""Interface gráfica Tkinter."""
from __future__ import annotations

import queue
import threading
import tkinter as tk
import webbrowser
from datetime import datetime
from tkinter import filedialog, messagebox, ttk

import exporters
from models import SearchParams
from services import pipeline
from services.dedupe import normalize_text
from utils import Cancelled, CancelToken, ProviderError

SITE_FILTERS = {"Todos": "todos", "Com site": "com_site", "Sem site conhecido": "sem_site"}
TREE_COLS = [("prioridade", "Prioridade", 80), ("nome", "Nome", 220), ("categoria", "Categoria", 120),
             ("telefone", "Telefone", 120), ("site", "Site", 200), ("status_site", "Status do site", 230),
             ("status_redes", "Redes sociais", 210)]


class App(tk.Tk):
    def __init__(self, settings, db, categories) -> None:
        super().__init__()
        self.settings, self.db, self.categories = settings, db, categories
        self.title("LocalLead Finder — empresas sem site")
        self.geometry("1180x780")
        self.minsize(980, 640)
        self.msgs: queue.Queue = queue.Queue()
        self.cancel = CancelToken()
        self.worker: threading.Thread | None = None
        self.current_ids: list[int] = []
        self._build()
        self.after(100, self._poll)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------- construção ----------
    def _build(self) -> None:
        s = self.settings
        self.v = {
            "keyword": tk.StringVar(value="dentista"), "city": tk.StringVar(value=s.default_city),
            "state": tk.StringVar(value=s.default_state), "country": tk.StringVar(value=s.default_country),
            "radius": tk.StringVar(value="5"), "max": tk.StringVar(value="50"),
            "source": tk.StringVar(value=pipeline.SOURCE_OSM), "site": tk.StringVar(value="Todos"),
            "phone": tk.BooleanVar(value=False), "browser": tk.BooleanVar(value=True),
            "headless": tk.BooleanVar(value=s.firefox_headless),
            "export": tk.StringVar(value=exporters.EXPORT_FILTERS["todos"]),
        }
        form = ttk.LabelFrame(self, text="Pesquisa", padding=8)
        form.pack(fill="x", padx=10, pady=(10, 4))
        def field(label, widget, row, col, **grid):
            ttk.Label(form, text=label).grid(row=row, column=col * 2, sticky="e", padx=(8, 3), pady=3)
            widget.grid(row=row, column=col * 2 + 1, sticky="we", pady=3, **grid)
        self.kw_box = ttk.Combobox(form, textvariable=self.v["keyword"], values=self.categories.labels(), width=26)
        field("Segmento:", self.kw_box, 0, 0)
        field("Cidade:", ttk.Entry(form, textvariable=self.v["city"], width=22), 0, 1)
        field("Estado:", ttk.Entry(form, textvariable=self.v["state"], width=18), 0, 2)
        field("País:", ttk.Entry(form, textvariable=self.v["country"], width=14), 0, 3)
        field("Raio (km):", ttk.Spinbox(form, from_=1, to=50, textvariable=self.v["radius"], width=8), 1, 0)
        field("Máx. resultados:", ttk.Spinbox(form, from_=1, to=500, textvariable=self.v["max"], width=8), 1, 1)
        field("Fonte:", ttk.Combobox(form, textvariable=self.v["source"], state="readonly", width=20,
                                     values=[pipeline.SOURCE_OSM, pipeline.SOURCE_GOOGLE]), 1, 2)
        field("Site:", ttk.Combobox(form, textvariable=self.v["site"], state="readonly", width=18,
                                    values=list(SITE_FILTERS)), 1, 3)
        opts = ttk.Frame(form)
        opts.grid(row=2, column=0, columnspan=8, sticky="w", pady=(4, 0))
        ttk.Checkbutton(opts, text="Somente com telefone", variable=self.v["phone"]).pack(side="left", padx=6)
        ttk.Checkbutton(opts, text="Usar Firefox na verificação", variable=self.v["browser"]).pack(side="left", padx=6)
        ttk.Checkbutton(opts, text="Firefox sem janela", variable=self.v["headless"]).pack(side="left", padx=6)
        ttk.Button(opts, text="Adicionar categoria…", command=self._add_category).pack(side="left", padx=12)

        bar = ttk.Frame(self, padding=(10, 4))
        bar.pack(fill="x")
        self.btn_search = ttk.Button(bar, text="Pesquisar empresas", command=self._search)
        self.btn_verify = ttk.Button(bar, text="Verificar sites e redes sociais", command=self._verify)
        self.btn_cancel = ttk.Button(bar, text="Cancelar", command=self._cancel, state="disabled")
        for b in (self.btn_search, self.btn_verify, self.btn_cancel):
            b.pack(side="left", padx=4)
        ttk.Button(bar, text="Exportar Excel", command=lambda: self._export("xlsx")).pack(side="right", padx=4)
        ttk.Button(bar, text="Exportar CSV", command=lambda: self._export("csv")).pack(side="right", padx=4)
        ttk.Combobox(bar, textvariable=self.v["export"], state="readonly", width=38,
                     values=list(exporters.EXPORT_FILTERS.values())).pack(side="right", padx=4)
        ttk.Label(bar, text="Exportar:").pack(side="right")

        self.progress = ttk.Progressbar(self, mode="determinate")
        self.progress.pack(fill="x", padx=12, pady=2)

        panes = ttk.PanedWindow(self, orient="vertical")
        panes.pack(fill="both", expand=True, padx=10, pady=4)
        frame = ttk.Frame(panes)
        self.tree = ttk.Treeview(frame, columns=[c[0] for c in TREE_COLS], show="headings", height=14)
        for key, title, width in TREE_COLS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w")
        sb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", self._open_row)
        for tag, color in (("alta", "#d4f4dd"), ("média", "#fff3c4"), ("baixa", "#efefef")):
            self.tree.tag_configure(tag, background=color)
        panes.add(frame, weight=3)
        logf = ttk.LabelFrame(panes, text="Logs (duplo clique em uma linha abre o site ou a fonte)")
        self.log_box = tk.Text(logf, height=9, state="disabled", wrap="word")
        lsb = ttk.Scrollbar(logf, orient="vertical", command=self.log_box.yview)
        self.log_box.configure(yscrollcommand=lsb.set)
        self.log_box.pack(side="left", fill="both", expand=True)
        lsb.pack(side="right", fill="y")
        panes.add(logf, weight=1)
        self._log("Pronto. Informe o segmento e a cidade e clique em 'Pesquisar empresas'.")

    # ---------- infraestrutura de threads ----------
    def _log(self, text: str) -> None:
        self.log_box.configure(state="normal")
        self.log_box.insert("end", f"[{datetime.now():%H:%M:%S}] {text}\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _poll(self) -> None:
        try:
            while True:
                kind, *data = self.msgs.get_nowait()
                if kind == "log":
                    self._log(data[0])
                elif kind == "progress":
                    done, total = data
                    if total == 0:
                        self.progress.configure(mode="indeterminate")
                        self.progress.start(12)
                    else:
                        self.progress.stop()
                        self.progress.configure(mode="determinate", maximum=total, value=done)
                elif kind == "ids":
                    self.current_ids = data[0]
                elif kind == "done":
                    self._finish()
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _busy(self, busy: bool) -> None:
        self.btn_search.configure(state="disabled" if busy else "normal")
        self.btn_verify.configure(state="disabled" if busy else "normal")
        self.btn_cancel.configure(state="normal" if busy else "disabled")

    def _finish(self) -> None:
        self.progress.stop()
        self.progress.configure(mode="determinate", value=0)
        self._busy(False)
        self._refresh_table()

    def _run(self, target) -> None:
        if self.worker and self.worker.is_alive():
            return
        self.cancel = CancelToken()
        self._busy(True)
        log = lambda m: self.msgs.put(("log", m))
        progress = lambda d, t: self.msgs.put(("progress", d, t))

        def job() -> None:
            try:
                target(self.cancel, log, progress)
            except Cancelled:
                log("Operação cancelada.")
            except ProviderError as exc:
                log(f"ERRO: {exc}")
            except Exception as exc:  # nunca deixar a thread morrer em silêncio
                log(f"ERRO inesperado: {type(exc).__name__}: {exc}")
            finally:
                self.msgs.put(("done",))

        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    # ---------- ações ----------
    def _params(self) -> SearchParams | None:
        try:
            radius, maximum = float(self.v["radius"].get().replace(",", ".")), int(self.v["max"].get())
            if radius <= 0 or maximum <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Dados inválidos", "Raio e quantidade máxima devem ser números positivos.")
            return None
        kw, city = self.v["keyword"].get().strip(), self.v["city"].get().strip()
        if not kw or not city:
            messagebox.showerror("Dados incompletos", "Informe o segmento e a cidade.")
            return None
        return SearchParams(kw, city, self.v["state"].get().strip(), self.v["country"].get().strip(), radius, maximum)

    def _search(self) -> None:
        params = self._params()
        if not params:
            return
        source = self.v["source"].get()
        if source == pipeline.SOURCE_GOOGLE and not self.settings.google_api_key:
            messagebox.showerror("Chave ausente", "Defina GOOGLE_PLACES_API_KEY no arquivo .env "
                                 "(veja o README) ou escolha OpenStreetMap.")
            return
        site_filter, only_phone = SITE_FILTERS[self.v["site"].get()], self.v["phone"].get()

        def target(cancel, log, progress):
            ids = pipeline.run_search(self.settings, self.db, self.categories, params, source,
                                      site_filter, only_phone, cancel, log, progress)
            self.msgs.put(("ids", ids))
        self._run(target)

    def _verify(self) -> None:
        if not self.current_ids:
            messagebox.showinfo("Nada a verificar", "Faça uma pesquisa primeiro.")
            return
        ids, use_browser, headless = list(self.current_ids), self.v["browser"].get(), self.v["headless"].get()
        self._run(lambda cancel, log, progress: pipeline.run_verification(
            self.settings, self.db, ids, cancel, log, progress, use_browser, headless))

    def _cancel(self) -> None:
        self.cancel.cancel()
        self._log("Cancelando... aguarde a operação atual terminar.")

    def _refresh_table(self) -> None:
        self.tree.delete(*self.tree.get_children())
        for c in self.db.get_many(self.current_ids):
            values = [getattr(c, k) or "não informado" for k, _, _ in TREE_COLS]
            self.tree.insert("", "end", iid=str(c.id), values=values, tags=(c.prioridade,))

    def _open_row(self, _event) -> None:
        sel = self.tree.selection()
        if not sel:
            return
        c = self.db.get_many([int(sel[0])])[0]
        url = c.site or c.google_maps_url or c.fonte_url
        if url:
            webbrowser.open(url)

    def _export(self, kind: str) -> None:
        companies = self.db.get_many(self.current_ids)
        if not companies:
            messagebox.showinfo("Nada a exportar", "Faça uma pesquisa primeiro.")
            return
        mode = next(k for k, v in exporters.EXPORT_FILTERS.items() if v == self.v["export"].get())
        selected = exporters.filter_companies(companies, mode)
        if not selected:
            messagebox.showinfo("Nada a exportar", "Nenhuma empresa atende ao filtro de exportação escolhido.")
            return
        default = f"leads_{normalize_text(self.v['keyword'].get()).replace(' ', '_')}_{datetime.now():%Y%m%d}.{kind}"
        path = filedialog.asksaveasfilename(defaultextension=f".{kind}", initialfile=default,
                                            filetypes=[("CSV" if kind == "csv" else "Excel", f"*.{kind}")])
        if not path:
            return
        try:
            (exporters.export_csv if kind == "csv" else exporters.export_excel)(selected, path)
        except OSError as exc:
            messagebox.showerror("Erro ao salvar", f"Não foi possível gravar o arquivo:\n{exc}")
            return
        self._log(f"{len(selected)} empresa(s) exportada(s) para {path}")

    def _add_category(self) -> None:
        win = tk.Toplevel(self)
        win.title("Adicionar categoria")
        win.transient(self)
        entries = {}
        rows = [("name", "Nome (ex.: Pet shop):", ""),
                ("aliases", "Palavras-chave (separe por vírgula):", ""),
                ("tags", "Tags OSM (E = vírgula, OU = ponto e vírgula):", "shop=pet")]
        for i, (key, label, default) in enumerate(rows):
            ttk.Label(win, text=label).grid(row=i, column=0, sticky="e", padx=8, pady=4)
            entries[key] = ttk.Entry(win, width=46)
            entries[key].insert(0, default)
            entries[key].grid(row=i, column=1, padx=8, pady=4)

        def save() -> None:
            name = entries["name"].get().strip()
            groups = [[t.strip() for t in g.split(",") if t.strip()] for g in entries["tags"].get().split(";")]
            groups = [g for g in groups if g]
            if not name or not groups:
                messagebox.showerror("Dados incompletos", "Informe o nome e ao menos uma tag.", parent=win)
                return
            try:
                self.categories.add(name, name, [a for a in entries["aliases"].get().split(",")] + [name], groups)
            except ValueError as exc:
                messagebox.showerror("Tag inválida", str(exc), parent=win)
                return
            self.kw_box.configure(values=self.categories.labels())
            self._log(f"Categoria '{name}' adicionada.")
            win.destroy()
        ttk.Button(win, text="Salvar", command=save).grid(row=3, column=1, sticky="e", padx=8, pady=8)

    def _on_close(self) -> None:
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno("Operação em andamento", "Cancelar e sair?"):
                return
            self.cancel.cancel()
            self.worker.join(timeout=5)
        self.db.close()
        self.destroy()
