"""Modelos de dados e constantes de status."""
from __future__ import annotations

from dataclasses import dataclass, field, fields

NAO_INFORMADO = "não informado"

# Status da verificação de site (exatamente os estados pedidos)
SITE_ENCONTRADO = "Site oficial encontrado"
SITE_NAO_INFORMADO = "Site não informado pela fonte"
SITE_NENHUM = "Nenhum site encontrado após verificação"
SITE_INCONCLUSIVO = "Verificação inconclusiva"

# Status da verificação de redes sociais
REDES_NAO_VERIFICADAS = "Não verificadas"
REDES_NO_SITE = "Encontradas no site oficial"
REDES_FONTE = "Informadas pela fonte"
REDES_BUSCA = "Confirmadas por busca pública"
REDES_CANDIDATOS = "Candidatos encontrados (revisar manualmente)"
REDES_NENHUMA = "Nenhuma rede social encontrada"

PRIORIDADE_ALTA = "alta"
PRIORIDADE_MEDIA = "média"
PRIORIDADE_BAIXA = "baixa"


@dataclass
class SearchParams:
    keyword: str
    city: str
    state: str
    country: str
    radius_km: float = 5.0
    max_results: int = 50


@dataclass
class Company:
    nome: str = ""
    categoria: str = ""
    endereco: str = ""
    cidade: str = ""
    estado: str = ""
    latitude: float | None = None
    longitude: float | None = None
    telefone: str = ""
    site: str = ""
    instagram: str = ""
    facebook: str = ""
    youtube: str = ""
    google_maps_url: str = ""
    fonte: str = ""
    source_id: str = ""
    fonte_url: str = ""
    data_pesquisa: str = ""
    status_site: str = SITE_NAO_INFORMADO
    status_redes: str = REDES_NAO_VERIFICADAS
    verificacao_url: str = ""
    analise_site: str = ""
    site_problemas: str = ""      # problemas observáveis separados por " | "
    redes_candidatas: str = ""    # URLs não confirmadas, só para revisão manual
    motivo: str = ""
    prioridade: str = ""
    ativo: bool = True
    verificado_em: str = ""
    id: int | None = None


COMPANY_FIELDS = [f.name for f in fields(Company)]
