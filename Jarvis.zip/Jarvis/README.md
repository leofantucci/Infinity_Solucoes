# LocalLead Finder

Busca empresas por segmento e localização, identifica as que **não têm site oficial conhecido** e exporta para CSV e Excel. Feito para prospectar clientes de criação de landing pages.

A interface é um **painel web local no estilo HUD/J.A.R.V.I.S.**: o programa sobe um servidor em `127.0.0.1` e abre o painel no **Firefox**. Nada é publicado na internet.

- Fonte gratuita: **OpenStreetMap** (Nominatim + Overpass), sem chave.
- Fonte opcional: **Google Places API (New)**, com a sua chave.
- Verificação de site e redes sociais com **Requests + BeautifulSoup** e, quando necessário, **Firefox + Selenium**.
- Resultados em **SQLite** (sem duplicatas) e exportação em CSV UTF-8 e XLSX.

> **Estado dos testes:** classificação, deduplicação, redes sociais, parsing do OSM/Google/DuckDuckGo, exportação, a API do servidor local (token, host, exportação) e o fluxo completo (com rede e navegador simulados) têm testes automatizados. O visual do painel em um Firefox real, o Selenium com Firefox e as APIs públicas dependem do seu ambiente e precisam ser validados na sua máquina (veja "Solução de problemas").

---

## 1. Instalação no Manjaro Linux

### 1.1 Verifique o ambiente

```bash
python --version          # precisa ser 3.10 ou superior
firefox --version
geckodriver --version
```

Se algum comando falhar, instale os pacotes abaixo.

### 1.2 Pacotes do sistema

```bash
sudo pacman -Syu
sudo pacman -S --needed python python-pip firefox geckodriver
```

- O painel web **não precisa de Tkinter**. Só instale `tk` se quiser a interface antiga (`python main.py --tk`).
- Use o Firefox e o geckodriver **dos repositórios oficiais**. Firefox instalado por Snap/Flatpak costuma não funcionar com o geckodriver (sandbox).
- O Selenium 4 também consegue baixar o driver sozinho (Selenium Manager), mas isso exige internet; com o pacote `geckodriver` instalado ele é usado diretamente.

### 1.3 Ambiente virtual e dependências Python

O Manjaro bloqueia `pip install` global (PEP 668), então use um ambiente virtual:

```bash
cd locallead_finder
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python main.py
```

O Firefox abre em `http://127.0.0.1:8765/`. Nas próximas vezes: `source .venv/bin/activate && python main.py`.

Opções: `--port 9000` (outra porta), `--no-open` (não abrir o navegador; acesse a URL manualmente), `--tk` (interface Tkinter antiga). Para encerrar, use o botão **Encerrar sistema** no painel ou `Ctrl+C` no terminal.

> O Selenium abre uma **segunda janela do Firefox** (perfil temporário) só para as verificações. O painel continua na sua aba.

### 1.4 Testes

```bash
python -m unittest discover -s tests -t . -v
```

---

## 2. Configuração (`.env`)

Edite o `.env` criado a partir do `.env.example`. Os principais campos:

| Variável | Para que serve |
|---|---|
| `DEFAULT_CITY`, `DEFAULT_STATE`, `DEFAULT_COUNTRY` | Valores iniciais da interface (padrão: Birigui, São Paulo, Brasil). Também dá para trocar direto na tela. |
| `NOMINATIM_EMAIL` | **Recomendado:** seu e-mail de contato, exigido pela política de uso do Nominatim. |
| `GOOGLE_PLACES_API_KEY` | Chave da Google Places API (opcional). |
| `REQUEST_DELAY_SECONDS` | Intervalo mínimo entre requisições ao mesmo servidor (mínimo efetivo: 1 s). |
| `REQUEST_TIMEOUT_SECONDS`, `MAX_RETRIES` | Timeout e número de novas tentativas em falhas temporárias. |
| `CACHE_TTL_HOURS` | Por quanto tempo reutilizar respostas já obtidas (evita consultas repetidas). |
| `FIREFOX_HEADLESS` | `true` para o Firefox rodar sem janela. Por padrão você **vê** o navegador trabalhando. |
| `FIREFOX_BINARY`, `GECKODRIVER_PATH` | Caminhos manuais, se o autodetectado não servir. |

O `.env` e a chave **nunca** vão para o código nem para as planilhas exportadas.

---

## 3. Usando o modo gratuito (OpenStreetMap)

1. Rode `python main.py` (o painel abre no Firefox).
2. Escolha ou digite o **segmento** (ex.: `dentista`), confirme **cidade/estado/país**, defina **raio** e **máximo de resultados**.
3. Fonte: **OpenStreetMap**. Filtros opcionais: site (todos / com site / sem site conhecido) e "somente com telefone".
4. Clique em **Pesquisar empresas**. Os resultados aparecem na tabela, coloridos por prioridade.
5. Clique em **Verificar sites e redes sociais**. O Firefox abre e você acompanha o que está sendo verificado. **Cancelar** interrompe com segurança; o que já foi verificado fica salvo.
6. Escolha o filtro de exportação e clique em **CSV** ou **Excel**; o arquivo vai para a pasta de downloads do Firefox.

Clique em uma linha da tabela para ver endereço, motivo da classificação, análise do site e fontes; os botões SITE / IG / FB / YT / MAPS / FONTE abrem os links para conferência manual. **Carregar banco local** traz de volta tudo o que já foi pesquisado.

### Exemplos de pesquisa

| Segmento | Cidade | Raio | O que acontece |
|---|---|---|---|
| `dentista` | Birigui / São Paulo / Brasil | 5 km | `amenity=dentist` e `healthcare=dentist` |
| `mercado` | Birigui / São Paulo / Brasil | 8 km | `shop=supermarket` e `shop=convenience` |
| `dermatologista` | Birigui / São Paulo / Brasil | 15 km | `healthcare=doctor` + especialidade dermatologia, mais busca pelo nome "dermat" |

Para outras cidades ou segmentos, basta trocar os campos na tela.

### Adicionando categorias sem mexer no código

- Pelo link **+ adicionar categoria** do painel (nome, palavras-chave e tags OSM; vírgula = E, ponto e vírgula = OU), ou
- Editando `data/categories.json`.

Se o segmento digitado não estiver mapeado, o app busca pelo nome do estabelecimento (menos preciso) e avisa no log.

> **Limitação importante do OpenStreetMap:** os dados são colaborativos e incompletos. Muitos negócios não estão cadastrados, e telefone/site frequentemente faltam. Campos ausentes ficam como "não informado"; nada é inventado.

---

## 4. Google Places API (opcional)

1. No [Google Cloud Console](https://console.cloud.google.com/), crie um projeto e ative o **faturamento**.
2. Ative a **Places API (New)**.
3. Crie uma chave de API e restrinja-a à Places API (e, se possível, ao seu IP).
4. Coloque no `.env`: `GOOGLE_PLACES_API_KEY=sua_chave`.
5. Na interface, escolha a fonte **Google Places API**.

O app usa o Text Search da API oficial e pede só os campos necessários: id, nome, endereço, localização, link do Google Maps, telefone, site e status de funcionamento.

**Custos:** telefone e site pertencem a níveis de cobrança mais altos que nome e endereço, e preços e cotas gratuitas mudam. Consulte a documentação e a tabela de preços vigentes antes de pesquisar em volume.

O app **não** raspa o HTML do Google Maps e não tenta contornar CAPTCHAs, limites ou bloqueios.

---

## 5. Como a verificação funciona

Para cada empresa:

1. **A fonte trouxe um site?** O app o acessa com Requests (e com o Firefox, se a página depender de JavaScript), procura links de Instagram, Facebook e YouTube e avalia critérios observáveis: meta viewport (responsividade), HTTPS, contato visível, quantidade de conteúdo, título e links internos quebrados. Se o campo "site" for na verdade uma rede social, ele é tratado como perfil, não como site.
2. **Não trouxe site?** O app pesquisa o nome da empresa no DuckDuckGo pelo Firefox. Um resultado só é aceito como site oficial se houver mais de um indício independente (por exemplo, telefone da empresa na página junto com o nome, ou nome no título/domínio junto com a cidade). Diretórios, marketplaces e redes sociais nunca contam como site.
3. **Redes sociais encontradas na busca** só são gravadas se o texto do resultado trouxer o nome completo da empresa e a cidade ou o telefone. Os demais ficam em "Perfis candidatos (não confirmados)", para revisão manual. Perfis pessoais (`facebook.com/people/...`) são ignorados.
4. **CAPTCHA ou bloqueio:** o app para, registra "Verificação inconclusiva" e deixa para você revisar. Ele não tenta contornar nada e não faz login em contas.

### Status de site

| Status | Significado |
|---|---|
| Site oficial encontrado | A fonte informou ou a busca confirmou um site |
| Site não informado pela fonte | O campo veio vazio e a busca ainda não foi feita |
| Nenhum site encontrado após verificação | Busca feita, nenhum site associável à empresa |
| Verificação inconclusiva | Site inacessível, bloqueio, busca sem resultados legíveis ou candidatos que não puderam ser abertos |

### Prioridade comercial

- **Alta:** empresa ativa, com telefone e **nenhum site encontrado após verificação**.
- **Média:** presença digital incompleta e existência de site não confirmada (inclui "não informado pela fonte" e "inconclusiva"), ou site com 2 ou mais deficiências observáveis.
- **Baixa:** já possui site sem deficiências relevantes, ou empresa inativa.

Usar Instagram ou Facebook não classifica a empresa como "sem site".

---

## 6. Exportação

Filtros: todos os resultados, apenas sem site encontrado, apenas com telefone, apenas alta prioridade.

- **CSV:** UTF-8 com BOM (`utf-8-sig`), para o Excel e o LibreOffice acentuarem corretamente.
- **XLSX:** cabeçalho formatado, filtros, painel congelado, links clicáveis e prioridade colorida.
- Campos ausentes aparecem como `não informado`; as colunas incluem URL da fonte e URL da verificação.

Exemplo (com dados **fictícios**): `examples/exemplo_exportacao.csv` e `examples/exemplo_exportacao.xlsx`.

---

## 7. Estrutura

```
main.py                    inicialização (abre o painel no Firefox)
webapp.py                  servidor local 127.0.0.1 + API JSON
web/index.html             painel HUD (HTML/CSS/JS, sem dependências externas)
interface.py               interface Tkinter antiga (opcional: --tk)
config.py / .env           configurações
models.py                  dados e status
categories.py              categorias configuráveis (data/categories.json)
database.py                SQLite: empresas, deduplicação e cache
exporters.py               CSV e Excel
utils.py                   cancelamento, HTTP com tentativas e intervalos
providers/osm.py           Nominatim + Overpass
providers/google_places.py Google Places API (opcional)
browser/firefox.py         Selenium + Firefox
services/site_checker.py   verificação de site e redes
services/social_finder.py  links de Instagram/Facebook/YouTube
services/lead_classifier.py classificação comercial
services/dedupe.py         normalização e duplicatas
services/matching.py       regras conservadoras de associação
services/pipeline.py       orquestra pesquisa e verificação
tests/                     testes automatizados
```

---

## 8. Boas práticas e limites

- Segurança do painel: o servidor escuta só em `127.0.0.1`, exige um token aleatório a cada execução e confere o cabeçalho Host (contra páginas externas e DNS rebinding). Não exponha a porta na rede.
- Os intervalos entre requisições, o cache e o limite de resultados existem para não sobrecarregar Nominatim e Overpass. Não reduza o atraso abaixo do padrão.
- Respeite a LGPD ao usar os contatos: são dados comerciais públicos, mas a abordagem comercial (telefone, WhatsApp, e-mail) tem regras de consentimento e de opt-out.
- A ferramenta ajuda a **encontrar candidatos**. Confira manualmente os de alta prioridade antes de abordar.

## 9. Solução de problemas

| Mensagem / sintoma | O que fazer |
|---|---|
| O painel não abriu sozinho | Acesse a URL mostrada no terminal; confirme `firefox` no PATH |
| `Nenhuma porta livre` / porta ocupada | Use `python main.py --port 9000` |
| Painel mostra "offline" | O servidor foi encerrado: rode `python main.py` de novo |
| `Tkinter não encontrado` (só com `--tk`) | `sudo pacman -S tk` |
| `Não foi possível iniciar o Firefox/geckodriver` | `sudo pacman -S firefox geckodriver`; evite Firefox via Snap/Flatpak; ajuste `FIREFOX_BINARY`/`GECKODRIVER_PATH` no `.env` |
| `Cidade não encontrada` | Confira a grafia de cidade, estado e país |
| `Overpass indisponível` | Servidor público sobrecarregado: aguarde alguns minutos (o resultado é guardado em cache quando funciona) |
| `Verificação inconclusiva` em várias empresas | Provável CAPTCHA do buscador ou site fora do ar: aguarde e verifique de novo, ou revise manualmente |
| Google: HTTP 403/400 | Confira a chave, se a Places API (New) está ativa e o faturamento do projeto |
