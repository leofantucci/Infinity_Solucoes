"""Interpretação e expansão local de categorias comerciais (sem IA paga).

Prioridade:
1. palavras-chave cadastradas no banco;
2. sinônimos cadastrados;
3. variações comerciais de um léxico local;
4. remoção de duplicatas/redundâncias e limite de consultas.
"""
from __future__ import annotations

import re

from services.dedupe import normalize_text

# Léxico local de variações comerciais. As chaves são comparadas sem acentos.
_LEXICON: dict[str, list[str]] = {
    "vidracaria": ["vidraçaria", "loja de vidros", "instalação de vidros", "vidros temperados",
                   "box para banheiro", "esquadrias de alumínio"],
    "vidro": ["vidraçaria", "loja de vidros", "instalação de vidros", "vidros temperados"],
    "clinica de estetica": ["clínica de estética", "estética facial", "estética corporal",
                            "clínica de beleza", "tratamento estético"],
    "estetica": ["clínica de estética", "estética facial", "estética corporal", "tratamento estético"],
    "energia solar": ["energia solar", "instalação de energia solar", "painéis solares",
                      "energia fotovoltaica", "empresa de energia solar"],
    "painel solar": ["energia solar", "instalação de energia solar", "painéis solares",
                     "energia fotovoltaica"],
    "marcenaria": ["marcenaria", "móveis planejados", "marceneiro", "móveis sob medida"],
    "moveis planejados": ["marcenaria", "móveis planejados", "móveis sob medida"],
    "ar condicionado": ["ar-condicionado", "instalação de ar-condicionado",
                        "manutenção de ar-condicionado", "climatização", "refrigeração"],
    "climatizacao": ["ar-condicionado", "instalação de ar-condicionado", "climatização", "refrigeração"],
    "desentupidora": ["desentupidora", "desentupimento", "limpa fossa", "desentupimento de esgoto"],
    "limpeza de estofado": ["limpeza de estofados", "lavagem de estofados",
                            "higienização de estofados", "limpeza de sofás"],
    "limpeza de sofa": ["limpeza de estofados", "lavagem de estofados", "limpeza de sofás"],
    "assistencia tecnica de computador": ["assistência técnica de computadores",
                                          "assistência técnica de informática",
                                          "manutenção de computadores", "conserto de notebooks",
                                          "reparo de computadores", "técnico em informática"],
    "assistencia tecnica": ["assistência técnica", "conserto de celular", "conserto de notebook",
                            "manutenção de computadores", "técnico em informática"],
    "pet shop": ["pet shop", "banho e tosa", "pet shop 24 horas", "clínica veterinária"],
    "banho e tosa": ["pet shop", "banho e tosa", "tosagem"],
    "clinica odontologica": ["dentista", "clínica odontológica", "consultório odontológico",
                             "ortodontista", "odontologia"],
    "dentista": ["dentista", "clínica odontológica", "consultório odontológico", "ortodontista"],
    "salao de beleza": ["salão de beleza", "cabeleireiro", "cabeleireira", "barbearia",
                        "manicure", "pedicure", "escovaria"],
    "academia": ["academia", "academia de ginástica", "personal trainer", "crossfit", "pilates"],
    "advogado": ["advogado", "escritório de advocacia", "advocacia", "assessoria jurídica"],
    "contabilidade": ["contabilidade", "escritório de contabilidade", "contador", "assessoria contábil"],
    "imobiliaria": ["imobiliária", "corretor de imóveis", "aluguel de imóveis", "venda de imóveis"],
    "construcao": ["construtora", "construção civil", "obra", "reforma"],
    "reforma": ["reforma", "construção civil", "pedreiro", "obra"],
}

_STOPWORDS = {"de", "da", "do", "das", "dos", "e", "em", "para", "com", "a", "o", "as", "os"}


def split_terms(raw: str) -> list[str]:
    """Separa termos por vírgula/ponto e vírgula/quebra de linha, preservando expressões compostas."""
    if not raw:
        return []
    out: list[str] = []
    seen: set[str] = set()
    for part in re.split(r"[,;\n]+", str(raw)):
        term = re.sub(r"\s+", " ", part).strip(" .-")
        if not term:
            continue
        key = normalize_text(term)
        if key and key not in seen:
            seen.add(key)
            out.append(term)
    return out


def _lexicon_variations(term: str) -> list[str]:
    norm = normalize_text(term)
    if not norm:
        return []
    best_key = ""
    for key in _LEXICON:
        if key == norm or (len(key) >= 4 and (key in norm or norm in key)):
            if len(key) > len(best_key):
                best_key = key
    return list(_LEXICON.get(best_key, [])) if best_key else []


def generate_variations(term: str) -> list[str]:
    """Variações comerciais locais, sem inventar segmentos fora do termo original."""
    term = re.sub(r"\s+", " ", str(term or "")).strip()
    if not term:
        return []
    return _lexicon_variations(term)


def _redundant(term: str, kept: list[str]) -> bool:
    norm = normalize_text(term)
    if not norm:
        return True
    if not any(ch.isalnum() for ch in norm):
        return True
    for other in kept:
        other_norm = normalize_text(other)
        if norm == other_norm:
            return True
        # Remove variações genéricas curtas que já estão contidas em outra consulta.
        if len(norm) >= 5 and norm in other_norm and len(other_norm) > len(norm) and \
                len(norm.split()) <= 2 and other_norm.split()[:len(norm.split())] == norm.split():
            return True
    return False


def expand_terms(raw: str, category=None, limit: int = 12) -> list[str]:
    """Monta a lista final de consultas, priorizando banco e depois o léxico local."""
    raw_terms = split_terms(raw)
    blocks: list[list[str]] = []
    if category is not None:
        known = {normalize_text(category.label), *map(normalize_text, category.keywords),
                 *map(normalize_text, category.synonyms)}
        raw_norm = normalize_text(raw)
        specific = bool(raw_norm and raw_norm not in known)
        cat_terms = [category.label, *category.keywords, *category.synonyms]
        blocks = [raw_terms, cat_terms] if specific else [cat_terms, raw_terms]
    else:
        blocks = [raw_terms]
    result: list[str] = []
    for block in blocks:
        for term in block:
            term = re.sub(r"\s+", " ", str(term or "")).strip(" .-")
            if not term:
                continue
            for candidate in [term, *generate_variations(term)]:
                candidate = re.sub(r"\s+", " ", str(candidate or "")).strip(" .-")
                if not candidate or _redundant(candidate, result):
                    continue
                result.append(candidate)
                if len(result) >= max(1, limit):
                    return result
    return result


def resolve_context(store, raw: str, limit: int = 12):
    """Retorna (categoria do banco ou None, rótulo, termos expandidos)."""
    category = store.resolve(raw) if store is not None else None
    label = category.label if category else (split_terms(raw)[0] if split_terms(raw) else str(raw or "").strip())
    terms = expand_terms(raw, category=category, limit=limit)
    return category, label, terms
