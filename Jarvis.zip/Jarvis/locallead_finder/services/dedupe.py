"""Normalização e deduplicação de empresas."""
from __future__ import annotations

import re
import unicodedata

from models import Company

_MERGE_FIELDS = [
    "categoria", "endereco", "cidade", "estado", "latitude", "longitude", "telefone",
    "email", "site", "instagram", "facebook", "youtube", "google_maps_url",
    "avaliacao_google", "fonte_url", "status_site", "status_redes", "verificacao_url",
    "analise_site", "site_problemas", "redes_candidatas", "motivo", "prioridade",
    "observacao", "verificado_em", "relevancia", "relevancia_motivo",
]

_GENERIC_NAME_TOKENS = {
    "de", "da", "do", "das", "dos", "e", "em", "a", "o", "as", "os", "para",
    "ltda", "me", "eireli", "sa", "s", "comercio", "servico", "servicos",
    "empresa", "empresas", "loja", "lojas", "clinica", "clinicas", "grupo",
}


def normalize_text(value: str | None) -> str:
    """minúsculas, sem acentos, só letras/números separados por um espaço."""
    if not value:
        return ""
    text = unicodedata.normalize("NFKD", str(value))
    text = "".join(ch for ch in text if not unicodedata.combining(ch)).lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def normalize_phone(value: str | None) -> str:
    """Só dígitos, sem o código do país 55; usa o primeiro número se houver vários."""
    if not value:
        return ""
    first = re.split(r"[;/,]", str(value))[0]
    digits = re.sub(r"\D", "", first)
    if digits.startswith("55") and len(digits) > 11:
        digits = digits[2:]
    return digits


def id_key(c: Company) -> str:
    return f"{c.fonte}:{c.source_id}" if c.fonte and c.source_id else ""


def fingerprint(c: Company) -> str:
    """Combinação normalizada de nome + endereço + telefone."""
    name, addr, phone = normalize_text(c.nome), normalize_text(c.endereco), normalize_phone(c.telefone)
    if not name:
        return ""
    return f"{name}|{addr}|{phone}"


def name_phone_key(c: Company) -> str:
    """Chave relaxada: mesmo nome e mesmo telefone (endereços variam entre fontes)."""
    name, phone = normalize_text(c.nome), normalize_phone(c.telefone)
    return f"{name}|{phone}" if name and phone else ""


def name_address_key(c: Company) -> str:
    """Mesmo nome e endereço, mesmo quando uma das fontes não traz telefone."""
    name, addr = normalize_text(c.nome), normalize_text(c.endereco)
    return f"{name}|{addr}" if len(name) >= 4 and len(addr) >= 8 else ""


def phone_key(c: Company) -> str:
    phone = normalize_phone(c.telefone)
    return f"tel:{phone}" if len(phone) >= 10 else ""


def keys_for(c: Company) -> list[str]:
    return [k for k in (id_key(c), fingerprint(c), name_phone_key(c), name_address_key(c), phone_key(c)) if k]


def _name_tokens(c: Company) -> set[str]:
    return {t for t in normalize_text(c.nome).split() if len(t) >= 4 and t not in _GENERIC_NAME_TOKENS}


def names_compatible(a: Company, b: Company) -> bool:
    """Telefone isolado só confirma duplicata se os nomes tiverem um termo em comum."""
    na, nb = normalize_text(a.nome), normalize_text(b.nome)
    if not na or not nb:
        return False
    if na == nb or na in nb or nb in na:
        return True
    return bool(_name_tokens(a) & _name_tokens(b))


def is_duplicate(a: Company, b: Company) -> bool:
    if id_key(a) and id_key(a) == id_key(b):
        return True
    if fingerprint(a) and fingerprint(a) == fingerprint(b):
        return True
    if name_phone_key(a) and name_phone_key(a) == name_phone_key(b):
        return True
    if name_address_key(a) and name_address_key(a) == name_address_key(b):
        return True
    if phone_key(a) and phone_key(a) == phone_key(b) and names_compatible(a, b):
        return True
    return False


def merge_into(base: Company, other: Company) -> Company:
    """Preenche campos vazios de `base` com dados de `other` (nunca sobrescreve)."""
    for name in _MERGE_FIELDS:
        if getattr(base, name) in ("", None) and getattr(other, name) not in ("", None):
            setattr(base, name, getattr(other, name))
    return base


def completeness(c: Company) -> int:
    """Quantidade de campos relevantes preenchidos (para preservar o registro mais completo)."""
    fields = ("endereco", "cidade", "estado", "latitude", "longitude", "telefone", "email", "site",
              "instagram", "facebook", "youtube", "google_maps_url", "avaliacao_google",
              "fonte_url", "observacao", "verificado_em")
    return sum(1 for name in fields if getattr(c, name) not in ("", None))


def deduplicate(companies: list[Company]) -> list[Company]:
    """Remove duplicatas mantendo um registro por empresa e aproveitando os dados das demais."""
    seen: dict[str, Company] = {}
    result: list[Company] = []
    for company in companies:
        keys = keys_for(company)
        match = next((seen[k] for k in keys if k in seen), None)
        if match is not None:
            if completeness(company) > completeness(match):
                # O novo registro é mais completo: preserve-o como base e traga o que faltar.
                merge_into(company, match)
                index = next((i for i, item in enumerate(result) if item is match), None)
                if index is not None:
                    result[index] = company
                for key, value in list(seen.items()):
                    if value is match:
                        seen[key] = company
                match = company
            else:
                merge_into(match, company)
            keys = keys + keys_for(match)
        else:
            result.append(company)
            match = company
        for k in keys:
            seen[k] = match
    return result
