"""Geocodificação de cidades via Nominatim, com cache no banco e validação de coordenadas."""
from __future__ import annotations

import json

from cities import valid_coordinates
from services.dedupe import normalize_text
from utils import CancelToken, FetchError, HttpClient, ProviderError


def geocode_location(settings, db, city: str, state: str = "", country: str = "Brasil",
                     http: HttpClient | None = None, cancel: CancelToken | None = None,
                     log=print) -> dict:
    city, state, country = (str(city or "").strip(), str(state or "").strip(),
                            str(country or "Brasil").strip())
    if not city:
        raise ProviderError("Informe o nome da cidade para geocodificar.")
    key = "nominatim:" + "|".join(normalize_text(x) for x in (city, state, country))
    cached = db.cache_get(key, settings.cache_ttl_hours)
    if cached:
        log("Geocodificação obtida do cache local.")
        return json.loads(cached)
    http = http or HttpClient(settings, cancel or CancelToken(), log)
    log(f"Geocodificando {city}, {state or '-'}, {country} no Nominatim...")
    params = {"city": city, "state": state, "country": country, "format": "jsonv2", "limit": 1}
    if settings.nominatim_email:
        params["email"] = settings.nominatim_email
    try:
        resp = http.get(settings.nominatim_url, params=params, min_interval=1.2,
                        headers={"User-Agent": settings.nominatim_user_agent})
    except FetchError as exc:
        raise ProviderError(f"Não foi possível consultar o Nominatim: {exc}") from exc
    if resp.status_code != 200:
        raise ProviderError(f"Nominatim respondeu HTTP {resp.status_code}. Tente novamente mais tarde.")
    try:
        data = resp.json()
    except ValueError as exc:
        raise ProviderError("O Nominatim retornou uma resposta inválida.") from exc
    if not data:
        raise ProviderError(f"Cidade não encontrada: {city}, {state}, {country}. Confira a grafia.")
    try:
        lat, lon = float(data[0]["lat"]), float(data[0]["lon"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ProviderError("O Nominatim retornou coordenadas inválidas.") from exc
    if not valid_coordinates(lat, lon):
        raise ProviderError("O Nominatim retornou coordenadas fora dos limites geográficos.")
    result = {"lat": lat, "lon": lon, "nome": data[0].get("display_name", "")}
    db.cache_set(key, json.dumps(result))
    log(f"Coordenadas encontradas: {lat:.6f}, {lon:.6f}.")
    return result
