"""Validação conservadora de relevância dos resultados.

Não tenta adivinhar o segmento de nomes criativos: quando não há evidência,
marca para revisão manual em vez de descartar ou inventar classificação.
"""
from __future__ import annotations

import re

from services.dedupe import normalize_text

_STOPWORDS = {
    "de", "da", "do", "das", "dos", "e", "em", "para", "com", "a", "o", "as", "os",
    "loja", "lojas", "empresa", "empresas", "servico", "servicos", "clinica", "clinicas",
    "assistencia", "tecnica", "tecnico", "casa", "grupo", "centro", "espaco",
}


def _tokens(value: str) -> set[str]:
    return {t for t in normalize_text(value).split() if len(t) >= 4 and t not in _STOPWORDS}


def _is_place_name(name: str, city: str, state: str, country: str) -> bool:
    norm = normalize_text(name)
    places = {normalize_text(city), normalize_text(state), normalize_text(country)}
    return bool(norm) and (norm in places or (len(norm) <= 3 and norm in {"sp", "ms", "brasil"}))


def evaluate(company, terms, city: str = "", state: str = "", country: str = "") -> tuple[str, str]:
    """Retorna ('confirmada'|'revisar'|'descartar', motivo)."""
    name = (company.nome or "").strip()
    if not name:
        return "descartar", "Resultado sem nome."
    if _is_place_name(name, city, state, country):
        return "descartar", "Resultado é o nome da localidade, não uma empresa."
    name_tokens = _tokens(name)
    term_tokens: set[str] = set()
    for term in terms or []:
        term_tokens |= _tokens(term)
    if not term_tokens:
        return "revisar", "Não há termos suficientes para validar o segmento."
    common = name_tokens & term_tokens
    if common:
        return "confirmada", "Nome contém termo do segmento: " + ", ".join(sorted(common)[:4]) + "."
    address_tokens = _tokens(getattr(company, "endereco", "") or "")
    if address_tokens & term_tokens:
        return "confirmada", "Endereço contém termo do segmento."
    return "revisar", "Nome não contém termo do segmento; revisar manualmente."


def apply(company, terms, city: str = "", state: str = "", country: str = "") -> str:
    company.relevancia, company.relevancia_motivo = evaluate(company, terms, city, state, country)
    return company.relevancia
