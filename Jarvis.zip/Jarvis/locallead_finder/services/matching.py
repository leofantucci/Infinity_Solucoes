"""Funções puras para decidir se uma página/perfil pertence à empresa (conservador)."""
from __future__ import annotations

import re
from urllib.parse import urlparse

from models import Company
from services.dedupe import normalize_phone, normalize_text

_STOP = {"ltda", "eireli", "epp", "sa", "me", "dos", "das", "para", "com", "the", "and", "de", "da", "do", "e"}

# Diretórios, redes e marketplaces: nunca são o "site oficial" da empresa.
DIRECTORY_DOMAINS = (
    "google.", "goo.gl", "bing.com", "duckduckgo.com", "facebook.com", "instagram.com", "youtube.com",
    "linkedin.com", "twitter.com", "x.com", "tiktok.com", "wikipedia.org", "tripadvisor.", "yelp.",
    "foursquare.com", "doctoralia.", "apontador.", "guiamais.", "telelistas.", "solutudo.", "cylex",
    "encontrasp", "listamais", "olx.com", "mercadolivre.", "ifood.com", "waze.com", "openstreetmap.org",
    "jusbrasil.", "reclameaqui.", "econodata.", "cnpj.", "casadosdados.", "wa.me", "whatsapp.com",
    "glassdoor.", "indeed.", "yellowpages", "bol.uol", "pt.wikipedia", "fandom.com", "pinterest.",
)


def is_directory_domain(url: str) -> bool:
    host = urlparse(url if "://" in url else "https://" + url).netloc.lower()
    return any(d in host for d in DIRECTORY_DOMAINS)


def name_tokens(name: str) -> list[str]:
    return [t for t in normalize_text(name).split() if len(t) >= 3 and t not in _STOP]


def token_ratio(haystack: str, tokens: list[str], nospace: bool = False) -> float:
    if not tokens:
        return 0.0
    hay = normalize_text(haystack)
    if nospace:
        hay = hay.replace(" ", "")
    return sum(1 for t in tokens if t in hay) / len(tokens)


def host_label(url: str) -> str:
    host = urlparse(url if "://" in url else "https://" + url).netloc.lower().split(":")[0]
    host = re.sub(r"^www\.", "", host)
    return host.split(".")[0]


def phone_in_text(phone: str, text: str) -> bool:
    digits = normalize_phone(phone)
    if len(digits) < 8:
        return False
    return digits[-8:] in re.sub(r"\D", "", text or "")


def score_candidate(c: Company, url: str, title: str, page_text: str) -> tuple[bool, list[str]]:
    """Confirma um candidato a site oficial. Exige mais de um indício independente."""
    tokens = name_tokens(c.nome)
    reasons = []
    phone = phone_in_text(c.telefone, page_text)
    name_page = token_ratio(page_text, tokens) >= 0.7
    name_head = token_ratio(f"{title} {host_label(url)}", tokens, nospace=True) >= 0.6
    city = bool(c.cidade) and normalize_text(c.cidade) in normalize_text(page_text)
    if phone:
        reasons.append("telefone da empresa aparece na página")
    if name_page:
        reasons.append("nome da empresa aparece no conteúdo")
    if name_head:
        reasons.append("nome da empresa no título/domínio")
    if city:
        reasons.append("cidade aparece na página")
    confirmed = (phone and name_page) or (phone and name_head) or (name_head and city)
    return confirmed, reasons


def snippet_confirms_profile(c: Company, text: str) -> bool:
    """Perfil social só é aceito se o texto do resultado trouxer o nome completo + cidade ou telefone."""
    tokens = name_tokens(c.nome)
    if not tokens or token_ratio(text, tokens) < 1.0:
        return False
    return phone_in_text(c.telefone, text) or (bool(c.cidade) and normalize_text(c.cidade) in normalize_text(text))
