"""Identificação de links públicos de Instagram, Facebook e YouTube."""
from __future__ import annotations

import json
import re
from collections import Counter
from urllib.parse import parse_qs, urljoin, urlparse

from bs4 import BeautifulSoup

PLATFORMS = ("instagram", "facebook", "youtube")

_GENERIC = {"facebook", "instagram", "youtube", "meta", "wix", "wordpress", "godaddy", "google"}
_IG_BLOCK = {"p", "reel", "reels", "tv", "explore", "accounts", "stories", "direct", "share", "sharer",
             "about", "developer", "legal", "web", "oauth", "challenge", "privacy", "directory"}
_FB_BLOCK = {"sharer", "sharer.php", "share", "share.php", "dialog", "plugins", "tr", "login", "login.php",
             "policies", "help", "legal", "privacy", "events", "groups", "watch", "hashtag", "marketplace",
             "gaming", "stories", "reel", "reels", "photo", "photo.php", "permalink.php", "l.php", "flx",
             "business", "ads", "public", "people", "story.php", "sharer.php", "v2.0", "v3.0", "dialog"}
_YT_BLOCK = {"watch", "embed", "shorts", "playlist", "results", "share", "feed", "redirect", "about",
             "t", "channel_switcher", "iframe_api", "live", "hashtag"}


def _clean_host(host: str) -> str:
    host = host.lower().split(":")[0]
    for prefix in ("www.", "m.", "mobile.", "pt-br.", "web."):
        if host.startswith(prefix):
            host = host[len(prefix):]
    return host


def classify_url(url: str) -> tuple[str, str] | None:
    """Retorna (plataforma, url_normalizada) ou None se o link não for um perfil utilizável.

    Ignora links de compartilhamento, posts/reels, páginas genéricas e perfis pessoais
    (facebook.com/people/...).
    """
    if not url:
        return None
    url = url.strip()
    if url.startswith("//"):
        url = "https:" + url
    if not re.match(r"^[a-z]+://", url, re.I):
        url = "https://" + url
    parsed = urlparse(url)
    host = _clean_host(parsed.netloc)
    segs = [s for s in parsed.path.split("/") if s]
    if not segs and not parsed.query:
        return None

    if host in ("instagram.com", "instagr.am"):
        first = segs[0] if segs else ""
        if not first or first.lower() in _IG_BLOCK or first.lower() in _GENERIC:
            return None
        return "instagram", f"https://www.instagram.com/{first}/"

    if host in ("facebook.com", "fb.com", "web.facebook.com"):
        first = segs[0] if segs else ""
        if first == "profile.php":
            fid = parse_qs(parsed.query).get("id", [""])[0]
            return ("facebook", f"https://www.facebook.com/profile.php?id={fid}") if fid.isdigit() else None
        if first.lower() == "pages" and len(segs) >= 3:
            return "facebook", f"https://www.facebook.com/pages/{segs[1]}/{segs[2]}"
        if not first or first.lower() in _FB_BLOCK or first.lower() in _GENERIC:
            return None
        return "facebook", f"https://www.facebook.com/{first}/"

    if host == "youtube.com":
        first = segs[0] if segs else ""
        if first.startswith("@") and len(first) > 1:
            return "youtube", f"https://www.youtube.com/{first}"
        if first in ("channel", "c", "user") and len(segs) >= 2:
            return "youtube", f"https://www.youtube.com/{first}/{segs[1]}"
        return None
    return None


def normalize_handle(platform: str, value: str) -> str:
    """Converte valores de tags do OSM (@usuario, usuario ou URL) em URL de perfil."""
    value = (value or "").strip().split(";")[0].strip()
    if not value:
        return ""
    if "/" in value or re.match(r"^(www\.)?(instagram|facebook|fb|youtube)\.", value, re.I):
        found = classify_url(value)
        return found[1] if found and found[0] == platform else ""
    handle = value.lstrip("@")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{2,64}", handle):
        return ""
    return {
        "instagram": f"https://www.instagram.com/{handle}/",
        "facebook": f"https://www.facebook.com/{handle}/",
        "youtube": f"https://www.youtube.com/@{handle}",
    }[platform]


def extract_social_links(html: str, base_url: str = "") -> dict[str, list[str]]:
    """Lê links <a>, <link> e JSON-LD (sameAs) e devolve perfis por plataforma (mais frequentes primeiro)."""
    soup = BeautifulSoup(html or "", "html.parser")
    raw: list[str] = [a["href"] for a in soup.find_all("a", href=True)]
    raw += [l["href"] for l in soup.find_all("link", href=True) if "me" in (l.get("rel") or [])]
    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or "")
        except (ValueError, TypeError):
            continue
        stack = [data]
        while stack:
            node = stack.pop()
            if isinstance(node, dict):
                same = node.get("sameAs")
                raw += [same] if isinstance(same, str) else [s for s in (same or []) if isinstance(s, str)]
                stack += [v for v in node.values() if isinstance(v, (dict, list))]
            elif isinstance(node, list):
                stack += node
    counts: dict[str, Counter] = {p: Counter() for p in PLATFORMS}
    for href in raw:
        href = urljoin(base_url, href) if base_url else href
        found = classify_url(href)
        if found:
            counts[found[0]][found[1]] += 1
    return {p: [u for u, _ in counts[p].most_common()] for p in PLATFORMS}
