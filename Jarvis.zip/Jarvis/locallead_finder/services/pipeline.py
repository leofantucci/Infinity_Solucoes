"""Orquestra pesquisa e verificação (usado pela interface; também testável sem GUI)."""
from __future__ import annotations

import time

from browser.firefox import BrowserError, FirefoxBrowser
from models import SITE_ENCONTRADO, Company, SearchParams
from providers.google_places import GooglePlacesProvider
from providers.osm import OSMProvider
from services import lead_classifier, relevance
from services.category_expansion import resolve_context
from services.dedupe import deduplicate, normalize_phone
from services.site_checker import SiteVerifier
from utils import Cancelled, HttpClient, ProviderError

SOURCE_OSM = "OpenStreetMap"
SOURCE_GOOGLE = "Google Places API"


def is_qualified(c: Company) -> bool:
    """Lead importante: tem nome, telefone ou e-mail e não possui site cadastrado."""
    contact = bool(normalize_phone(c.telefone)) or bool((c.email or "").strip())
    return bool((c.nome or "").strip()) and contact and not (c.site or "").strip()


def filter_qualified(companies: list[Company]) -> list[Company]:
    return [c for c in companies if is_qualified(c)]


def filter_discovered(companies: list[Company], site_filter: str, only_phone: bool) -> list[Company]:
    """site_filter: 'todos' | 'com_site' | 'sem_site'."""
    out = []
    for c in companies:
        if site_filter == "com_site" and not c.site:
            continue
        if site_filter == "sem_site" and c.site:
            continue
        if only_phone and not c.telefone:
            continue
        out.append(c)
    return out


def run_search(settings, db, categories, params: SearchParams, source: str, site_filter: str,
               only_phone: bool, cancel, log=print, progress=lambda done, total: None,
               qualified_only: bool = False) -> list[int]:
    started = time.perf_counter()
    http = HttpClient(settings, cancel, log)
    osm = OSMProvider(settings, db, categories, http, cancel, log)
    provider = osm if source == SOURCE_OSM else GooglePlacesProvider(settings, osm, http, cancel, log)

    limit = max(settings.google_max_queries, settings.osm_max_terms)
    category, label, terms = resolve_context(categories, params.keyword, limit=limit)
    params.category_label = label
    params.category_id = category.id if category else None
    params.terms = tuple(terms)
    log(f"Categoria: {params.keyword}.")
    if category:
        log(f"Categoria encontrada no banco: {category.label} (id {category.id or category.key}).")
    else:
        log("Categoria personalizada (não cadastrada); usando interpretação e expansão local.")
    log(f"{len(terms)} termo(s) preparado(s): " + " · ".join(terms[:10])
        + (" · ..." if len(terms) > 10 else ""))
    log(f"Localização: {params.city} - {params.uf or params.state} ({params.country}).")
    if params.latitude is not None and params.longitude is not None:
        log(f"Coordenadas fornecidas pelo seletor: {params.latitude:.6f}, {params.longitude:.6f}.")
    else:
        log("Coordenadas serão obtidas por geocodificação confiável.")
    log(f"Raio configurado: {params.radius_km:g} km · limite: {params.max_results} resultado(s).")
    log(f"Consultando {provider.source_name}...")
    progress(0, 0)
    companies = provider.search(params)
    log(f"{len(companies)} resultado(s) recebido(s) da fonte.")

    kept: list[Company] = []
    discarded = review = 0
    for company in companies:
        status = relevance.apply(company, terms, params.city, params.state, params.country)
        if status == "descartar":
            discarded += 1
            continue
        if status == "revisar":
            review += 1
        kept.append(company)
    if discarded or review:
        log(f"Relevância: {len(kept)} mantido(s), {discarded} descartado(s) como ruído, "
            f"{review} marcado(s) para revisão manual.")

    before = len(kept)
    companies = deduplicate(kept)
    removed = before - len(companies)
    if removed:
        log(f"{removed} duplicata(s) removida(s) na consolidação.")

    # Resultados confirmados e incertos são persistidos. Os filtros de exibição/exportação
    # não descartam empresas do banco; apenas limitam o que é devolvido nesta pesquisa.
    visible = filter_discovered(companies, site_filter, only_phone)
    if qualified_only:
        visible = filter_qualified(visible)
    visible = visible[: params.max_results]
    stored_ids: dict[int, int] = {}
    new = 0
    total = len(companies)
    for i, c in enumerate(companies, 1):
        cancel.check()
        if c.site:
            c.status_site = SITE_ENCONTRADO
        lead_classifier.apply(c)
        cid, is_new = db.upsert(c)
        existing = db.get_many([cid])[0]
        lead_classifier.apply(existing)
        db.save(existing)
        stored_ids[id(c)] = cid
        new += is_new
        progress(i, total)
    ids = [stored_ids[id(c)] for c in visible if id(c) in stored_ids]
    elapsed = time.perf_counter() - started
    log(f"Pesquisa concluída em {elapsed:.1f}s: {len(companies)} empresa(s) armazenada(s), "
        f"{len(ids)} exibida(s) após filtros ({new} nova(s)).")
    return ids


def run_verification(settings, db, ids: list[int], cancel, log=print, progress=lambda d, t: None,
                     use_browser: bool = True, headless: bool | None = None, recheck: bool = False) -> int:
    companies = db.get_many(ids)
    todo = [c for c in companies if recheck or not c.verificado_em]
    if not todo:
        log("Nada a verificar: todas as empresas já foram verificadas.")
        return 0
    http = HttpClient(settings, cancel, log)
    browser = None
    done = 0
    try:
        if use_browser:
            browser = FirefoxBrowser(settings, cancel, headless, log)
            try:
                browser.start()
            except BrowserError as exc:
                log(f"AVISO: {exc}")
                log("Continuando apenas com Requests (sem busca no navegador).")
                browser = None
        verifier = SiteVerifier(settings, http, cancel, log, browser, use_search=browser is not None)
        progress(0, len(todo))
        for c in todo:
            cancel.check()
            try:
                verifier.verify(c)
            except Cancelled:
                raise
            except Exception as exc:   # uma empresa com erro não pode derrubar o lote
                log(f"  Erro ao verificar '{c.nome}': {exc}. Marcado como inconclusivo.")
                c.status_site = "Verificação inconclusiva"
                lead_classifier.apply(c)
            db.save(c)
            done += 1
            progress(done, len(todo))
    except Cancelled:
        log("Verificação cancelada; o que já foi verificado ficou salvo.")
    finally:
        if browser is not None:
            browser.close()
    log(f"Verificação finalizada: {done} de {len(todo)} empresa(s).")
    return done
