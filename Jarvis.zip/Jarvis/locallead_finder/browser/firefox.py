"""Automação do Firefox com Selenium (importação preguiçosa: o resto do app funciona sem Selenium)."""
from __future__ import annotations

import shutil
from dataclasses import dataclass
from urllib.parse import parse_qs, quote_plus, urlparse

from bs4 import BeautifulSoup

from utils import CancelToken


class BrowserError(Exception):
    """Firefox/geckodriver indisponível ou falha irrecuperável."""


class BrowserBlocked(Exception):
    """O mecanismo de busca apresentou CAPTCHA/bloqueio. Não tentamos contornar."""


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str


_BLOCK_MARKERS = ("anomaly-modal", "unusual traffic", "captcha", "select all squares", "are you a human",
                  "bots use duckduckgo")


def parse_duckduckgo(html: str) -> list[SearchResult]:
    """Extrai resultados da versão HTML do DuckDuckGo."""
    soup = BeautifulSoup(html or "", "html.parser")
    results = []
    for block in soup.select("div.result, div.web-result"):
        link = block.select_one("a.result__a")
        if not link or not link.get("href"):
            continue
        href = link["href"]
        if href.startswith("//"):
            href = "https:" + href
        qs = parse_qs(urlparse(href).query)
        if "uddg" in qs:
            href = qs["uddg"][0]
        if not href.startswith("http"):
            continue
        snip = block.select_one(".result__snippet")
        results.append(SearchResult(link.get_text(" ", strip=True), href, snip.get_text(" ", strip=True) if snip else ""))
    return results


def looks_blocked(html: str) -> bool:
    low = (html or "").lower()
    return any(m in low for m in _BLOCK_MARKERS)


class FirefoxBrowser:
    def __init__(self, settings, cancel: CancelToken, headless: bool | None = None, log=print) -> None:
        self.s, self.cancel, self.log = settings, cancel, log
        self.headless = settings.firefox_headless if headless is None else headless
        self.driver = None

    # ---------- ciclo de vida ----------
    def start(self) -> None:
        try:
            from selenium import webdriver
            from selenium.webdriver.firefox.options import Options
            from selenium.webdriver.firefox.service import Service
        except ImportError as exc:
            raise BrowserError("Selenium não instalado. Rode: pip install -r requirements.txt") from exc
        options = Options()
        if self.headless:
            options.add_argument("-headless")
        if self.s.firefox_binary:
            options.binary_location = self.s.firefox_binary
        driver_path = self.s.geckodriver_path or shutil.which("geckodriver")
        service = Service(executable_path=driver_path) if driver_path else Service()
        self.log("Abrindo o Firefox" + (" (sem janela)" if self.headless else "") + "...")
        try:
            self.driver = webdriver.Firefox(options=options, service=service)
            self.driver.set_page_load_timeout(self.s.page_load_timeout)
        except Exception as exc:   # WebDriverException e variações de ambiente
            self.driver = None
            raise BrowserError(
                "Não foi possível iniciar o Firefox/geckodriver. No Manjaro: "
                "sudo pacman -S firefox geckodriver (evite Firefox via Snap/Flatpak). "
                f"Detalhe: {str(exc)[:160]}") from exc

    def close(self) -> None:
        if self.driver is not None:
            try:
                self.driver.quit()
            except Exception:
                pass
            self.driver = None
            self.log("Firefox encerrado.")

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ---------- navegação ----------
    def get_html(self, url: str, settle_seconds: float = 2.0) -> str:
        """Carrega a página (com tentativas limitadas) e devolve o HTML renderizado."""
        from selenium.common.exceptions import TimeoutException, WebDriverException
        if self.driver is None:
            raise BrowserError("Firefox não iniciado.")
        last = ""
        for attempt in range(1, self.s.max_retries + 2):
            self.cancel.check()
            self.cancel.sleep(self.s.request_delay)
            try:
                self.driver.get(url)
            except TimeoutException:
                self.log(f"  Tempo esgotado ao carregar {url}; usando o que já foi carregado.")
                try:
                    self.driver.execute_script("window.stop();")
                except WebDriverException:
                    pass
            except WebDriverException as exc:
                last = str(exc).splitlines()[0][:140]
                self.log(f"  Erro do navegador ({last}); tentativa {attempt}/{self.s.max_retries + 1}")
                continue
            self.cancel.sleep(settle_seconds)
            return self.driver.page_source or ""
        raise BrowserError(f"Falha ao abrir {url}: {last}")

    def search(self, query: str) -> list[SearchResult]:
        """Pesquisa no DuckDuckGo (versão HTML) pelo Firefox. Se houver CAPTCHA, aborta sem contornar."""
        html = self.get_html("https://html.duckduckgo.com/html/?q=" + quote_plus(query))
        if looks_blocked(html):
            raise BrowserBlocked("O mecanismo de busca pediu verificação (CAPTCHA/limite). "
                                 "Aguarde um pouco ou revise manualmente.")
        return parse_duckduckgo(html)
