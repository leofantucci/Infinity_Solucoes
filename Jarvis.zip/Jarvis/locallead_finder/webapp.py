"""Servidor web local (somente 127.0.0.1) que alimenta o painel HUD no Firefox. Só usa a biblioteca padrão."""
from __future__ import annotations

import json
import secrets
import tempfile
import threading
from dataclasses import asdict
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import exporters
from cities import CityStore, valid_coordinates
from models import SearchParams
from services import pipeline
from services.dedupe import normalize_text
from services.geocoding import geocode_location
from utils import Cancelled, CancelToken, ProviderError

WEB_DIR = Path(__file__).resolve().parent / "web"
MAX_BODY = 64 * 1024
SITE_FILTERS = {"todos", "com_site", "sem_site"}


class Jobs:
    """Executa uma tarefa por vez em segundo plano e guarda logs/progresso para o painel."""

    def __init__(self, settings, db, categories) -> None:
        self.settings, self.db, self.categories = settings, db, categories
        self.lock = threading.Lock()
        self.logs: list[dict] = []
        self.running, self.task = False, ""
        self.progress = (0, 0)
        self.ids: list[int] = []
        self.cancel = CancelToken()
        self.thread: threading.Thread | None = None

    def log(self, msg: str) -> None:
        with self.lock:
            self.logs.append({"t": datetime.now().strftime("%H:%M:%S"), "m": str(msg)})

    def set_progress(self, done: int, total: int) -> None:
        self.progress = (done, total)

    def start(self, task: str, fn) -> bool:
        with self.lock:
            if self.running:
                return False
            self.running, self.task, self.progress = True, task, (0, 0)
            self.cancel = CancelToken()
            cancel = self.cancel

        def job() -> None:
            try:
                fn(cancel, self.log, self.set_progress)
            except Cancelled:
                self.log("Operação cancelada.")
            except ProviderError as exc:
                self.log(f"ERRO: {exc}")
            except Exception as exc:  # a thread nunca morre em silêncio
                self.log(f"ERRO inesperado: {type(exc).__name__}: {exc}")
            finally:
                with self.lock:
                    self.running = False

        self.thread = threading.Thread(target=job, daemon=True)
        self.thread.start()
        return True

    def status(self, since: int) -> dict:
        with self.lock:
            return {"running": self.running, "task": self.task, "logs": self.logs[since:],
                    "next": len(self.logs), "done": self.progress[0], "total": self.progress[1]}


def parse_params(data: dict) -> SearchParams:
    try:
        radius = float(str(data.get("radius", "5")).replace(",", "."))
        maximum = int(data.get("max", 50))
    except (TypeError, ValueError):
        raise ValueError("Raio e quantidade máxima devem ser números.")
    if not (0 < radius <= 50) or not (0 < maximum <= 500):
        raise ValueError("Raio deve estar entre 0 e 50 km e o máximo entre 1 e 500.")
    kw, city = str(data.get("keyword", "")).strip(), str(data.get("city", "")).strip()
    if not kw or not city:
        raise ValueError("Informe a categoria (ou termo) e a cidade.")
    latitude = longitude = None
    raw_lat, raw_lon = data.get("latitude"), data.get("longitude")
    if raw_lat not in (None, "") or raw_lon not in (None, ""):
        try:
            latitude, longitude = float(raw_lat), float(raw_lon)
        except (TypeError, ValueError):
            raise ValueError("Coordenadas inválidas.")
        if not valid_coordinates(latitude, longitude):
            raise ValueError("Coordenadas fora dos limites geográficos.")
    city_id = None
    if data.get("city_id") not in (None, ""):
        try:
            city_id = int(data.get("city_id"))
        except (TypeError, ValueError):
            raise ValueError("Cidade inválida.")
    return SearchParams(
        keyword=kw[:80], city=city[:80], state=str(data.get("state", "")).strip()[:80],
        country=str(data.get("country", "")).strip()[:80], radius_km=radius, max_results=maximum,
        uf=str(data.get("uf", "")).strip()[:8], city_id=city_id, latitude=latitude, longitude=longitude)


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, addr, settings, db, categories, cities=None) -> None:
        super().__init__(addr, Handler)
        self.settings, self.db, self.categories = settings, db, categories
        self.cities = cities if cities is not None else CityStore(db)
        self.jobs = Jobs(settings, db, categories)
        self.token = secrets.token_urlsafe(24)


class Handler(BaseHTTPRequestHandler):
    server: Server

    def log_message(self, *args) -> None:   # silencioso; o painel tem seus próprios logs
        pass

    # ---------- utilidades ----------
    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; "
                         "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def _error(self, code: int, msg: str) -> None:
        self._json({"error": msg}, code)

    def _host_ok(self) -> bool:
        port = self.server.server_address[1]
        return self.headers.get("Host", "") in (f"127.0.0.1:{port}", f"localhost:{port}")

    def _authorized(self, query: dict) -> bool:
        token = self.headers.get("X-LLF-Token") or (query.get("token") or [""])[0]
        return self._host_ok() and secrets.compare_digest(token, self.server.token)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > MAX_BODY:
            raise ValueError("Requisição grande demais.")
        raw = self.rfile.read(length) if length else b"{}"
        data = json.loads(raw or b"{}")
        if not isinstance(data, dict):
            raise ValueError("Corpo inválido.")
        return data

    # ---------- GET ----------
    def do_GET(self) -> None:
        url = urlparse(self.path)
        query = parse_qs(url.query)
        if url.path == "/":
            if not self._host_ok():
                return self._error(403, "Host não permitido.")
            html = (WEB_DIR / "index.html").read_text(encoding="utf-8").replace("__TOKEN__", self.server.token)
            return self._send(200, html.encode(), "text/html; charset=utf-8")
        if not self._authorized(query):
            return self._error(403, "Acesso negado.")
        s, jobs = self.server.settings, self.server.jobs
        if url.path == "/api/config":
            return self._json({
                "city": s.default_city, "state": s.default_state, "country": s.default_country,
                "categories": self.server.categories.labels(active_only=True),
                "category_options": self.server.categories.options(active_only=True),
                "cities": self.server.cities.options(active_only=True),
                "google_configured": bool(s.google_api_key),
                "sources": [pipeline.SOURCE_OSM, pipeline.SOURCE_GOOGLE],
                "export_filters": exporters.EXPORT_FILTERS,
                "export_fields": exporters.EXPORT_FIELDS,
                "default_qualified": True,
                "firefox_headless": s.firefox_headless,
                "google_max_queries": s.google_max_queries,
            })
        if url.path == "/api/status":
            try:
                since = max(int((query.get("since") or ["0"])[0]), 0)
            except ValueError:
                since = 0
            return self._json(jobs.status(since))
        if url.path == "/api/categories":
            q = (query.get("q") or [""])[0]
            include_inactive = (query.get("all") or ["0"])[0] in ("1", "true", "sim")
            return self._json({"categories": self.server.categories.options(
                active_only=not include_inactive, query=q)})
        if url.path == "/api/cities":
            q = (query.get("q") or [""])[0]
            include_inactive = (query.get("all") or ["0"])[0] in ("1", "true", "sim")
            return self._json({"cities": self.server.cities.options(
                active_only=not include_inactive, query=q)})
        if url.path == "/api/results":
            db = self.server.db
            companies = db.all() if (query.get("scope") or [""])[0] == "all" else db.get_many(jobs.ids)
            return self._json({"results": [asdict(c) for c in companies]})
        if url.path == "/api/export":
            return self._export(query)
        self._error(404, "Não encontrado.")

    def _export(self, query: dict) -> None:
        kind = (query.get("kind") or ["csv"])[0]
        mode = (query.get("filter") or ["todos"])[0]
        raw_fields = (query.get("fields") or [""])[0].strip()
        fields = [f for f in raw_fields.split(",") if f] if raw_fields else None
        raw_ids = (query.get("ids") or [""])[0].strip()
        if kind not in ("csv", "xlsx", "pdf") or mode not in exporters.EXPORT_FILTERS:
            return self._error(400, "Parâmetros de exportação inválidos.")
        if fields is not None and (not fields or any(f not in exporters.EXPORT_FIELDS for f in fields)):
            return self._error(400, "Colunas de exportação inválidas.")
        try:
            ids = [int(x) for x in raw_ids.split(",") if x.strip()] if raw_ids else None
            if ids is not None and (not ids or any(i <= 0 for i in ids)):
                raise ValueError
        except ValueError:
            return self._error(400, "Seleção de empresas inválida.")
        companies = self.server.db.get_many(ids) if ids is not None else \
            self.server.db.get_many(self.server.jobs.ids)
        companies = exporters.filter_companies(companies, mode)
        if not companies:
            return self._error(404, "Nenhuma empresa atende ao filtro de exportação.")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / f"out.{kind}"
            exporter = {"csv": exporters.export_csv, "xlsx": exporters.export_excel,
                        "pdf": exporters.export_pdf}[kind]
            exporter(companies, path, fields)
            body = path.read_bytes()
        name = f"leads_{mode}_{datetime.now():%Y%m%d_%H%M}.{kind}"
        ctype = {"csv": "text/csv; charset=utf-8",
                 "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                 "pdf": "application/pdf"}[kind]
        self._send(200, body, ctype, {"Content-Disposition": f'attachment; filename="{name}"'})

    # ---------- POST ----------
    def do_POST(self) -> None:
        url = urlparse(self.path)
        if not self._authorized(parse_qs(url.query)):
            return self._error(403, "Acesso negado.")
        try:
            data = self._body()
        except (ValueError, json.JSONDecodeError) as exc:
            return self._error(400, str(exc))
        srv, jobs, s = self.server, self.server.jobs, self.server.settings

        if url.path == "/api/search":
            try:
                params = parse_params(data)
            except ValueError as exc:
                return self._error(400, str(exc))
            if params.city_id is not None:
                city = srv.cities.get(params.city_id)
                if city is None:
                    return self._error(400, "Cidade selecionada não encontrada.")
                if params.latitude is None or params.longitude is None:
                    params.latitude, params.longitude = city.latitude, city.longitude
                params.city = params.city or city.name
                params.state = params.state or city.state
                params.uf = params.uf or city.uf
                params.country = params.country or city.country
            source = data.get("source", pipeline.SOURCE_OSM)
            site_filter = data.get("site_filter", "todos")
            if source not in (pipeline.SOURCE_OSM, pipeline.SOURCE_GOOGLE) or site_filter not in SITE_FILTERS:
                return self._error(400, "Fonte ou filtro inválido.")
            if source == pipeline.SOURCE_GOOGLE and not s.google_api_key:
                return self._error(400, "Defina GOOGLE_PLACES_API_KEY no .env ou use o OpenStreetMap.")
            only_phone = bool(data.get("only_phone"))
            qualified_only = bool(data.get("qualified_only", True))

            def run(cancel, log, progress):
                jobs.ids = pipeline.run_search(s, srv.db, srv.categories, params, source, site_filter,
                                               only_phone, cancel, log, progress, qualified_only)
            return self._started(jobs.start("search", run))

        if url.path == "/api/verify":
            if not jobs.ids:
                return self._error(400, "Faça uma pesquisa primeiro.")
            ids = list(jobs.ids)
            use_browser, headless = bool(data.get("use_browser", True)), bool(data.get("headless", False))
            return self._started(jobs.start("verify", lambda cancel, log, progress: pipeline.run_verification(
                s, srv.db, ids, cancel, log, progress, use_browser, headless)))

        if url.path == "/api/cancel":
            jobs.cancel.cancel()
            jobs.log("Cancelando... aguarde a operação atual terminar.")
            return self._json({"ok": True})

        if url.path == "/api/load_db":
            if jobs.running:
                return self._error(409, "Aguarde a tarefa atual terminar.")
            jobs.ids = [c.id for c in srv.db.all()]
            jobs.log(f"{len(jobs.ids)} empresa(s) carregada(s) do banco local.")
            return self._json({"ok": True})

        if url.path in ("/api/category", "/api/category/update", "/api/category/delete"):
            try:
                if url.path == "/api/category/delete":
                    cid = data.get("id")
                    cid = int(cid) if cid not in (None, "") else None
                    key = str(data.get("key", "")).strip() or None
                    current = srv.categories.get(cid, key)
                    if not current:
                        return self._error(404, "Categoria não encontrada.")
                    srv.categories.delete(category_id=cid, key=key)
                    jobs.log(f"Categoria '{current.label}' excluída. Pesquisas e leads antigos foram preservados.")
                    return self._json({"ok": True, "categories": srv.categories.options(active_only=False)})
                payload = dict(data)
                if "keywords" not in payload and "terms" in payload:
                    payload["keywords"] = payload.get("terms")
                if "terms" in payload and isinstance(payload["terms"], str):
                    payload["keywords"] = payload.get("keywords") or payload["terms"]
                if url.path == "/api/category/update":
                    cid = payload.get("id")
                    cid = int(cid) if cid not in (None, "") else None
                    key = str(payload.get("key", "")).strip() or None
                    cat = srv.categories.update(
                        category_id=cid, key=key, name=payload.get("name"),
                        description=payload.get("description"),
                        keywords=payload.get("keywords") if "keywords" in payload else None,
                        synonyms=payload.get("synonyms") if "synonyms" in payload else None,
                        tags=payload.get("osm_tags", payload.get("tags")) if ("osm_tags" in payload or "tags" in payload) else None,
                        active=payload.get("active") if "active" in payload else None)
                    jobs.log(f"Categoria '{cat.label}' atualizada.")
                else:
                    name = str(payload.get("name", "")).strip()
                    if not name:
                        return self._error(400, "Informe o nome da categoria.")
                    cat = srv.categories.create(
                        name, description=payload.get("description", ""),
                        keywords=payload.get("keywords", []), synonyms=payload.get("synonyms", []),
                        tags=payload.get("osm_tags", payload.get("tags", [])),
                        active=bool(payload.get("active", True)))
                    jobs.log(f"Categoria '{cat.label}' adicionada.")
            except ValueError as exc:
                return self._error(400, str(exc))
            return self._json({"ok": True, "categories": srv.categories.options(active_only=False),
                               "category_options": srv.categories.options(active_only=True)})

        if url.path in ("/api/city", "/api/city/update", "/api/city/delete"):
            try:
                if url.path == "/api/city/delete":
                    cid = int(data.get("id"))
                    current = srv.cities.get(cid)
                    if not current:
                        return self._error(404, "Cidade não encontrada.")
                    srv.cities.delete(cid)
                    jobs.log(f"Cidade '{current.display}' excluída. Pesquisas e leads antigos foram preservados.")
                    return self._json({"ok": True, "cities": srv.cities.options(active_only=False)})
                if url.path == "/api/city/update":
                    cid = int(data.get("id"))
                    city = srv.cities.update(
                        cid, name=data.get("name"), state=data.get("state"), uf=data.get("uf"),
                        country=data.get("country"), latitude=data.get("latitude"),
                        longitude=data.get("longitude"), active=data.get("active"))
                    jobs.log(f"Cidade '{city.display}' atualizada.")
                else:
                    city = srv.cities.create(
                        data.get("name", ""), state=data.get("state", ""), uf=data.get("uf", ""),
                        country=data.get("country", "Brasil"), latitude=data.get("latitude"),
                        longitude=data.get("longitude"), active=bool(data.get("active", True)))
                    jobs.log(f"Cidade '{city.display}' adicionada.")
            except (TypeError, ValueError) as exc:
                return self._error(400, str(exc))
            return self._json({"ok": True, "cities": srv.cities.options(active_only=False),
                               "city_options": srv.cities.options(active_only=True)})

        if url.path == "/api/geocode":
            try:
                result = geocode_location(s, srv.db, data.get("name", ""),
                                          data.get("state") or data.get("uf", ""),
                                          data.get("country", "Brasil"), log=jobs.log)
            except ProviderError as exc:
                return self._error(400, str(exc))
            return self._json({"ok": True, "latitude": result["lat"], "longitude": result["lon"],
                               "display_name": result.get("nome", "")})

        if url.path == "/api/observation":
            try:
                cid = int(data.get("id"))
            except (TypeError, ValueError):
                return self._error(400, "Empresa inválida.")
            companies = srv.db.get_many([cid])
            if not companies:
                return self._error(404, "Empresa não encontrada.")
            company = companies[0]
            company.observacao = str(data.get("observacao", "")).strip()[:2000]
            srv.db.save(company)
            return self._json({"ok": True})

        if url.path == "/api/shutdown":
            jobs.cancel.cancel()
            self._json({"ok": True})
            threading.Thread(target=srv.shutdown, daemon=True).start()
            return
        self._error(404, "Não encontrado.")

    def _started(self, ok: bool) -> None:
        if not ok:
            return self._error(409, "Já existe uma tarefa em andamento.")
        self._json({"ok": True})


def create_server(settings, db, categories, port: int = 8765, cities=None) -> Server:
    """Cria o servidor em 127.0.0.1. Se a porta estiver ocupada, tenta as próximas."""
    last: OSError | None = None
    for p in ([port + i for i in range(10)] if port else [0]):
        try:
            return Server(("127.0.0.1", p), settings, db, categories, cities)
        except OSError as exc:
            last = exc
    raise OSError(f"Nenhuma porta livre a partir de {port}: {last}")
