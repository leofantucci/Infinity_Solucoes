"""Ponto de entrada do LocalLead Finder (painel web local no Firefox)."""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import webbrowser


def open_in_firefox(url: str) -> None:
    exe = shutil.which("firefox")
    if exe:
        subprocess.Popen([exe, "--new-tab", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        print("Firefox não encontrado no PATH; abrindo no navegador padrão.")
        webbrowser.open(url)


def main() -> int:
    parser = argparse.ArgumentParser(description="LocalLead Finder")
    parser.add_argument("--port", type=int, default=8765, help="porta local (padrão 8765)")
    parser.add_argument("--no-open", action="store_true", help="não abrir o navegador automaticamente")
    parser.add_argument("--tk", action="store_true", help="usar a interface Tkinter antiga (requer o pacote 'tk')")
    args = parser.parse_args()

    from categories import CategoryStore
    from cities import CityStore
    from config import load_settings
    from database import Database

    settings = load_settings()
    db = Database(settings.db_path)
    categories = CategoryStore(db, seed_path=settings.categories_file)
    cities = CityStore(db)

    if args.tk:
        try:
            from interface import App
        except ImportError:
            print("Tkinter não encontrado. No Manjaro: sudo pacman -S tk", file=sys.stderr)
            return 1
        App(settings, db, categories).mainloop()
        return 0

    from webapp import create_server
    try:
        server = create_server(settings, db, categories, args.port, cities)
    except OSError as exc:
        print(f"Não foi possível iniciar o servidor local: {exc}", file=sys.stderr)
        return 1
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    print(f"LocalLead Finder online em {url}  (Ctrl+C para encerrar)")
    if not args.no_open:
        open_in_firefox(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrando...")
    finally:
        server.jobs.cancel.cancel()
        server.server_close()
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
