"""Cidades de pesquisa: persistência SQLite, CRUD e seeding idempotente."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime

from services.dedupe import normalize_text

# Coordenadas do centro geográfico validadas no Nominatim/OpenStreetMap.
# Elas são apenas sementes; o usuário pode editar/geocodificar cada cidade.
INITIAL_CITIES = [
    {"name": "Araçatuba", "state": "São Paulo", "uf": "SP", "country": "Brasil",
     "latitude": -21.2079920, "longitude": -50.4390225},
    {"name": "São José do Rio Preto", "state": "São Paulo", "uf": "SP", "country": "Brasil",
     "latitude": -20.8125851, "longitude": -49.3804212},
    {"name": "Bauru", "state": "São Paulo", "uf": "SP", "country": "Brasil",
     "latitude": -22.3173803, "longitude": -49.0689778},
    {"name": "Pardinho", "state": "São Paulo", "uf": "SP", "country": "Brasil",
     "latitude": -23.0810065, "longitude": -48.3781499},
    {"name": "Bonito", "state": "Mato Grosso do Sul", "uf": "MS", "country": "Brasil",
     "latitude": -21.1264766, "longitude": -56.4902208},
]

SEED_FLAG = "cities_seeded_v1"


def valid_coordinates(latitude, longitude) -> bool:
    try:
        lat, lon = float(latitude), float(longitude)
    except (TypeError, ValueError):
        return False
    return -90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0 and not (lat == 0 and lon == 0)


@dataclass
class City:
    id: int | None
    name: str
    state: str
    uf: str
    country: str
    latitude: float
    longitude: float
    active: bool = True

    @property
    def display(self) -> str:
        suffix = self.uf or self.state
        return f"{self.name} — {suffix}" if suffix else self.name

    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "state": self.state, "uf": self.uf,
            "country": self.country, "latitude": self.latitude, "longitude": self.longitude,
            "active": self.active, "display": self.display,
        }


class CityStore:
    def __init__(self, db, seed: bool = True) -> None:
        self.db = db
        self.cities: dict[int, City] = {}
        self.load()
        if seed:
            self.seed_initial()

    def load(self) -> None:
        self.cities.clear()
        for row in self.db.query("SELECT * FROM cities ORDER BY name, state"):
            city = City(
                id=row["id"], name=row["name"], state=row["state"] or "", uf=row["uf"] or "",
                country=row["country"] or "Brasil", latitude=row["latitude"],
                longitude=row["longitude"], active=bool(row["active"]),
            )
            self.cities[city.id] = city

    def seed_initial(self) -> int:
        """Insere as cidades iniciais apenas na primeira inicialização do banco."""
        row = self.db.query("SELECT value FROM app_meta WHERE key=?", (SEED_FLAG,))
        if row:
            return 0
        inserted = 0
        for item in INITIAL_CITIES:
            try:
                if self.create(**item, validate_duplicate=False):
                    inserted += 1
            except ValueError:
                pass
        self.db.execute("INSERT OR REPLACE INTO app_meta (key, value) VALUES (?,?)", (SEED_FLAG, "1"))
        self.load()
        return inserted

    def all(self, active_only: bool = False) -> list[City]:
        cities = list(self.cities.values())
        if active_only:
            cities = [c for c in cities if c.active]
        return cities

    def options(self, active_only: bool = False, query: str = "") -> list[dict]:
        cities = self.all(active_only=active_only)
        if query:
            q = normalize_text(query)
            cities = [c for c in cities if q in normalize_text(c.name) or q in normalize_text(c.state)
                      or q in normalize_text(c.uf) or q in normalize_text(c.country)]
        return [c.to_dict() for c in cities]

    def get(self, city_id: int | None) -> City | None:
        return self.cities.get(city_id) if city_id is not None else None

    def find_duplicate(self, name: str, state: str, country: str,
                       exclude_id: int | None = None) -> City | None:
        identity = (normalize_text(name), normalize_text(state), normalize_text(country))
        for city in self.cities.values():
            if exclude_id is not None and city.id == exclude_id:
                continue
            if (normalize_text(city.name), normalize_text(city.state),
                    normalize_text(city.country)) == identity:
                return city
        return None

    def _clean(self, name, state, uf, country, latitude, longitude) -> dict:
        name = re.sub(r"\s+", " ", str(name or "")).strip()
        state = re.sub(r"\s+", " ", str(state or "")).strip()
        uf = re.sub(r"\s+", " ", str(uf or "")).strip().upper()
        country = re.sub(r"\s+", " ", str(country or "Brasil")).strip() or "Brasil"
        if not name:
            raise ValueError("Informe o nome da cidade.")
        if len(name) > 120 or len(state) > 120 or len(uf) > 8 or len(country) > 80:
            raise ValueError("Dados da cidade muito longos.")
        if not valid_coordinates(latitude, longitude):
            raise ValueError("Informe coordenadas válidas (latitude entre -90 e 90, longitude entre -180 e 180).")
        return {"name": name, "state": state, "uf": uf, "country": country,
                "latitude": float(latitude), "longitude": float(longitude)}

    def create(self, name: str, state: str = "", uf: str = "", country: str = "Brasil",
               latitude=None, longitude=None, active: bool = True,
               validate_duplicate: bool = True) -> City:
        data = self._clean(name, state, uf, country, latitude, longitude)
        if validate_duplicate and self.find_duplicate(data["name"], data["state"], data["country"]):
            raise ValueError(f"Cidade já cadastrada: {data['name']} — {data['state'] or data['uf']}.")
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        cur = self.db.execute(
            "INSERT INTO cities (name, name_key, state, state_key, uf, country, country_key, "
            "latitude, longitude, active, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (data["name"], normalize_text(data["name"]), data["state"], normalize_text(data["state"]),
             data["uf"], data["country"], normalize_text(data["country"]), data["latitude"],
             data["longitude"], int(bool(active)), now, now))
        self.load()
        return self.cities[cur.lastrowid]

    def update(self, city_id: int, name: str | None = None, state: str | None = None,
               uf: str | None = None, country: str | None = None, latitude=None,
               longitude=None, active: bool | None = None) -> City:
        current = self.get(city_id)
        if current is None:
            raise ValueError("Cidade não encontrada.")
        data = self._clean(name if name is not None else current.name,
                           state if state is not None else current.state,
                           uf if uf is not None else current.uf,
                           country if country is not None else current.country,
                           latitude if latitude is not None else current.latitude,
                           longitude if longitude is not None else current.longitude)
        dup = self.find_duplicate(data["name"], data["state"], data["country"], exclude_id=city_id)
        if dup:
            raise ValueError(f"Já existe uma cidade equivalente: {dup.display}.")
        self.db.execute(
            "UPDATE cities SET name=?, name_key=?, state=?, state_key=?, uf=?, country=?, country_key=?, "
            "latitude=?, longitude=?, active=?, updated_at=? WHERE id=?",
            (data["name"], normalize_text(data["name"]), data["state"], normalize_text(data["state"]),
             data["uf"], data["country"], normalize_text(data["country"]), data["latitude"],
             data["longitude"], int(bool(current.active if active is None else active)),
             datetime.now().strftime("%Y-%m-%d %H:%M"), city_id))
        self.load()
        return self.cities[city_id]

    def delete(self, city_id: int) -> bool:
        if city_id not in self.cities:
            return False
        self.db.execute("DELETE FROM cities WHERE id=?", (city_id,))
        self.load()
        return True
