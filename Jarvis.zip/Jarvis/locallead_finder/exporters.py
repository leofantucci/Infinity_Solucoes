"""Exportação para CSV (UTF-8), Excel (XLSX) e PDF."""
from __future__ import annotations

import textwrap
from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from models import NAO_INFORMADO, PRIORIDADE_ALTA, Company

EXPORT_FILTERS = {
    "todos": "Todos os resultados",
    "qualificados": "Apenas leads importantes (sem site, com contato)",
    "sem_site": "Apenas empresas sem site encontrado",
    "com_site": "Apenas empresas com site",
    "com_telefone": "Apenas empresas com telefone",
    "sem_telefone": "Apenas empresas sem telefone",
    "incompletos": "Apenas resultados com dados incompletos",
    "revisar": "Apenas casos para revisão manual",
    "alta_prioridade": "Apenas oportunidades de alta prioridade",
}

# Ordem das colunas exibidas e exportadas.
EXPORT_FIELDS = {
    "nome": "Nome",
    "telefone": "Telefone",
    "email": "E-mail",
    "redes_sociais": "Redes sociais",
    "site": "Link do site",
    "endereco": "Endereço",
    "avaliacao_google": "Avaliação Google",
    "observacao": "Observação",
    "cidade_uf": "Cidade / UF",
    "prioridade": "Prioridade",
    "categoria": "Categoria",
    "fonte": "Fonte",
    "fonte_url": "URL da fonte",
    "google_maps_url": "Google Maps",
    "verificacao_url": "URL da verificação",
    "data_pesquisa": "Data da pesquisa",
}

COLUMNS = [(key, label) for key, label in EXPORT_FIELDS.items()]
_LINK_FIELDS = {"site", "fonte_url", "google_maps_url", "verificacao_url"}


def filter_companies(companies: list[Company], mode: str) -> list[Company]:
    if mode == "qualificados":
        return [c for c in companies if (c.nome or "").strip()
                and ((c.telefone or "").strip() or (c.email or "").strip())
                and not (c.site or "").strip()]
    if mode == "sem_site":
        return [c for c in companies if not c.site]
    if mode == "com_site":
        return [c for c in companies if c.site]
    if mode == "com_telefone":
        return [c for c in companies if c.telefone]
    if mode == "sem_telefone":
        return [c for c in companies if not c.telefone]
    if mode == "incompletos":
        return [c for c in companies
                if not ((c.telefone or "").strip() or (c.email or "").strip()) or not (c.endereco or "").strip()]
    if mode == "revisar":
        return [c for c in companies if c.relevancia == "revisar"]
    if mode == "alta_prioridade":
        return [c for c in companies if c.prioridade == PRIORIDADE_ALTA]
    return list(companies)


def redes_sociais(c: Company) -> str:
    return " ; ".join(u for u in (c.instagram, c.facebook, c.youtube) if u)


def cidade_uf(c: Company) -> str:
    return " / ".join(x for x in (c.cidade, c.estado) if x)


def value_for(c: Company, attr: str):
    if attr == "redes_sociais":
        return redes_sociais(c)
    if attr == "cidade_uf":
        return cidade_uf(c)
    return getattr(c, attr, "")


def _cell(value) -> str:
    if value is None or value == "":
        return NAO_INFORMADO
    return str(value)


def _columns(fields: list[str] | None) -> list[tuple[str, str]]:
    if fields is None:
        return list(COLUMNS)
    invalid = [f for f in fields if f not in EXPORT_FIELDS]
    if not fields or invalid:
        raise ValueError("Selecione ao menos um campo válido para exportar.")
    wanted = set(fields)
    return [(key, label) for key, label in COLUMNS if key in wanted]


def to_dataframe(companies: list[Company], fields: list[str] | None = None) -> pd.DataFrame:
    columns = _columns(fields)
    rows = [{header: _cell(value_for(c, attr)) for attr, header in columns} for c in companies]
    return pd.DataFrame(rows, columns=[h for _, h in columns])


def export_csv(companies: list[Company], path: str | Path, fields: list[str] | None = None) -> Path:
    path = Path(path)
    # utf-8-sig = UTF-8 com BOM, para o Excel/LibreOffice reconhecerem os acentos
    to_dataframe(companies, fields).to_csv(path, index=False, encoding="utf-8-sig")
    return path


def export_excel(companies: list[Company], path: str | Path, fields: list[str] | None = None) -> Path:
    path = Path(path)
    df = to_dataframe(companies, fields)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Leads")
        ws = writer.sheets["Leads"]
        fill = PatternFill("solid", fgColor="1F4E78")
        for cell in ws[1]:
            cell.font, cell.fill = Font(bold=True, color="FFFFFF"), fill
            cell.alignment = Alignment(vertical="center", wrap_text=True)
        ws.freeze_panes = "B2"
        ws.auto_filter.ref = ws.dimensions
        colors = {"alta": "C6EFCE", "média": "FFEB9C", "baixa": "EDEDED"}
        for idx, header in enumerate(df.columns, 1):
            letter = get_column_letter(idx)
            longest = max([len(str(header))] + [len(str(v)) for v in df[header]])
            ws.column_dimensions[letter].width = min(max(12, longest + 2), 60)
            for row in range(2, len(df) + 2):
                cell = ws.cell(row=row, column=idx)
                if header in {EXPORT_FIELDS[k] for k in _LINK_FIELDS} and str(cell.value).startswith("http"):
                    cell.hyperlink = str(cell.value)
                    cell.font = Font(color="0563C1", underline="single")
                if header == "Prioridade" and cell.value in colors:
                    cell.fill = PatternFill("solid", fgColor=colors[cell.value])
    return path


# ---------- PDF sem dependências externas ----------
_PAGE_W, _PAGE_H, _MARGIN = 842.0, 595.0, 28.0
_FONT_SIZE = 6.0
_LINE_H = 7.5
_MAX_LINES = 6


def _escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _text(x: float, y: float, value: str, size: float, bold: bool = False,
          color: tuple[float, float, float] = (0, 0, 0)) -> str:
    value = str(value).encode("latin-1", "replace").decode("latin-1")
    r, g, b = color
    font = "F2" if bold else "F1"
    return f"{r:.3f} {g:.3f} {b:.3f} rg BT /{font} {size} Tf {x:.2f} {y:.2f} Td ({_escape(value)}) Tj ET\n"


def _wrap(value: str, width: float) -> list[str]:
    text = str(value).replace("\r", "")
    max_chars = max(4, int((width - 4) / (_FONT_SIZE * 0.48)))
    lines: list[str] = []
    for part in text.split("\n"):
        lines += textwrap.wrap(part, width=max_chars, break_long_words=True,
                               break_on_hyphens=False) or [""]
    if len(lines) > _MAX_LINES:
        lines = lines[:_MAX_LINES]
        lines[-1] = (lines[-1][: max(1, max_chars - 3)] + "...").encode("latin-1", "replace").decode("latin-1")
    return lines or [""]


def export_pdf(companies: list[Company], path: str | Path, fields: list[str] | None = None) -> Path:
    """Gera um PDF simples em paisagem, com todas as colunas selecionadas e paginação."""
    path = Path(path)
    df = to_dataframe(companies, fields)
    available = _PAGE_W - 2 * _MARGIN
    raw = []
    for header in df.columns:
        longest = max([len(str(header))] + [len(str(v)) for v in df[header]])
        raw.append(min(max(longest, 8), 48))
    total = sum(raw) or 1
    widths = [available * w / total for w in raw]

    pages: list[list[str]] = []
    content: list[str] = []
    y = _PAGE_H - _MARGIN

    def header(first: bool) -> None:
        nonlocal content, y
        if first:
            content.append(_text(_MARGIN, y - 13, "LocalLead Finder - leads", 13, True))
            content.append(_text(_MARGIN, y - 27,
                                 f"{len(df)} lead(s) · gerado em {datetime.now():%d/%m/%Y %H:%M}", 8))
            y -= 44
        row_h = 18.0
        content.append(f"0.12 0.31 0.47 rg {_MARGIN:.2f} {y - row_h:.2f} {available:.2f} {row_h:.2f} re f\n")
        x = _MARGIN
        for col, w in zip(df.columns, widths):
            content.append(_text(x + 2, y - 12, str(col), 7, True, (1, 1, 1)))
            x += w
        y -= row_h

    header(True)
    for i, (_, row) in enumerate(df.iterrows()):
        cells = [_wrap(row[col], w) for col, w in zip(df.columns, widths)]
        row_h = max(len(lines) for lines in cells) * _LINE_H + 4
        if y - row_h < _MARGIN:
            pages.append(content)
            content, y = [], _PAGE_H - _MARGIN
            header(False)
        if i % 2:
            content.append(f"0.96 0.98 1 rg {_MARGIN:.2f} {y - row_h:.2f} {available:.2f} {row_h:.2f} re f\n")
        x = _MARGIN
        for lines, w in zip(cells, widths):
            content.append(f"0.75 0.75 0.75 RG 0.4 w {x:.2f} {y - row_h:.2f} {w:.2f} {row_h:.2f} re S\n")
            for j, line in enumerate(lines):
                content.append(_text(x + 2, y - 10 - j * _LINE_H, line, _FONT_SIZE))
            x += w
        y -= row_h
    pages.append(content)

    objects: list[bytes] = [b"", b"", b"", b""]   # 1 catálogo, 2 páginas, 3 fonte, 4 fonte negrito
    objects[2] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"
    objects[3] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"

    def add(obj: bytes) -> int:
        objects.append(obj)
        return len(objects)

    page_ids = []
    for page in pages:
        stream = "".join(page).encode("latin-1", "replace")
        cid = add(b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream")
        page_ids.append(add(
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {_PAGE_W:.0f} {_PAGE_H:.0f}] "
            f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {cid} 0 R >>".encode()))
    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects[0] = b"<< /Type /Catalog /Pages 2 0 R >>"
    objects[1] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>".encode()

    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for i, obj in enumerate(objects, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objects) + 1}\n".encode() + b"0000000000 65535 f \n"
    for off in offsets[1:]:
        out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    path.write_bytes(bytes(out))
    return path
