"""Categorias comerciais: persistência no SQLite (ou JSON legado) + regras de associação."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from services.dedupe import normalize_text

_JSON_LIST_FIELDS = ("keywords", "synonyms")


def _regex_terms(terms: list[str]) -> str:
    """Monta um regex de nomes a partir dos termos, incluindo a versão sem acentos."""
    unique: list[str] = []
    for term in terms:
        term = str(term).strip()
        if not term:
            continue
        for value in (term, normalize_text(term)):
            if value and value not in unique:
                unique.append(value)
    return "|".join(re.escape(value) for value in unique)


def clean_terms(values) -> list[str]:
    """Remove vazios, espaços extras e duplicatas (comparação sem acentos/maiúsculas)."""
    if isinstance(values, str):
        values = re.split(r"[,;\n]+", values)
    out: list[str] = []
    seen: set[str] = set()
    for value in values or []:
        term = re.sub(r"\s+", " ", str(value or "")).strip(" ,;")
        if not term:
            continue
        key = normalize_text(term)
        if key and key not in seen:
            seen.add(key)
            out.append(term)
    return out


def _parse_tag(text: str) -> tuple[str, str]:
    key, _, value = str(text).partition("=")
    if not key.strip() or not value.strip():
        raise ValueError(f"Tag inválida '{text}'. Use o formato chave=valor (ex.: amenity=dentist).")
    return key.strip(), value.strip()


def _loads_list(raw) -> list[str]:
    if isinstance(raw, list):
        return clean_terms(raw)
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
    except (TypeError, ValueError):
        parsed = None
    if isinstance(parsed, list):
        return clean_terms(parsed)
    return clean_terms(str(raw))


def _loads_tags(raw) -> list[list[str]]:
    if isinstance(raw, list):
        groups = raw
    elif not raw:
        return []
    else:
        try:
            groups = json.loads(raw)
        except (TypeError, ValueError):
            groups = [g.split(",") for g in str(raw).split(";") if g.strip()]
    out: list[list[str]] = []
    for group in groups or []:
        if isinstance(group, str):
            group = group.split(",")
        tags = [str(t).strip() for t in group if str(t).strip()]
        if not tags:
            continue
        for tag in tags:
            _parse_tag(tag)
        out.append(tags)
    return out


@dataclass
class Category:
    key: str
    label: str
    aliases: list[str]
    queries: list[list[tuple[str, str]]]
    name_regex: str = ""
    id: int | None = None
    description: str = ""
    keywords: list[str] = field(default_factory=list)
    synonyms: list[str] = field(default_factory=list)
    osm_tags: list[list[str]] = field(default_factory=list)
    active: bool = True
    custom: bool = True

    @property
    def terms(self) -> list[str]:
        values = clean_terms([*self.keywords, *self.synonyms, *self.aliases])
        return values or [self.label]

    def to_dict(self) -> dict:
        return {
            "id": self.id, "key": self.key, "label": self.label, "name": self.label,
            "terms": self.terms, "description": self.description,
            "keywords": self.keywords, "synonyms": self.synonyms,
            "osm_tags": self.osm_tags, "active": self.active, "custom": self.custom,
        }


class CategoryStore:
    """Repositório de categorias. Use `CategoryStore(db, seed_path=...)` em produção.

    O construtor antigo `CategoryStore(caminho_json)` continua funcionando para
    compatibilidade e testes; nesse modo os dados ficam no arquivo JSON.
    """

    def __init__(self, source, seed_path: Path | str | None = None) -> None:
        from database import Database  # import tardio evita ciclo

        self.db = source if isinstance(source, Database) else None
        self.path = None if self.db is not None else Path(source)
        self.seed_path = Path(seed_path) if seed_path else None
        self.categories: dict[str, Category] = {}
        self.load()

    # ---------- leitura/carga ----------
    def _read_json(self, path: Path) -> dict:
        if not path.exists():
            return {}
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return raw if isinstance(raw, dict) else {}

    def _seed_from_json(self) -> None:
        if not self.seed_path:
            return
        raw = self._read_json(self.seed_path)
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        for key, item in raw.items():
            if key.startswith("_") or not isinstance(item, dict):
                continue
            label = str(item.get("label", key)).strip() or key
            aliases = clean_terms(item.get("aliases", []))
            if not aliases:
                aliases = [label]
            try:
                self.db.execute(
                    "INSERT OR IGNORE INTO categories "
                    "(key, name, name_key, description, keywords, synonyms, osm_tags, active, created_at, updated_at) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (key, label, normalize_text(label), "", json.dumps(aliases, ensure_ascii=False), "[]",
                     json.dumps(item.get("queries", []), ensure_ascii=False), 1, now, now))
            except Exception:
                continue

    def load(self) -> None:
        self.categories.clear()
        if self.db is not None:
            rows = self.db.query("SELECT * FROM categories ORDER BY name")
            if not rows:
                self._seed_from_json()
                rows = self.db.query("SELECT * FROM categories ORDER BY name")
            for row in rows:
                cat = self._from_row(row)
                self.categories[cat.key] = cat
            return
        raw = self._read_json(self.path) if self.path else {}
        for key, item in raw.items():
            if key.startswith("_") or not isinstance(item, dict):
                continue
            label = str(item.get("label", key)).strip() or key
            aliases = clean_terms(item.get("aliases", []))
            if not aliases:
                aliases = [label]
            queries = [[_parse_tag(t) for t in q] for q in item.get("queries", [])]
            name_regex = item["name_regex"] if "name_regex" in item else _regex_terms(aliases)
            self.categories[key] = Category(
                key=key, label=label, aliases=aliases, queries=queries, name_regex=name_regex,
                description=str(item.get("description", "")),
                keywords=aliases, synonyms=clean_terms(item.get("synonyms", [])),
                osm_tags=[[f"{k}={v}" for k, v in q] for q in queries], active=bool(item.get("active", True)),
            )

    def _from_row(self, row) -> Category:
        keywords = _loads_list(row["keywords"])
        synonyms = _loads_list(row["synonyms"])
        tags = _loads_tags(row["osm_tags"])
        queries = [[_parse_tag(t) for t in group] for group in tags]
        return Category(
            key=row["key"], label=row["name"], aliases=keywords, queries=queries,
            name_regex=_regex_terms([*keywords, *synonyms]) if not queries else "",
            id=row["id"], description=row["description"] or "", keywords=keywords,
            synonyms=synonyms, osm_tags=tags, active=bool(row["active"]),
        )

    def labels(self, active_only: bool = False) -> list[str]:
        return [c.label for c in self.categories.values() if c.active or not active_only]

    def options(self, active_only: bool = False, query: str = "") -> list[dict]:
        cats = list(self.categories.values())
        if active_only:
            cats = [c for c in cats if c.active]
        if query:
            q = normalize_text(query)
            cats = [c for c in cats if q in normalize_text(c.label) or q in normalize_text(c.key)
                    or any(q in normalize_text(t) for t in c.terms)]
        return [c.to_dict() for c in cats]

    # ---------- associação ----------
    def match(self, keyword: str, include_inactive: bool = False) -> Category | None:
        """Encontra a categoria pelo que o usuário digitou (rótulo, chave, alias ou subcategoria)."""
        kw = normalize_text(keyword)
        if not kw:
            return None
        cats = [c for c in self.categories.values() if include_inactive or c.active]
        for cat in cats:           # correspondência exata
            names = {normalize_text(cat.key), normalize_text(cat.label), *map(normalize_text, cat.terms)}
            if kw in names:
                return cat
        for cat in cats:           # correspondência parcial
            for alias in map(normalize_text, cat.terms):
                if len(alias) >= 4 and (alias in kw or kw in alias):
                    return cat
        return None

    def resolve(self, keyword: str) -> Category | None:
        """Interpreta o texto do usuário, inclusive termos separados por vírgula."""
        whole = self.match(keyword)
        if whole:
            return whole
        for part in re.split(r"[,;]+", keyword or ""):
            found = self.match(part.strip())
            if found:
                return found
        return None

    def find_duplicate(self, name: str, exclude_id: int | None = None,
                       exclude_key: str | None = None) -> Category | None:
        name_key = normalize_text(name)
        if not name_key:
            return None
        for cat in self.categories.values():
            if exclude_id is not None and cat.id == exclude_id:
                continue
            if exclude_key is not None and cat.key == exclude_key:
                continue
            if normalize_text(cat.label) == name_key or normalize_text(cat.key) == name_key:
                return cat
        return None

    # ---------- escrita ----------
    def _validate(self, name: str, keywords, synonyms, tags, exclude_id=None, exclude_key=None) -> tuple[str, list[str], list[str], list[list[str]]]:
        name = re.sub(r"\s+", " ", str(name or "")).strip()
        if not name:
            raise ValueError("Informe o nome da categoria.")
        if len(name) > 120:
            raise ValueError("O nome da categoria deve ter no máximo 120 caracteres.")
        dup = self.find_duplicate(name, exclude_id=exclude_id, exclude_key=exclude_key)
        if dup:
            raise ValueError(f"Já existe uma categoria equivalente: {dup.label}.")
        keywords = clean_terms(keywords)
        synonyms = clean_terms(synonyms)
        tags = _loads_tags(tags)
        if not keywords:
            keywords = [name]
        return name, keywords, synonyms, tags

    def create(self, name: str, description: str = "", keywords=None, synonyms=None,
               tags=None, active: bool = True, key: str | None = None) -> Category:
        name, keywords, synonyms, tags = self._validate(name, keywords, synonyms, tags)
        key = (key or normalize_text(name).replace(" ", "_") or "categoria").strip()
        if key in self.categories:
            key = f"{key}_{len(self.categories) + 1}"
        if self.db is not None:
            now = datetime.now().strftime("%Y-%m-%d %H:%M")
            self.db.execute(
                "INSERT INTO categories (key, name, name_key, description, keywords, synonyms, osm_tags, active, created_at, updated_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                (key, name, normalize_text(name), str(description or "").strip(),
                 json.dumps(keywords, ensure_ascii=False), json.dumps(synonyms, ensure_ascii=False),
                 json.dumps(tags, ensure_ascii=False), int(bool(active)), now, now))
        else:
            raw = self._read_json(self.path)
            raw[key] = {"label": name, "aliases": keywords, "queries": tags,
                        "description": str(description or "").strip(), "synonyms": synonyms,
                        "active": bool(active)}
            self.path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
        self.load()
        return self.categories[key]

    def update(self, category_id: int | None = None, key: str | None = None, name: str | None = None,
               description: str | None = None, keywords=None, synonyms=None, tags=None,
               active: bool | None = None) -> Category:
        current = self._get(category_id, key)
        if current is None:
            raise ValueError("Categoria não encontrada.")
        new_name, new_keywords, new_synonyms, new_tags = self._validate(
            name if name is not None else current.label,
            keywords if keywords is not None else current.keywords,
            synonyms if synonyms is not None else current.synonyms,
            tags if tags is not None else current.osm_tags,
            exclude_id=current.id, exclude_key=current.key)
        new_active = current.active if active is None else bool(active)
        new_desc = current.description if description is None else str(description).strip()
        if self.db is not None:
            self.db.execute(
                "UPDATE categories SET name=?, name_key=?, description=?, keywords=?, synonyms=?, "
                "osm_tags=?, active=?, updated_at=? WHERE id=?",
                (new_name, normalize_text(new_name), new_desc,
                 json.dumps(new_keywords, ensure_ascii=False), json.dumps(new_synonyms, ensure_ascii=False),
                 json.dumps(new_tags, ensure_ascii=False), int(new_active),
                 datetime.now().strftime("%Y-%m-%d %H:%M"), current.id))
        else:
            raw = self._read_json(self.path)
            raw[current.key] = {"label": new_name, "aliases": new_keywords, "queries": new_tags,
                                "description": new_desc, "synonyms": new_synonyms, "active": new_active}
            self.path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
        self.load()
        return self._get(category_id, key) or self.categories[current.key]

    def delete(self, category_id: int | None = None, key: str | None = None) -> bool:
        current = self._get(category_id, key)
        if current is None:
            return False
        if self.db is not None:
            self.db.execute("DELETE FROM categories WHERE id=?", (current.id,))
        else:
            raw = self._read_json(self.path)
            raw.pop(current.key, None)
            self.path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
        self.load()
        return True

    def get(self, category_id: int | None = None, key: str | None = None) -> Category | None:
        if category_id is not None:
            for cat in self.categories.values():
                if cat.id == category_id:
                    return cat
        if key:
            return self.categories.get(key)
        return None

    def _get(self, category_id: int | None, key: str | None) -> Category | None:
        return self.get(category_id, key)

    # ---------- compatibilidade com a API antiga ----------
    def add(self, key: str, label: str, aliases: list[str], tag_groups: list[list[str]]) -> None:
        """Adiciona/atualiza uma categoria com tags OSM (modo avançado)."""
        for group in tag_groups:
            for tag in group:
                _parse_tag(tag)
        existing = self.match(key, include_inactive=True) or self.match(label, include_inactive=True)
        if existing:
            self.update(category_id=existing.id, key=existing.key, name=label or key,
                        keywords=clean_terms([*existing.keywords, *aliases]) or [label or key],
                        tags=tag_groups)
        else:
            self.create(label or key, keywords=aliases or [label or key], tags=tag_groups,
                        key=normalize_text(key).replace(" ", "_") or None)

    def add_simple(self, label: str, terms: list[str]) -> Category:
        """Categoria personalizada simples: nome + termos relacionados (busca por nome/Google)."""
        label = re.sub(r"\s+", " ", str(label or "")).strip()
        terms = clean_terms(terms)
        if not label and terms:
            label = terms[0]
        if not label:
            raise ValueError("Informe o nome da categoria.")
        existing = self.match(label, include_inactive=True)
        if existing:
            merged = clean_terms([*existing.keywords, *terms]) or [label]
            return self.update(category_id=existing.id, key=existing.key, name=label,
                               keywords=merged, synonyms=existing.synonyms,
                               tags=existing.osm_tags, active=True)
        return self.create(label, keywords=terms or [label])
