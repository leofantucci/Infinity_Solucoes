"""Google Places API (New) – opcional. Usa apenas a API oficial e a máscara mínima de campos.

ATENÇÃO: telefone e site pertencem a níveis (SKUs) de cobrança mais altos que nome/endereço.
Confira os preços e cotas vigentes na documentação oficial antes de usar.
"""
from __future__ import annotations

from datetime import datetime

from models import Company, SearchParams
from services.dedupe import normalize_text
from utils import FetchError, HttpClient, ProviderError, haversine_km

ENDPOINT = "https://places.googleapis.com/v1/places:searchText"
FIELD_MASK = ",".join([
    "places.id", "places.displayName", "places.formattedAddress", "places.location",
    "places.googleMapsUri", "places.nationalPhoneNumber", "places.websiteUri",
    "places.rating", "places.userRatingCount", "places.businessStatus", "nextPageToken",
])


def parse_places(places: list[dict], city: str, state: str, label: str, now: str | None = None) -> list[Company]:
    now = now or datetime.now().strftime("%Y-%m-%d %H:%M")
    result = []
    for p in places:
        name = (p.get("displayName") or {}).get("text", "").strip()
        if not name:
            continue
        address = p.get("formattedAddress", "")
        norm_addr = normalize_text(address)
        loc = p.get("location") or {}
        rating = p.get("rating")
        reviews = p.get("userRatingCount")
        avaliacao = ""
        if rating is not None:
            avaliacao = f"{float(rating):.1f}".replace(".", ",")
            if reviews:
                avaliacao += f" ({int(reviews)} avaliações)"
        result.append(Company(
            nome=name, categoria=label, endereco=address,
            # só preenche cidade/estado se constarem no endereço retornado (nada é presumido)
            cidade=city if normalize_text(city) in norm_addr else "",
            estado=state if normalize_text(state) in norm_addr else "",
            latitude=loc.get("latitude"), longitude=loc.get("longitude"),
            telefone=p.get("nationalPhoneNumber", ""),
            site=p.get("websiteUri", ""),
            google_maps_url=p.get("googleMapsUri", ""),
            avaliacao_google=avaliacao,
            fonte="Google Places", source_id=p.get("id", ""),
            fonte_url=p.get("googleMapsUri", ""),
            data_pesquisa=now,
            ativo=p.get("businessStatus", "OPERATIONAL") == "OPERATIONAL",
        ))
    return result


class GooglePlacesProvider:
    source_name = "Google Places API"

    def __init__(self, settings, osm_provider, http: HttpClient, cancel, log=print) -> None:
        self.s, self.osm, self.http, self.cancel, self.log = settings, osm_provider, http, cancel, log

    def _center(self, params: SearchParams) -> dict:
        if params.latitude is not None and params.longitude is not None:
            return {"lat": float(params.latitude), "lon": float(params.longitude), "nome": "seletor de cidades"}
        return self.osm.geocode(params.city, params.state, params.country)

    def search(self, params: SearchParams) -> list[Company]:
        key = self.s.google_api_key
        if not key:
            raise ProviderError("Chave da Google Places API não configurada. Defina GOOGLE_PLACES_API_KEY no .env.")
        geo = self._center(params)
        self.log(f"Coordenadas da pesquisa: {geo['lat']:.6f}, {geo['lon']:.6f} ({geo.get('nome', '')}).")
        label = params.category_label or params.keyword
        terms = list(params.terms) or [params.keyword]
        terms = list(dict.fromkeys(t.strip() for t in terms if t.strip()))[: self.s.google_max_queries]
        self.log(f"Google Places: {len(terms)} consulta(s) serão feitas para '{label}'.")
        headers = {"Content-Type": "application/json", "X-Goog-Api-Key": key, "X-Goog-FieldMask": FIELD_MASK}
        found: dict[str, Company] = {}
        received = outside = no_coords = pages = 0
        radius_km = float(params.radius_km)
        for term in terms:
            if len(found) >= params.max_results:
                break
            self.cancel.check()
            self.log(f"Consultando a Google Places API (Text Search): {term}...")
            base_body = {
                "textQuery": f"{term} em {params.city}, {params.state or params.uf}, {params.country}",
                "languageCode": "pt-BR", "regionCode": "BR",
                "locationBias": {"circle": {
                    "center": {"latitude": geo["lat"], "longitude": geo["lon"]},
                    "radius": min(radius_km * 1000.0, 50000.0)}},
            }
            page_token = None
            seen_tokens: set[str] = set()
            while len(found) < params.max_results:
                remaining = params.max_results - len(found)
                body = dict(base_body)
                body["pageSize"] = max(1, min(20, remaining))
                if page_token:
                    body["pageToken"] = page_token
                try:
                    resp = self.http.post(ENDPOINT, json=body, headers=headers, min_interval=1.0)
                except FetchError as exc:
                    raise ProviderError(f"Falha de conexão com a Google Places API: {exc}") from exc
                if resp.status_code != 200:
                    try:
                        msg = resp.json().get("error", {}).get("message", "")
                    except ValueError:
                        msg = ""
                    hint = " Verifique a chave, se a Places API (New) está ativada e o faturamento do projeto." \
                        if resp.status_code in (400, 403) else ""
                    raise ProviderError(f"Google Places API respondeu HTTP {resp.status_code}: {msg}.{hint}")
                try:
                    data = resp.json()
                except ValueError as exc:
                    raise ProviderError("A Google Places API retornou uma resposta inválida.") from exc
                places = data.get("places", []) or []
                pages += 1
                received += len(places)
                for company in parse_places(places, params.city, params.state, label):
                    if company.latitude is None or company.longitude is None:
                        no_coords += 1
                        self.log(f"  Resultado sem coordenadas (mantido para diagnóstico): {company.nome}.")
                        k = company.source_id or company.nome
                        found.setdefault(k, company)
                        continue
                    dist = haversine_km(geo["lat"], geo["lon"], company.latitude, company.longitude)
                    if dist > radius_km:
                        outside += 1
                        continue
                    k = company.source_id or company.nome
                    found.setdefault(k, company)
                token = data.get("nextPageToken")
                if not token or token in seen_tokens:
                    break
                seen_tokens.add(token)
                page_token = token
                self.cancel.check()
        self.log(f"Google Places: {pages} página(s), {received} resultado(s) recebido(s), "
                 f"{outside} fora do raio, {no_coords} sem coordenadas, {len(found)} único(s).")
        return list(found.values())[: params.max_results]
