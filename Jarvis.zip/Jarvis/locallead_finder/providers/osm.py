"""OpenStreetMap: geocodificação (Nominatim) + busca de estabelecimentos (Overpass/Photon)."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime

from categories import CategoryStore
from models import Company, SearchParams
from services.dedupe import normalize_text
from services.geocoding import geocode_location
from services.social_finder import normalize_handle
from utils import FetchError, HttpClient, ProviderError, haversine_km


def _q(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def build_query(queries: list[list[tuple[str, str]]], name_regex: str,
                lat: float, lon: float, radius_m: int, limit: int) -> str:
    """Monta a consulta Overpass QL (OU entre queries, E entre tags de uma query)."""
    around = f"(around:{radius_m},{lat:.6f},{lon:.6f})"
    parts = []
    for query in queries:
        conds = "".join(f'["{_q(k)}"="{_q(v)}"]' for k, v in query)
        parts.append(f"  nwr{conds}{around};")
    if name_regex:
        parts.append(f'  nwr["name"~"{_q(name_regex)}",i]{around};')
    if not parts:
        raise ProviderError("Nenhum filtro de busca definido para este segmento.")
    return "[out:json][timeout:60];\n(\n" + "\n".join(parts) + f"\n);\nout center tags {limit};"


def _address(tags: dict) -> str:
    street = tags.get("addr:street", "")
    number = tags.get("addr:housenumber", "")
    first = ", ".join(x for x in (street, number) if x)
    suburb = tags.get("addr:suburb") or tags.get("addr:neighbourhood") or ""
    city = tags.get("addr:city", "")
    state = tags.get("addr:state", "")
    postcode = tags.get("addr:postcode", "")
    city_state = " - ".join(x for x in (city, state) if x)
    pieces = [first, suburb, city_state, postcode]
    return ", ".join(p for p in pieces if p)


def _is_active(tags: dict) -> bool:
    return not any(k.startswith(("disused:", "abandoned:", "was:", "closed")) for k in tags) \
        and tags.get("opening_hours") != "closed"


def parse_elements(elements: list[dict], label: str, center: tuple[float, float],
                   max_results: int, now: str | None = None,
                   radius_km: float | None = None) -> list[Company]:
    """Converte elementos do Overpass em Company. Campos ausentes ficam vazios (nada é inventado)."""
    now = now or datetime.now().strftime("%Y-%m-%d %H:%M")
    found: list[tuple[float, Company]] = []
    for el in elements:
        tags = el.get("tags") or {}
        name = (tags.get("name") or tags.get("brand") or "").strip()
        if not name:
            continue                      # sem nome não há como prospectar
        lat = el.get("lat", (el.get("center") or {}).get("lat"))
        lon = el.get("lon", (el.get("center") or {}).get("lon"))
        kind, oid = el.get("type", "node"), el.get("id")
        company = Company(
            nome=name,
            categoria=label,
            endereco=_address(tags),
            cidade=tags.get("addr:city", ""),
            estado=tags.get("addr:state", ""),
            latitude=lat, longitude=lon,
            telefone=(tags.get("phone") or tags.get("contact:phone") or tags.get("contact:mobile")
                      or tags.get("mobile") or tags.get("contact:whatsapp") or "").strip(),
            email=(tags.get("email") or tags.get("contact:email") or "").strip(),
            site=(tags.get("website") or tags.get("contact:website") or tags.get("url") or "").strip(),
            instagram=normalize_handle("instagram", tags.get("contact:instagram", "")),
            facebook=normalize_handle("facebook", tags.get("contact:facebook", "")),
            youtube=normalize_handle("youtube", tags.get("contact:youtube", "")),
            fonte="OpenStreetMap",
            source_id=f"{kind}/{oid}",
            fonte_url=f"https://www.openstreetmap.org/{kind}/{oid}",
            data_pesquisa=now,
            ativo=_is_active(tags),
        )
        dist = haversine_km(center[0], center[1], lat, lon) if lat is not None and lon is not None else 9e9
        if radius_km is not None and dist > radius_km:
            continue
        found.append((dist, company))
    found.sort(key=lambda t: t[0])
    return [c for _, c in found[:max_results]]


PHOTON_URL = "https://photon.komoot.io/api/"
_PHOTON_IGNORED_KEYS = {"place", "waterway", "highway", "natural", "boundary", "railway", "landuse"}


def parse_photon_features(features: list[dict], center: tuple[float, float], radius_km: float,
                          allowed_tags: set[tuple[str, str]] | None = None) -> list[dict]:
    """Converte resultados do Photon em candidatos OSM dentro do raio, sem inventar dados."""
    found = []
    seen: set[str] = set()
    for feature in features:
        props = feature.get("properties") or {}
        name = str(props.get("name") or "").strip()
        if not name or props.get("osm_key") in _PHOTON_IGNORED_KEYS:
            continue
        if allowed_tags is not None and (props.get("osm_key"), props.get("osm_value")) not in allowed_tags:
            continue
        coords = (feature.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        lon, lat = float(coords[0]), float(coords[1])
        dist = haversine_km(center[0], center[1], lat, lon)
        if dist > radius_km:
            continue
        kind = {"N": "node", "W": "way", "R": "relation"}.get(str(props.get("osm_type", "")).upper())
        oid = props.get("osm_id")
        if not kind or not oid:
            continue
        key = f"{kind}/{oid}"
        if key in seen:
            continue
        seen.add(key)
        found.append({"name": name, "kind": kind, "id": oid,
                      "lat": lat, "lon": lon, "props": props, "dist": dist})
    found.sort(key=lambda c: c["dist"])
    return found


class OSMProvider:
    source_name = "OpenStreetMap"

    def __init__(self, settings, db, categories: CategoryStore, http: HttpClient, cancel, log=print) -> None:
        self.s, self.db, self.categories = settings, db, categories
        self.http, self.cancel, self.log = http, cancel, log

    # ---------- Nominatim ----------
    def geocode(self, city: str, state: str, country: str) -> dict:
        return geocode_location(self.s, self.db, city, state, country, self.http, self.cancel, self.log)

    def _center(self, params: SearchParams) -> dict:
        if params.latitude is not None and params.longitude is not None:
            self.log(f"Usando coordenadas do seletor: {params.latitude:.6f}, {params.longitude:.6f}.")
            return {"lat": float(params.latitude), "lon": float(params.longitude), "nome": "seletor de cidades"}
        return self.geocode(params.city, params.state, params.country)

    # ---------- Overpass ----------
    def _overpass(self, query: str) -> list[dict]:
        key = "overpass:" + hashlib.sha1(query.encode()).hexdigest()
        cached = self.db.cache_get(key, self.s.cache_ttl_hours)
        if cached:
            self.log("Resultado do Overpass obtido do cache local (sem nova consulta).")
            return json.loads(cached)
        last = "sem resposta"
        for url in self.s.overpass_urls:
            self.log(f"Consultando Overpass API ({url.split('/')[2]})...")
            try:
                resp = self.http.post(url, data={"data": query}, timeout=45, retries=0,
                                      min_interval=self.s.overpass_min_interval)
            except FetchError as exc:
                last = str(exc)
                self.log(f"  Servidor indisponível: {exc}")
                continue
            if resp.status_code == 200:
                try:
                    elements = resp.json().get("elements", [])
                except ValueError:
                    last = "resposta inválida"
                    continue
                self.db.cache_set(key, json.dumps(elements))
                return elements
            last = f"HTTP {resp.status_code}"
            self.log(f"  Overpass respondeu {last}; tentando o próximo servidor.")
        raise ProviderError(f"Overpass indisponível ({last}). Aguarde alguns minutos e tente de novo.")

    def _overpass_tags(self, candidates: list[dict]) -> dict[str, dict]:
        """Busca as tags completas (telefone, site, e-mail) dos candidatos do Photon."""
        groups: dict[str, list[str]] = {}
        for c in candidates:
            groups.setdefault(c["kind"], []).append(str(c["id"]))
        parts = [f"  {kind}(id:{','.join(ids)});" for kind, ids in groups.items()]
        if not parts:
            return {}
        query = "[out:json][timeout:30];\n(\n" + "\n".join(parts) + "\n);\nout center tags;"
        try:
            elements = self._overpass(query)
        except ProviderError as exc:
            self.log(f"  Não foi possível obter os detalhes das empresas: {exc}")
            return {}
        return {f"{el.get('type')}/{el.get('id')}": el for el in elements}

    def _photon_features(self, term: str, params: SearchParams, geo: dict) -> list[dict]:
        key = "photon:" + hashlib.sha1(
            f"{normalize_text(term)}|{normalize_text(params.city)}|{geo['lat']:.5f}|{geo['lon']:.5f}".encode()
        ).hexdigest()
        cached = self.db.cache_get(key, self.s.cache_ttl_hours)
        if cached:
            self.log(f"  Photon: cache local para '{term}'.")
            return json.loads(cached)
        try:
            resp = self.http.get(PHOTON_URL, params={
                "q": f"{term} {params.city}", "limit": 50,
                "lat": geo["lat"], "lon": geo["lon"],
            }, timeout=20, retries=0, min_interval=1.0)
        except FetchError as exc:
            self.log(f"  Photon indisponível para '{term}': {exc}")
            return []
        if resp.status_code != 200:
            self.log(f"  Photon respondeu HTTP {resp.status_code} para '{term}'.")
            return []
        try:
            features = resp.json().get("features", [])
        except ValueError:
            self.log(f"  Photon retornou uma resposta inválida para '{term}'.")
            return []
        self.db.cache_set(key, json.dumps(features))
        return features

    def _photon_search(self, params: SearchParams, geo: dict, terms: list[str] | None = None,
                       label: str | None = None, allowed_tags: set[tuple[str, str]] | None = None) -> list[Company]:
        """Fallback: Photon localiza pelos termos e o Overpass completa as tags."""
        terms = list(dict.fromkeys(t for t in (terms or [params.keyword]) if t.strip()))
        # Photon é um serviço público: limita a quantidade de termos consultados.
        terms = terms[: max(1, min(self.s.osm_max_terms, 4))]
        label = label or params.keyword
        center = (geo["lat"], geo["lon"])
        candidates: dict[str, dict] = {}
        for term in terms:
            self.cancel.check()
            self.log(f"Buscando '{term}' pelo nome no Photon (OpenStreetMap)...")
            features = self._photon_features(term, params, geo)
            found = parse_photon_features(features, center, params.radius_km, allowed_tags)
            for cand in found:
                candidates.setdefault(f"{cand['kind']}/{cand['id']}", cand)
        ordered = sorted(candidates.values(), key=lambda c: c["dist"])
        ordered = ordered[: max(1, min(params.max_results * 2, 50))]
        self.log(f"Photon encontrou {len(ordered)} candidato(s) dentro do raio.")
        if not ordered:
            return []
        details = self._overpass_tags(ordered)
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        out: list[Company] = []
        for cand in ordered:
            key = f"{cand['kind']}/{cand['id']}"
            el = details.get(key)
            if el:
                parsed = parse_elements([el], label, center, 1, now=now, radius_km=params.radius_km)
                if parsed:
                    out.append(parsed[0])
                    continue
            props = cand["props"]
            tags = {
                "addr:street": props.get("street", ""), "addr:housenumber": props.get("housenumber", ""),
                "addr:suburb": props.get("district") or props.get("locality") or "",
                "addr:city": props.get("city", ""), "addr:state": props.get("state", ""),
                "addr:postcode": props.get("postcode", ""),
            }
            out.append(Company(
                nome=cand["name"], categoria=label, endereco=_address(tags),
                cidade=props.get("city", ""), estado=props.get("state", ""),
                latitude=cand["lat"], longitude=cand["lon"],
                telefone=str(props.get("phone") or "").strip(),
                email=str(props.get("email") or "").strip(),
                site=str(props.get("website") or "").strip(),
                fonte="OpenStreetMap", source_id=key,
                fonte_url=f"https://www.openstreetmap.org/{key}", data_pesquisa=now,
            ))
        return out

    def search(self, params: SearchParams) -> list[Company]:
        geo = self._center(params)
        self.log(f"Coordenadas da pesquisa: {geo['lat']:.6f}, {geo['lon']:.6f} ({geo.get('nome', '')}).")
        category = self.categories.match(params.keyword)
        terms = list(params.terms) or [params.keyword]
        terms = list(dict.fromkeys(t.strip() for t in terms if t.strip()))[: self.s.osm_max_terms]
        if category:
            label = category.label
            queries = category.queries
            if not queries:
                self.log(f"Categoria personalizada: {label} ({len(terms)} termo(s)).")
                return self._photon_search(params, geo, terms=terms, label=label)
            # Categorias com tags OSM não usam regex de nome: a consulta por nome é
            # cara e costuma estourar o tempo dos servidores públicos do Overpass.
            regex = ""
            self.log(f"Categoria reconhecida: {label} ({len(terms)} termo(s) preparado(s)).")
        else:
            self.log(f"Categoria não cadastrada: usando busca por nome/termos no Photon.")
            return self._photon_search(params, geo, terms=terms, label=params.keyword)
        limit = min(max(params.max_results * 5, 100), 2000)
        query = build_query(queries, regex, geo["lat"], geo["lon"], int(params.radius_km * 1000), limit)
        allowed = {tag for group in queries for tag in group}
        try:
            elements = self._overpass(query)
        except ProviderError as exc:
            self.log(f"AVISO: {exc}")
            self.log("Tentando a busca alternativa pelo Photon...")
            return self._photon_search(params, geo, terms=terms, label=label, allowed_tags=allowed)
        self.log(f"Overpass retornou {len(elements)} elemento(s).")
        if not elements:
            alt = self._photon_search(params, geo, terms=terms, label=label, allowed_tags=allowed)
            if alt:
                return alt
        result = parse_elements(elements, label, (geo["lat"], geo["lon"]), limit,
                                radius_km=params.radius_km)
        outside = len(elements) - len(result)
        if outside > 0:
            self.log(f"{len(result)} resultado(s) dentro do raio; {outside} descartado(s)/sem dados.")
        return result
