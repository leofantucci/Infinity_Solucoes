import unittest

from database import Database
from models import Company
from services.dedupe import deduplicate, fingerprint, is_duplicate, normalize_phone, normalize_text


class DedupeTests(unittest.TestCase):
    def test_normalize_text_remove_acentos_e_pontuacao(self):
        self.assertEqual(normalize_text("  Clínica  São-José, Ltda. "), "clinica sao jose ltda")

    def test_normalize_phone(self):
        self.assertEqual(normalize_phone("+55 (18) 3641-0000"), "1836410000")
        self.assertEqual(normalize_phone("(18) 3641-0000; (18) 99999-1111"), "1836410000")

    def test_mesmo_id_da_fonte_e_duplicata(self):
        a = Company(nome="A", fonte="OpenStreetMap", source_id="node/1")
        b = Company(nome="Outro nome", fonte="OpenStreetMap", source_id="node/1")
        self.assertTrue(is_duplicate(a, b))

    def test_fingerprint_nome_endereco_telefone(self):
        a = Company(nome="Dr. João", endereco="Rua A, 10", telefone="(18) 3641-0000")
        b = Company(nome="DR JOAO", endereco="rua a 10", telefone="18 3641 0000")
        self.assertEqual(fingerprint(a), fingerprint(b))
        self.assertTrue(is_duplicate(a, b))

    def test_mesmo_nome_e_telefone_com_enderecos_diferentes(self):
        a = Company(nome="Mercado Bom", endereco="Rua A", telefone="1836410000", fonte="OpenStreetMap", source_id="node/1")
        b = Company(nome="Mercado Bom", endereco="R. A, 10 - Centro", telefone="(18) 3641-0000", fonte="Google Places", source_id="abc")
        self.assertTrue(is_duplicate(a, b))

    def test_empresas_diferentes_nao_sao_duplicatas(self):
        a = Company(nome="Mercado Bom", endereco="Rua A", telefone="1836410000")
        b = Company(nome="Mercado Bom", endereco="Rua B", telefone="1836419999")
        self.assertFalse(is_duplicate(a, b))

    def test_deduplicate_mescla_dados_faltantes(self):
        a = Company(nome="Clínica X", telefone="1836410000", fonte="OpenStreetMap", source_id="node/1")
        b = Company(nome="Clinica X", telefone="(18) 3641-0000", site="https://x.com.br", fonte="Google Places", source_id="g1")
        result = deduplicate([a, b, Company(nome="Outra", telefone="1899990000")])
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0].site, "https://x.com.br")

    def test_banco_nao_insere_duplicata(self):
        db = Database(":memory:")
        first, new1 = db.upsert(Company(nome="Clínica X", telefone="1836410000", fonte="OpenStreetMap", source_id="node/1"))
        second, new2 = db.upsert(Company(nome="CLINICA X", telefone="(18) 3641-0000", fonte="Google Places", source_id="g1", site="https://x.com"))
        self.assertTrue(new1)
        self.assertFalse(new2)
        self.assertEqual(first, second)
        self.assertEqual(len(db.all()), 1)
        self.assertEqual(db.all()[0].site, "https://x.com")


if __name__ == "__main__":
    unittest.main()
