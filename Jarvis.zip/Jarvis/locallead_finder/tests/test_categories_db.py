import unittest

from categories import CategoryStore
from config import load_settings
from database import Database


class CategoryDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.store = CategoryStore(self.db, seed_path=load_settings().categories_file)

    def test_seed_idempotente_e_crud(self):
        self.assertEqual(len(self.store.options(active_only=False)), 16)
        self.assertEqual(len(CategoryStore(self.db, seed_path=load_settings().categories_file).options()), 16)

        cat = self.store.create(
            "Pet shop", description="Banho, tosa e produtos",
            keywords=["pet shop", "banho e tosa"], synonyms=["petshop"],
            tags=["shop=pet", "amenity=veterinary"])
        self.assertIsNotNone(cat.id)
        self.assertEqual(self.store.match("banho e tosa").label, "Pet shop")
        self.assertEqual(len(cat.osm_tags), 2)

        with self.assertRaises(ValueError):
            self.store.create("Pet shop", keywords=["pet"])

        updated = self.store.update(cat.id, name="Pet shop e veterinária", active=False)
        self.assertFalse(updated.active)
        self.assertEqual(updated.label, "Pet shop e veterinária")
        self.assertNotIn(updated.id, [c["id"] for c in self.store.options(active_only=True)])

        self.assertTrue(self.store.delete(category_id=cat.id))
        self.assertIsNone(self.store.match("banho e tosa"))
        self.assertEqual(len(self.store.options(active_only=False)), 16)

    def test_tags_invalidas_nao_sao_aceitas(self):
        with self.assertRaises(ValueError):
            self.store.create("Inválida", tags=["sem valor"])


if __name__ == "__main__":
    unittest.main()
