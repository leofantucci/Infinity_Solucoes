import json
import threading
import unittest
import urllib.error
import urllib.request

from categories import CategoryStore
from config import load_settings
from database import Database
from webapp import create_server, parse_params


class WebManagementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.settings = load_settings()
        cls.db = Database(":memory:")
        cls.server = create_server(
            cls.settings, cls.db, CategoryStore(cls.db, seed_path=cls.settings.categories_file), port=0)
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def call(self, path, body=None):
        headers = {"Content-Type": "application/json", "X-LLF-Token": self.server.token}
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, headers=headers,
                                     method="POST" if body is not None else "GET")
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def test_crud_cidade(self):
        status, body = self.call("/api/cities?all=1")
        self.assertEqual(status, 200)
        self.assertEqual(len(body["cities"]), 5)

        status, body = self.call("/api/city", {
            "name": "Birigui", "state": "São Paulo", "uf": "SP", "country": "Brasil",
            "latitude": -21.2886, "longitude": -50.3400})
        self.assertEqual(status, 200)
        city = next(c for c in body["cities"] if c["name"] == "Birigui")

        status, body = self.call("/api/city/update", {"id": city["id"], "active": False})
        self.assertEqual(status, 200)
        self.assertFalse(next(c for c in body["cities"] if c["id"] == city["id"])["active"])

        status, body = self.call("/api/city/delete", {"id": city["id"]})
        self.assertEqual(status, 200)
        self.assertNotIn(city["id"], [c["id"] for c in body["cities"]])

        self.assertEqual(self.call("/api/city", {"name": "X", "latitude": 0, "longitude": 0})[0], 400)
        self.assertEqual(self.call("/api/city/delete", {"id": 99999})[0], 404)

    def test_crud_categoria(self):
        status, body = self.call("/api/category", {
            "name": "Pet shop", "description": "Banho e tosa",
            "keywords": ["pet shop", "banho e tosa"], "synonyms": ["petshop"],
            "osm_tags": "shop=pet; amenity=veterinary"})
        self.assertEqual(status, 200)
        cat = next(c for c in body["categories"] if c["label"] == "Pet shop")
        self.assertTrue(cat["osm_tags"])

        status, body = self.call("/api/category/update", {
            "id": cat["id"], "name": "Pet shop e veterinária", "active": False})
        self.assertEqual(status, 200)
        self.assertFalse(next(c for c in body["categories"] if c["id"] == cat["id"])["active"])

        status, body = self.call("/api/categories?all=1&q=pet")
        self.assertEqual(status, 200)
        self.assertTrue(any(c["id"] == cat["id"] for c in body["categories"]))

        status, body = self.call("/api/category/delete", {"id": cat["id"]})
        self.assertEqual(status, 200)
        self.assertNotIn(cat["id"], [c["id"] for c in body["categories"]])

        self.assertEqual(self.call("/api/category", {"name": "Pet shop", "osm_tags": "invalida"})[0], 400)
        self.assertEqual(self.call("/api/category/delete", {"id": 99999})[0], 404)

    def test_parse_params_com_coordenadas(self):
        p = parse_params({"keyword": "vidraçaria", "city": "Araçatuba", "state": "SP",
                          "latitude": "-21.207992", "longitude": "-50.4390225", "city_id": "1"})
        self.assertEqual((p.city_id, p.uf), (1, ""))
        self.assertAlmostEqual(p.latitude, -21.207992)
        with self.assertRaises(ValueError):
            parse_params({"keyword": "x", "city": "y", "latitude": "0", "longitude": "0"})
        with self.assertRaises(ValueError):
            parse_params({"keyword": "x", "city": "y", "latitude": "abc", "longitude": "1"})


if __name__ == "__main__":
    unittest.main()
