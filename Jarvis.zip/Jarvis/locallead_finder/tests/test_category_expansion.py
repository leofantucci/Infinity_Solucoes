import unittest

from categories import CategoryStore
from config import load_settings
from services.category_expansion import expand_terms, resolve_context, split_terms


class CategoryExpansionTests(unittest.TestCase):
    def test_termo_especifico_tem_prioridade(self):
        terms = expand_terms("Assistência técnica de computadores")
        self.assertEqual(terms[0], "Assistência técnica de computadores")
        self.assertTrue(any("notebook" in t.lower() for t in terms))
        self.assertTrue(any("informática" in t.lower() for t in terms))

    def test_contexto_com_categoria_do_banco(self):
        store = CategoryStore(load_settings().categories_file)
        category, label, terms = resolve_context(store, "Assistência técnica de computadores")
        self.assertEqual(label, "Assistência técnica")
        self.assertIsNotNone(category)
        self.assertEqual(terms[0], "Assistência técnica de computadores")

    def test_split_terms_preserva_compostos(self):
        self.assertEqual(split_terms("pet shop, banho e tosa; pet shop 24 horas"),
                         ["pet shop", "banho e tosa", "pet shop 24 horas"])


if __name__ == "__main__":
    unittest.main()
