import sqlite3
import tempfile
import unittest
from pathlib import Path

from database import Database


class DatabaseMigrationTests(unittest.TestCase):
    def test_migra_banco_antigo_sem_perder_dados(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "antigo.sqlite3"
            conn = sqlite3.connect(path)
            conn.execute("CREATE TABLE companies (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT)")
            conn.execute("INSERT INTO companies (nome) VALUES ('Empresa antiga')")
            conn.commit()
            conn.close()

            db = Database(path)
            rows = db.all()
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0].nome, "Empresa antiga")
            columns = {r["name"] for r in db.query("PRAGMA table_info(companies)")}
            self.assertTrue({"k_nameaddr", "k_phone", "relevancia", "relevancia_motivo"} <= columns)
            indexes = {r["name"] for r in db.query(
                "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='companies'")}
            self.assertTrue({"idx_k_nameaddr", "idx_k_phone"} <= indexes)
            db.close()


if __name__ == "__main__":
    unittest.main()
