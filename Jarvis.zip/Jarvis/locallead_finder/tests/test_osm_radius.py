import unittest

from providers.osm import parse_elements, parse_photon_features


class OSMRadiusTests(unittest.TestCase):
    def test_photon_respeita_raio_e_tipo(self):
        center = (-21.207992, -50.4390225)
        features = [
            {"geometry": {"coordinates": [-50.4395, -21.2085]},
             "properties": {"name": "Vidraçaria Perto", "osm_key": "shop", "osm_value": "glass",
                            "osm_type": "N", "osm_id": 1, "city": "Araçatuba"}},
            {"geometry": {"coordinates": [-50.4395, -22.5000]},
             "properties": {"name": "Vidraçaria Longe", "osm_key": "shop", "osm_value": "glass",
                            "osm_type": "N", "osm_id": 2}},
            {"geometry": {"coordinates": [-50.4395, -21.2080]},
             "properties": {"name": "Farmácia", "osm_key": "amenity", "osm_value": "pharmacy",
                            "osm_type": "N", "osm_id": 3}},
        ]
        found = parse_photon_features(features, center, radius_km=5, allowed_tags={("shop", "glass")})
        self.assertEqual([c["name"] for c in found], ["Vidraçaria Perto"])

    def test_overpass_respeita_raio(self):
        center = (-21.207992, -50.4390225)
        elements = [
            {"type": "node", "id": 10, "lat": -21.2085, "lon": -50.4395,
             "tags": {"name": "Perto", "shop": "glass"}},
            {"type": "node", "id": 11, "lat": -22.5000, "lon": -50.4395,
             "tags": {"name": "Longe", "shop": "glass"}},
        ]
        found = parse_elements(elements, "Vidraçarias", center, 50, radius_km=5)
        self.assertEqual([c.nome for c in found], ["Perto"])
        self.assertEqual(found[0].source_id, "node/10")


class FakeResponse:
    status_code = 200

    def __init__(self, data):
        self._data = data

    def json(self):
        return self._data


class FakeHttp:
    def __init__(self, elements):
        self.elements = elements
        self.calls = []

    def post(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return FakeResponse({"elements": self.elements})


class OSMProviderSearchTests(unittest.TestCase):
    def test_busca_usa_coordenadas_e_raio_sem_geocodificar(self):
        from categories import CategoryStore
        from config import load_settings
        from database import Database
        from models import SearchParams
        from providers.osm import OSMProvider
        from utils import CancelToken

        settings = load_settings()
        db = Database(":memory:")
        provider = OSMProvider(settings, db, CategoryStore(settings.categories_file),
                               FakeHttp([
                                   {"type": "node", "id": 1, "lat": -21.2080, "lon": -50.4390,
                                    "tags": {"name": "Dentista Perto", "amenity": "dentist"}},
                                   {"type": "node", "id": 2, "lat": -22.5000, "lon": -50.4390,
                                    "tags": {"name": "Dentista Longe", "amenity": "dentist"}},
                               ]), CancelToken(), lambda *a: None)
        params = SearchParams(keyword="dentista", city="Araçatuba", state="SP", country="Brasil",
                              radius_km=5, max_results=50, latitude=-21.207992, longitude=-50.4390225,
                              terms=("dentista",))
        found = provider.search(params)
        self.assertEqual([c.nome for c in found], ["Dentista Perto"])
        self.assertEqual(len(provider.http.calls), 1)


if __name__ == "__main__":
    unittest.main()
