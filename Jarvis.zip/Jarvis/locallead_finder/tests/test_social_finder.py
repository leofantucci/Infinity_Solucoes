import unittest

from services.social_finder import classify_url, extract_social_links, normalize_handle

HTML = """
<html><head><script type="application/ld+json">{"@type":"Dentist","sameAs":["https://www.facebook.com/clinicaexemplo"]}</script></head>
<body>
<a href="https://www.instagram.com/clinicaexemplo/">Insta</a>
<a href="https://instagram.com/clinicaexemplo?hl=pt">Insta de novo</a>
<a href="https://www.instagram.com/p/ABC123/">post</a>
<a href="https://www.facebook.com/sharer/sharer.php?u=x">compartilhar</a>
<a href="https://www.facebook.com/people/Fulano/1000">pessoal</a>
<a href="https://www.youtube.com/watch?v=abc">vídeo</a>
<a href="https://www.youtube.com/@clinicaexemplo">canal</a>
</body></html>
"""


class SocialTests(unittest.TestCase):
    def test_extrai_somente_perfis(self):
        links = extract_social_links(HTML)
        self.assertEqual(links["instagram"], ["https://www.instagram.com/clinicaexemplo/"])
        self.assertEqual(links["facebook"], ["https://www.facebook.com/clinicaexemplo/"])
        self.assertEqual(links["youtube"], ["https://www.youtube.com/@clinicaexemplo"])

    def test_ignora_compartilhamento_posts_e_perfis_pessoais(self):
        for url in ("https://www.facebook.com/sharer/sharer.php?u=x", "https://www.instagram.com/p/ABC/",
                    "https://www.facebook.com/people/Fulano/1000", "https://www.youtube.com/watch?v=1",
                    "https://www.instagram.com/", "https://example.com/instagram"):
            self.assertIsNone(classify_url(url), url)

    def test_normalize_handle(self):
        self.assertEqual(normalize_handle("instagram", "@clinica.x"), "https://www.instagram.com/clinica.x/")
        self.assertEqual(normalize_handle("facebook", "https://facebook.com/clinicax"), "https://www.facebook.com/clinicax/")
        self.assertEqual(normalize_handle("instagram", "https://www.facebook.com/clinicax"), "")
        self.assertEqual(normalize_handle("instagram", ""), "")


if __name__ == "__main__":
    unittest.main()
