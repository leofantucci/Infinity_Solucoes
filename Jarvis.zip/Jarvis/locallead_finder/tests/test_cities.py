import unittest

from cities import CityStore, INITIAL_CITIES, valid_coordinates
from database import Database


class CityTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.store = CityStore(self.db)

    def test_seed_idempotente(self):
        self.assertEqual(len(self.store.options()), len(INITIAL_CITIES))
        self.assertEqual(len(CityStore(self.db).options()), len(INITIAL_CITIES))
        names = {c["name"] for c in self.store.options()}
        self.assertTrue({"Araçatuba", "São José do Rio Preto", "Bauru", "Pardinho", "Bonito"} <= names)

    def test_crud_e_duplicidade(self):
        city = self.store.create("Birigui", state="São Paulo", uf="SP",
                                 latitude=-21.2886, longitude=-50.3400)
        self.assertIsNotNone(city.id)
        self.assertEqual(city.display, "Birigui — SP")
        with self.assertRaises(ValueError):
            self.store.create("Birigui", state="São Paulo", latitude=-21.2, longitude=-50.3)

        updated = self.store.update(city.id, name="Birigui", uf="sp", active=False)
        self.assertFalse(updated.active)
        self.assertNotIn(city.id, [c["id"] for c in self.store.options(active_only=True)])

        self.assertTrue(self.store.delete(city.id))
        self.assertIsNone(self.store.get(city.id))

    def test_coordenadas_invalidas(self):
        self.assertFalse(valid_coordinates(0, 0))
        self.assertFalse(valid_coordinates(91, 10))
        self.assertFalse(valid_coordinates("x", 10))
        with self.assertRaises(ValueError):
            self.store.create("Sem coordenadas")


if __name__ == "__main__":
    unittest.main()
