import unittest

from models import (PRIORIDADE_ALTA, PRIORIDADE_BAIXA, PRIORIDADE_MEDIA, SITE_ENCONTRADO, SITE_INCONCLUSIVO,
                    SITE_NAO_INFORMADO, SITE_NENHUM, Company)
from services.lead_classifier import classify


def company(**kw) -> Company:
    base = dict(nome="Clínica Exemplo", telefone="(18) 3641-0000", ativo=True)
    base.update(kw)
    return Company(**base)


class ClassifierTests(unittest.TestCase):
    def test_alta_sem_site_apos_verificacao_com_telefone(self):
        prio, motivo = classify(company(status_site=SITE_NENHUM))
        self.assertEqual(prio, PRIORIDADE_ALTA)
        self.assertIn("nenhum site", motivo.lower())

    def test_nenhum_site_sem_telefone_nao_e_alta(self):
        self.assertEqual(classify(company(status_site=SITE_NENHUM, telefone=""))[0], PRIORIDADE_MEDIA)

    def test_alta_com_email_sem_telefone(self):
        c = company(status_site=SITE_NENHUM, telefone="", email="contato@exemplo.com")
        self.assertEqual(classify(c)[0], PRIORIDADE_ALTA)

    def test_campo_vazio_da_fonte_nunca_e_alta(self):
        prio, motivo = classify(company(status_site=SITE_NAO_INFORMADO))
        self.assertEqual(prio, PRIORIDADE_MEDIA)
        self.assertIn("verificada", motivo)

    def test_inconclusivo_e_media(self):
        self.assertEqual(classify(company(status_site=SITE_INCONCLUSIVO))[0], PRIORIDADE_MEDIA)

    def test_site_profissional_e_baixa(self):
        c = company(status_site=SITE_ENCONTRADO, site="https://x.com.br", verificado_em="2026-01-01")
        self.assertEqual(classify(c)[0], PRIORIDADE_BAIXA)

    def test_site_com_deficiencias_observaveis_e_media(self):
        c = company(status_site=SITE_ENCONTRADO, site="http://x.com.br", verificado_em="2026-01-01",
                    site_problemas="não usa HTTPS | sem meta viewport (provável layout não responsivo)")
        prio, motivo = classify(c)
        self.assertEqual(prio, PRIORIDADE_MEDIA)
        self.assertIn("HTTPS", motivo)

    def test_empresa_inativa_e_baixa(self):
        self.assertEqual(classify(company(status_site=SITE_NENHUM, ativo=False))[0], PRIORIDADE_BAIXA)

    def test_rede_social_nao_conta_como_ausencia_de_site(self):
        c = company(status_site=SITE_NAO_INFORMADO, instagram="https://www.instagram.com/clinicaexemplo/")
        prio, motivo = classify(c)
        self.assertEqual(prio, PRIORIDADE_MEDIA)
        self.assertIn("Instagram", motivo)


if __name__ == "__main__":
    unittest.main()
