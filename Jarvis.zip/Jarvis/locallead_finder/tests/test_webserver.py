import json
import threading
import unittest
import urllib.error
import urllib.request

from categories import CategoryStore
from config import load_settings
from database import Database
from models import Company
from webapp import create_server, parse_params


class WebServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.settings = load_settings()
        cls.db = Database(":memory:")
        cls.server = create_server(cls.settings, cls.db, CategoryStore(cls.settings.categories_file), port=0)
        cls.port = cls.server.server_address[1]
        cls.base = f"http://127.0.0.1:{cls.port}"
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cid, _ = cls.db.upsert(Company(nome="Clínica <b>X</b>", telefone="1836410000", prioridade="alta",
                                       fonte="OpenStreetMap", source_id="node/1"))
        cid2, _ = cls.db.upsert(Company(nome="Empresa B", telefone="1899990000", email="b@exemplo.com",
                                        prioridade="alta", fonte="OpenStreetMap", source_id="node/2"))
        cls.cid, cls.cid2 = cid, cid2
        cls.server.jobs.ids = [cid, cid2]

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def call(self, path, body=None, token=True, host=None):
        headers = {"Content-Type": "application/json"}
        if token:
            headers["X-LLF-Token"] = self.server.token
        if host:
            headers["Host"] = host
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, headers=headers,
                                     method="POST" if body is not None else "GET")
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, r.read(), r.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read(), e.headers

    def test_index_traz_token_e_cabecalhos_de_seguranca(self):
        status, body, headers = self.call("/", token=False)
        self.assertEqual(status, 200)
        html = body.decode()
        self.assertIn(self.server.token, html)
        self.assertIn("Somente leads importantes", html)
        self.assertIn('id="exportFields"', html)
        self.assertIn('id="customTerm"', html)
        self.assertIn('id="leadFilter"', html)
        self.assertIn('id="catModal"', html)
        self.assertIn('id="cityModal"', html)
        self.assertIn('id="confirmModal"', html)
        self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])

    def test_api_exige_token_e_host_local(self):
        self.assertEqual(self.call("/api/config", token=False)[0], 403)
        self.assertEqual(self.call("/api/search", {}, token=False)[0], 403)
        self.assertEqual(self.call("/api/config", host="evil.example.com")[0], 403)
        self.assertEqual(self.call("/api/config")[0], 200)

    def test_resultados_exportacao_e_validacao(self):
        status, body, _ = self.call("/api/results")
        results = json.loads(body)["results"]
        self.assertEqual(results[0]["nome"], "Clínica <b>X</b>")
        self.assertEqual(results[1]["email"], "b@exemplo.com")

        status, body, headers = self.call("/api/export?kind=csv&filter=alta_prioridade")
        self.assertEqual(status, 200)
        self.assertIn("attachment", headers["Content-Disposition"])
        self.assertIn("não informado".encode(), body)

        status, body, _ = self.call(f"/api/export?kind=csv&filter=todos&ids={self.cid2}")
        self.assertEqual(status, 200)
        self.assertIn("Empresa B".encode(), body)
        self.assertNotIn("Clínica".encode(), body)

        status, body, headers = self.call("/api/export?kind=csv&filter=todos&fields=nome,email")
        self.assertEqual(status, 200)
        self.assertTrue(body.decode("utf-8-sig").startswith("Nome,E-mail"))

        status, body, headers = self.call("/api/export?kind=pdf&filter=todos")
        self.assertEqual(status, 200)
        self.assertEqual(headers["Content-Type"], "application/pdf")
        self.assertTrue(body.startswith(b"%PDF-1.4"))

        self.assertEqual(self.call("/api/export?kind=exe&filter=todos")[0], 400)
        self.assertEqual(self.call("/api/export?kind=csv&filter=todos&fields=inexistente")[0], 400)
        self.assertEqual(self.call("/api/export?kind=csv&filter=todos&ids=0")[0], 400)
        self.assertEqual(self.call("/api/search", {"keyword": "", "city": ""})[0], 400)
        self.assertEqual(self.call("/api/search", {"keyword": "x", "city": "y", "source": "Google Places API"})[0], 400)

    def test_config_e_observacao(self):
        status, body, _ = self.call("/api/config")
        config = json.loads(body)
        self.assertEqual(len(config["category_options"]), 16)
        labels = [o["label"] for o in config["category_options"]]
        self.assertIn("Salão de beleza", labels)
        self.assertIn("Assistência técnica", labels)
        self.assertEqual(len(config["export_fields"]), 16)
        self.assertTrue(config["default_qualified"])

        self.assertEqual(self.call("/api/observation", {"id": self.cid, "observacao": "Ligar amanhã"})[0], 200)
        status, body, _ = self.call("/api/results")
        self.assertEqual(json.loads(body)["results"][0]["observacao"], "Ligar amanhã")
        self.assertEqual(self.call("/api/observation", {"id": 9999, "observacao": "x"})[0], 404)
        self.assertEqual(self.call("/api/observation", {"id": "x"})[0], 400)

    def test_parse_params(self):
        p = parse_params({"keyword": " dentista ", "city": "Birigui", "state": "São Paulo", "country": "Brasil",
                          "radius": "5,5", "max": "20"})
        self.assertEqual((p.keyword, p.radius_km, p.max_results), ("dentista", 5.5, 20))
        with self.assertRaises(ValueError):
            parse_params({"keyword": "a", "city": "b", "radius": "999", "max": 10})


if __name__ == "__main__":
    unittest.main()
