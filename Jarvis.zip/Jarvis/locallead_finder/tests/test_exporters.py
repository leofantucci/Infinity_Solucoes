import tempfile
import unittest
from pathlib import Path

import pandas as pd

import exporters
from models import Company


def sample():
    return [
        Company(nome="A", telefone="1836410000", email="a@exemplo.com", prioridade="alta", site="",
                instagram="https://www.instagram.com/a/", avaliacao_google="4,8 (10 avaliações)",
                observacao="Ligar à tarde", cidade="Birigui", estado="SP", categoria="Dentistas",
                fonte="OpenStreetMap", fonte_url="https://www.openstreetmap.org/node/1",
                data_pesquisa="2026-10-31 10:00"),
        Company(nome="B", telefone="", prioridade="baixa", site="https://b.com", latitude=-21.1, longitude=-50.2),
        Company(nome="C", telefone="1899990000", prioridade="média", site=""),
    ]


class ExportTests(unittest.TestCase):
    def test_filtros(self):
        names = lambda mode: [c.nome for c in exporters.filter_companies(sample(), mode)]
        self.assertEqual(names("todos"), ["A", "B", "C"])
        self.assertEqual(names("qualificados"), ["A", "C"])
        self.assertEqual(names("sem_site"), ["A", "C"])
        self.assertEqual(names("com_telefone"), ["A", "C"])
        self.assertEqual(names("alta_prioridade"), ["A"])

    def test_csv_utf8_e_nao_informado(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = exporters.export_csv(sample(), Path(tmp) / "x.csv")
            df = pd.read_csv(path, encoding="utf-8-sig", dtype=str, keep_default_na=False)
        self.assertEqual(df.loc[0, "Link do site"], "não informado")
        self.assertEqual(df.loc[1, "Telefone"], "não informado")
        self.assertEqual(df.loc[0, "Redes sociais"], "https://www.instagram.com/a/")
        self.assertEqual(df.loc[0, "Cidade / UF"], "Birigui / SP")

    def test_colunas_selecionadas(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = exporters.export_csv(sample(), Path(tmp) / "x.csv", ["nome", "email"])
            df = pd.read_csv(path, encoding="utf-8-sig", dtype=str, keep_default_na=False)
        self.assertEqual(list(df.columns), ["Nome", "E-mail"])

    def test_excel(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = exporters.export_excel(sample(), Path(tmp) / "x.xlsx")
            df = pd.read_excel(path, dtype=str)
        self.assertEqual(len(df), 3)
        self.assertIn("Avaliação Google", df.columns)
        self.assertIn("Observação", df.columns)

    def test_pdf(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = exporters.export_pdf(sample(), Path(tmp) / "x.pdf")
            data = path.read_bytes()
        self.assertTrue(data.startswith(b"%PDF-1.4"))
        self.assertIn(b"LocalLead Finder", data)
        self.assertGreater(len(data), 1000)


if __name__ == "__main__":
    unittest.main()
