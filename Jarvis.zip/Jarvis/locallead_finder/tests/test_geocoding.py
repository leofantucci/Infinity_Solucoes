import unittest
from types import SimpleNamespace

from database import Database
from services.geocoding import geocode_location
from utils import ProviderError


class FakeResponse:
    def __init__(self, status_code=200, data=None):
        self.status_code = status_code
        self._data = data

    def json(self):
        return self._data


class FakeHttp:
    def __init__(self, response):
        self.response = response
        self.calls = 0

    def get(self, url, **kwargs):
        self.calls += 1
        return self.response


class GeocodingTests(unittest.TestCase):
    def setUp(self):
        self.settings = SimpleNamespace(cache_ttl_hours=24, nominatim_email="", nominatim_url="https://example.test",
                                        nominatim_user_agent="LocalLeadFinder/1.0")
        self.db = Database(":memory:")

    def test_geocodifica_e_usa_cache(self):
        http = FakeHttp(FakeResponse(data=[{"lat": "-21.2079920", "lon": "-50.4390225",
                                            "display_name": "Araçatuba, SP, Brasil"}]))
        result = geocode_location(self.settings, self.db, "Araçatuba", "SP", "Brasil", http=http)
        self.assertAlmostEqual(result["lat"], -21.2079920)
        self.assertEqual(http.calls, 1)

        never = FakeHttp(FakeResponse(data=[]))
        cached = geocode_location(self.settings, self.db, "Araçatuba", "SP", "Brasil", http=never)
        self.assertEqual(cached["lat"], result["lat"])
        self.assertEqual(never.calls, 0)

    def test_rejeita_respostas_invalidas(self):
        with self.assertRaises(ProviderError):
            geocode_location(self.settings, self.db, "", http=FakeHttp(FakeResponse(data=[])))
        with self.assertRaises(ProviderError):
            geocode_location(self.settings, self.db, "X", http=FakeHttp(FakeResponse(data=[])))
        with self.assertRaises(ProviderError):
            geocode_location(self.settings, self.db, "X", http=FakeHttp(FakeResponse(data=[{"lat": "0", "lon": "0"}])))
        with self.assertRaises(ProviderError):
            geocode_location(self.settings, self.db, "X", http=FakeHttp(FakeResponse(status_code=500)))


if __name__ == "__main__":
    unittest.main()
