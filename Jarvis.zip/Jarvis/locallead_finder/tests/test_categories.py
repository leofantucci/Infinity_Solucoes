import json
import shutil
import tempfile
import unittest
from pathlib import Path

from categories import CategoryStore
from config import load_settings


class CategoryTests(unittest.TestCase):
    def setUp(self):
        self.store = CategoryStore(load_settings().categories_file)

    def test_categorias_base_e_subcategorias(self):
        labels = set(self.store.labels())
        for label in ("Salão de beleza", "Estúdio de tatuagem", "Fotógrafo", "Cerimonialista",
                      "Advogados", "Nutricionistas", "Psicólogos", "Eletricistas", "Chaveiros",
                      "Dermatologistas", "Profissionais da saúde autônomos", "Dentistas",
                      "Academias", "Empreendedores", "Veterinários", "Assistência técnica"):
            self.assertIn(label, labels)
        salao = self.store.match("cabeleireiro")
        self.assertIsNotNone(salao)
        self.assertEqual(salao.label, "Salão de beleza")
        self.assertIn("escovaria", salao.terms)

    def test_match_por_subcategoria(self):
        self.assertEqual(self.store.match("ortodontista").label, "Dentistas")
        self.assertEqual(self.store.match("wedding planner").label, "Cerimonialista")
        self.assertEqual(self.store.match("personal trainer").label, "Academias")
        self.assertEqual(self.store.match("oftalmologista").label, "Profissionais da saúde autônomos")
        self.assertEqual(self.store.match("assistencia tecnica").label, "Assistência técnica")
        self.assertEqual(self.store.match("celulares").label, "Assistência técnica")
        self.assertEqual(self.store.match("conserto de celular").label, "Assistência técnica")

    def test_adicionar_termos_nao_apaga_tags_da_categoria_base(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "categories.json"
            shutil.copy(self.store.path, path)
            store = CategoryStore(path)
            store.add_simple("Assistência técnica", ["meu termo novo"])
            cat = store.match("assistencia tecnica")
            self.assertTrue(cat.queries)
            self.assertIn("meu termo novo", cat.aliases)

    def test_categoria_personalizada_simples(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "categories.json"
            path.write_text("{}", encoding="utf-8")
            store = CategoryStore(path)
            store.add_simple("Pet shop", ["pet shop", "banho e tosa"])
            self.assertEqual(store.match("banho e tosa").label, "Pet shop")
            self.assertIn("pet_shop", json.loads(path.read_text(encoding="utf-8")))
            self.assertTrue(store.categories["pet_shop"].name_regex)


if __name__ == "__main__":
    unittest.main()
