"""Utilitários: cancelamento, cliente HTTP educado (atraso + tentativas) e geometria."""
from __future__ import annotations

import math
import threading
import time
from urllib.parse import urlparse

import requests


class Cancelled(Exception):
    """Pesquisa/verificação cancelada pelo usuário."""


class FetchError(Exception):
    """Falha de rede após as tentativas permitidas."""


class ProviderError(Exception):
    """Erro de uma fonte de dados (OSM, Google...), com mensagem para o usuário."""


class CancelToken:
    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def check(self) -> None:
        if self._event.is_set():
            raise Cancelled("Operação cancelada pelo usuário.")

    def sleep(self, seconds: float) -> None:
        """Dorme de forma interrompível."""
        if seconds > 0 and self._event.wait(seconds):
            raise Cancelled("Operação cancelada pelo usuário.")


class HttpClient:
    """Requests com intervalo mínimo por host, timeout, tentativas limitadas e cancelamento."""

    RETRY_STATUS = {429, 502, 503, 504}

    def __init__(self, settings, cancel: CancelToken, log=print) -> None:
        self.settings = settings
        self.cancel = cancel
        self.log = log
        self.session = requests.Session()
        self.session.headers["User-Agent"] = settings.http_user_agent
        self._last: dict[str, float] = {}

    def _throttle(self, host: str, interval: float) -> None:
        wait = interval - (time.monotonic() - self._last.get(host, 0.0))
        if wait > 0:
            self.cancel.sleep(wait)
        self._last[host] = time.monotonic()

    def request(self, method: str, url: str, min_interval: float | None = None,
                retries: int | None = None, timeout: float | None = None, **kwargs) -> requests.Response:
        host = urlparse(url).netloc
        interval = self.settings.request_delay if min_interval is None else min_interval
        retries = self.settings.max_retries if retries is None else retries
        timeout = timeout or self.settings.request_timeout
        last_error = "erro desconhecido"
        for attempt in range(1, retries + 2):
            self.cancel.check()
            self._throttle(host, interval)
            wait = 2.0 * attempt
            try:
                resp = self.session.request(method, url, timeout=timeout, **kwargs)
            except (requests.ConnectionError, requests.Timeout) as exc:
                last_error = f"{type(exc).__name__}: {str(exc)[:120]}"
            except requests.RequestException as exc:
                raise FetchError(f"{type(exc).__name__}: {str(exc)[:120]}") from exc
            else:
                if resp.status_code not in self.RETRY_STATUS:
                    return resp
                last_error = f"HTTP {resp.status_code}"
                retry_after = resp.headers.get("Retry-After", "")
                if retry_after.isdigit():
                    wait = min(float(retry_after), 60.0)
            if attempt <= retries:
                self.log(f"  Falha temporária em {host} ({last_error}); nova tentativa {attempt}/{retries}...")
                self.cancel.sleep(wait)
        raise FetchError(f"{host}: {last_error}")

    def get(self, url: str, **kw) -> requests.Response:
        return self.request("GET", url, **kw)

    def post(self, url: str, **kw) -> requests.Response:
        return self.request("POST", url, **kw)


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))
